# Dsphere frontend in Angular 18 (HTML, CSS and TypeScript only)

The complete Dsphere frontend converted to Angular: all six stakeholders and every page, with no `.js`
files in `src`. Every page is a standalone component (`.ts` with its `.html` template); the styles are the one
shared `src/styles.css`, so all stakeholders keep the same colour palette.

It runs on demo data today (`apiMode: 'mock'`) and talks to the Spring Boot backend when you set
`apiMode: 'live'` (section 6). Every call already uses the real backend path, paging, filters and error format.

## 1. Put it into your project

Your project from `ng new` keeps its `node_modules`, `package.json` and `tsconfig*.json`. Copy in:

```
src/                 → replace your whole src folder (back it up first)
public/              → project root (public/img/dsphere-logo.png)
proxy.conf.json      → project root
```

Then make the three changes to `angular.json` in section 2. Delete any old `src/legacy/` folder.

`angular-config-reference/` holds the complete `angular.json`, `package.json` and `tsconfig` files of a
working Angular 18 project. Compare them with yours, or use them as they are for a brand-new folder
(then run `npm install`).

## 2. angular.json

Under `projects → <name> → architect → build → options`:

```json
"assets": [{ "glob": "**/*", "input": "public" }],
"styles": ["src/styles.css"],
"scripts": []
```

Under `build → configurations → development`, add this if it is not there:

```json
"fileReplacements": [{ "replace": "src/environments/environment.ts", "with": "src/environments/environment.development.ts" }]
```

Under `serve → configurations → development` (for the backend):

```json
"proxyConfig": "proxy.conf.json"
```

## 3. Run

```
ng serve -o
```

Demo sign-ins:

| Stakeholder | Email | Password |
|---|---|---|
| System Admin | admin@dnp.local | Admin@12345 |
| Manufacturer | manufacturer@dnp.local | Demo@12345 |
| Distributor | distributor@dnp.local | Demo@12345 |
| Sales Manager | sales@dnp.local | Demo@12345 |
| Finance Manager | finance@dnp.local | Demo@12345 |
| Recovery Manager | recovery@dnp.local | Demo@12345 |

The demo data lives in the browser (localStorage). User menu → "Reset demo data" starts it again.

Check that no JavaScript is left: `dir /s /b src\*.js` must print nothing.

## 4. The pages

Each stakeholder has a folder with a `<role>.routes.ts`. Every route is lazy-loaded and guarded by the backend
call it needs, using the same `role_permission` rules as the sidebar.

| Stakeholder | Pages (`src/app/<role>/<page>/`) |
|---|---|
| admin | dashboard, users (two-step new user), stakeholders, access (permission matrix, request checker, rules, roles), distributors, master-data, configuration, audit, jobs, exports |
| manufacturer | dashboard, products (products, batches, product-code check), stock, shelf-life, shipments (verify, dispatch), returns, carbon, reports |
| distributor | dashboard, orders, deliveries (confirm with handover code), inventory, returns, tickets, commitments, performance, reports |
| sales | dashboard, distributors (360° view), orders (approve, move forward), targets, health, continuity, commitments, reports |
| finance | dashboard, invoices (record payment), payments, credit-limits, credit-risk, stock-value, reports |
| recovery | dashboard, tickets, sla, disputes, plans (milestones, close), underperformers, reports |

Every role also has `notifications` and `profile`.

Shared pieces in `src/app/common/` are used by several roles: order drawer and new order, shipment drawer and
delivery confirmation, ticket drawer and list, distributor 360° drawer, returns and exchange, commitments,
stock table, reports, and `crud-table` (list + create + edit + delete for any backend table).

The building blocks are in `src/app/shared/` (data table, form modal, modal/drawer, tabs, charts, KPI card,
pill, meter, pipes) and `src/app/core/` (API, auth and access check, guards, toasts, confirm, reference lists,
backend schema).

## 5. Folder layout

```
src/
  index.html  main.ts  styles.css
  environments/environment.ts, environment.development.ts
  app/
    app.component.ts  app.config.ts  app.routes.ts
    core/        api.service.ts, auth.service.ts, guards.ts, ref.service.ts, schema.ts, toast/confirm services
    mock/        the demo backend (remove after going live)
    shared/      data-table/, form-modal/, charts, modal, tabs, kpi, pill, meter, pipes, icons
    layout/      sidebar, top bar, menus (nav.config.ts lists each role's pages)
    auth/        login/, password-reset/
    common/      pages and drawers shared by several roles
    admin/ manufacturer/ distributor/ sales/ finance/ recovery/
```

## 6. Connect the backend (when you are ready)

1. `src/environments/environment.development.ts`: change `apiMode: 'mock'` to `apiMode: 'live'`.
2. Make sure `angular.json` has `"proxyConfig": "proxy.conf.json"` (section 2). It sends `/api` to
   `http://localhost:8081`, the backend's port, so no CORS setup is needed.
3. Start Spring Boot, then `ng serve`. Sign in with a real user from the database.

Nothing else changes. `ApiService` then uses `HttpClient` with HTTP Basic (the backend has no JWT), reads
`X-Total-Count` for paging, fetches long lists 100 rows at a time (the backend's page limit), sends
uploads as multipart field `file`, downloads exports as files, and shows the backend's error body
(`message`, `code`, `fieldErrors`) on forms and toasts.

When everything works live you may delete `src/app/mock/` and the mock branch in `core/api.service.ts`.
Keep `core/schema.ts`: the forms read the backend field rules from it.

Two things the demo does that the backend does not do yet: it raises the invoice and the sales record when a
delivery is confirmed, and it checks the credit limit when an order is approved. Live, those screens show
what the backend returns.

## 7. What was checked

- All TypeScript type-checks with Angular's strict settings (0 errors).
- Every template was checked for matching tags and blocks, `track` on every `@for`, imported components and
  pipes, existing `@Input`/`@Output` bindings, and that every name used exists on the component and is not private.
- Every page of every stakeholder was opened against the demo backend, every list loaded and every cell drawn.
- The main flows were run end to end: place an order → approve → processing → verify items → dispatch →
  confirm delivery with the handover code (with a damaged item raising a ticket); returns and exchange;
  commitments; payments; recovery plans; new user with a role; access matrix change; jobs; exports.
- Every backend call in the app was matched against the Spring controllers: all exist.

If `ng serve` still reports something, send the message and it will be fixed.
