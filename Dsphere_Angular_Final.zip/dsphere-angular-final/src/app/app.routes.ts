/* All routes (replace the 64 HTML page files). Each stakeholder has its own folder and routes file. */
import { Routes } from '@angular/router';
import { authGuard, roleGuard } from './core/guards';
import { LoginComponent } from './auth/login/login.component';
import { PasswordResetComponent } from './auth/password-reset/password-reset.component';
import { LayoutComponent } from './layout/layout.component';
import { ADMIN_ROUTES } from './admin/admin.routes';
import { MANUFACTURER_ROUTES } from './manufacturer/manufacturer.routes';
import { DISTRIBUTOR_ROUTES } from './distributor/distributor.routes';
import { SALES_ROUTES } from './sales/sales.routes';
import { FINANCE_ROUTES } from './finance/finance.routes';
import { RECOVERY_ROUTES } from './recovery/recovery.routes';

export const routes: Routes = [
  { path: 'login', title: 'Sign in · Dsphere', component: LoginComponent },
  { path: 'password-reset', title: 'Reset password · Dsphere', component: PasswordResetComponent },
  {
    path: '', component: LayoutComponent, canActivate: [authGuard], children: [
      { path: 'admin', canActivate: [roleGuard('admin')], children: ADMIN_ROUTES },
      { path: 'manufacturer', canActivate: [roleGuard('manufacturer')], children: MANUFACTURER_ROUTES },
      { path: 'distributor', canActivate: [roleGuard('distributor')], children: DISTRIBUTOR_ROUTES },
      { path: 'sales', canActivate: [roleGuard('sales')], children: SALES_ROUTES },
      { path: 'finance', canActivate: [roleGuard('finance')], children: FINANCE_ROUTES },
      { path: 'recovery', canActivate: [roleGuard('recovery')], children: RECOVERY_ROUTES },
      { path: '', pathMatch: 'full', redirectTo: '/login' }
    ]
  },
  { path: '**', redirectTo: 'login' }
];
