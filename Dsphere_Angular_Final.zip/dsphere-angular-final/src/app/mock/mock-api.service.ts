/*
 * The demo backend, in TypeScript (replaces assets/js/core/api.js).
 * It answers the same paths as the Spring Boot backend, with the same DTO field names, validation messages,
 * error body {status, error, code, message, path, fieldErrors} and role_permission check, so every page can run
 * without the backend. ApiService calls it while environment.apiMode is 'mock'.
 */
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { SCHEMA } from '../core/schema';
import { ApiError } from '../core/api-error';
import { PERMISSION_SEED } from './permissions';
import { SEED } from './mock-data';

const STORE_KEY = 'dsphere.mock.v2';  // v2: records use the backend DTO field names
export const SESSION_KEY = 'dsphere.session';

export interface MockResponse { status: number; data: any; headers: Record<string, string>; path: string; }
export interface RequestOptions { query?: Record<string, any>; body?: any; headers?: Record<string, string>; }
type Handler = (method: string, body: any, query: any, me: any, ...ids: string[]) => any;

// ------------------------------------------------------------------ helpers
const clone = (o: any) => JSON.parse(JSON.stringify(o));
const now = () => new Date();
const pad = (n: any) => String(n).padStart(2, "0");
const isoDate = (d: any) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const isoTs = (d: any) => `${isoDate(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}+05:30`;
const today = () => isoDate(now());
const daysBetween = (a: any, b: any) => Math.round((new Date(String(b).slice(0, 10)).getTime() - new Date(String(a).slice(0, 10)).getTime()) / 86400000);
const num = (v: any) => (v == null || v === "" ? 0 : Number(v));
const round2 = (v: any) => Math.round(v * 100) / 100;

const fail = (status: any, code: any, message: any, fieldErrors?: any): never => { throw new ApiError(status, code, message, fieldErrors); };
const notFound = (what: any, id: any) => fail(404, "RESOURCE_NOT_FOUND", `${what} not found with id ${id}`);
const rule = (message: any) => fail(422, "BUSINESS_RULE_VIOLATION", message);
const invalid = (fieldErrors: any) => fail(400, "VALIDATION_FAILED", "Validation failed", fieldErrors);

// ------------------------------------------------------------------ resources
const RES = SCHEMA.resources;
// controllers that serve the same table under another path
const ALIAS: Record<string, string> = {
  users: "app-users", orders: "distributor-orders", "inventory/products": "products", "inventory/stocks": "warehouse-stocks",
  "risk-management/assessments": "credit-risk-assessments", "risk-management/credit-limits": "distributor-credit-limits",
  "sustainability/commitments": "commitments", "sustainability/emission-factors": "emission-factors"
};
const tableOf = (key: any) => ALIAS[key] || key;
const resourceKeys = Object.keys(RES).sort((a, b) => b.split("/").length - a.split("/").length || b.length - a.length);
const idFieldOf = (key: any) => RES[key].idField;
const fieldsOf = (key: any) => RES[key].fields;

// ------------------------------------------------------------------ the mock database
let db: any = null;
function shiftDates(tables: any, base: any) {
  const delta = daysBetween(base, today());
  if (!delta) return tables;
  const dateRe = /^(\d{4}-\d{2}-\d{2})(.*)$/;
  for (const rows of Object.values(tables) as any[][]) {
    for (const row of rows) {
      for (const k in row) {
        const v = row[k];
        if (typeof v === "string" && v.length >= 10 && dateRe.test(v) && /(Date|At|From|To)$/.test(k)) {
          const [, d, rest] = v.match(dateRe)!;
          const nd = new Date(d + "T00:00:00");
          nd.setDate(nd.getDate() + delta);
          row[k] = isoDate(nd) + rest;
        }
      }
    }
  }
  return tables;
}
function freshDb() {
  const seed = SEED;
  const t = shiftDates(clone(seed.tables), seed.baseDate);
  // entity-only shipment fields (not in ShipmentDTO): kept with "_" and never returned
  for (const s of t.shipments) {
    s._orderId = s.orderId; s._distributorId = s.distributorId; s._handoverCode = s.handoverCode;
    delete s.orderId; delete s.distributorId; delete s.handoverCode;
  }
  for (const it of t["shipment-items"]) {
    it.verificationStatus = it.verification === "MATCH" ? "VERIFIED" : "PENDING";
    it.verifiedQuantity = it.verification === "MATCH" ? it.quantity : null;
    delete it.verification;
  }
  const factor = Object.fromEntries(t["emission-factors"].map((f: any) => [f.emissionFactorId, f.factorValue]));
  for (const a of t["transportation-activities"]) a.emissionKg = round2(a.distanceKm * (factor[a.emissionFactorId] || 0));
  for (const w of t["stock-write-offs"]) { w.writeOffValue = w.quantity * 60; w.writtenOffBy = 2; w.writtenOffAt = isoTs(now()); }
  // role_permission rows from V5__role_based_access.sql
  const roleIdByCode = Object.fromEntries(t.roles.map((r: any) => [r.roleCode, r.roleId]));
  t["role-permissions"] = PERMISSION_SEED.map(([role, resource, r, w], i) => ({
    rolePermissionId: i + 1, roleId: roleIdByCode[role], resource, canRead: !!r, canWrite: !!w,
    description: "Starting rule from V5", updatedAt: isoTs(now()), updatedBy: 1, version: 0
  }));
  // every DTO field is present on every row (null when empty), like the backend's JSON
  for (const key of Object.keys(RES)) {
    const table = t[tableOf(key)];
    if (!table || ALIAS[key]) continue;
    for (const row of table) for (const f of RES[key].fields) if (!(f.name in row)) row[f.name] = null;
  }
  for (const k of Object.keys(RES)) if (!t[tableOf(k)]) t[tableOf(k)] = [];
  return { tables: t, seq: {}, createdOn: today() };
}
function load() {
  if (db) return db;
  try { db = JSON.parse(localStorage.getItem(STORE_KEY) || 'null'); } catch (e) { db = null; }
  if (!db || !db.tables) { db = freshDb(); save(); }
  return db;
}
let saveTimer: any = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { try { localStorage.setItem(STORE_KEY, JSON.stringify(db)); } catch (e) { /* storage full or blocked: keep in memory */ } }, 60);
}
const T = (name: any) => load().tables[tableOf(name)];
function nextId(name: any) {
  const key = tableOf(name);
  const idf = idFieldOf(RES[key] ? key : name);
  const rows = T(key);
  const max = rows.reduce((m: any, r: any) => Math.max(m, num(r[idf])), 0);
  return max + 1;
}
const byId = (name: any, id: any) => {
  const key = tableOf(name);
  const idf = idFieldOf(key);
  return T(key).find((r: any) => String(r[idf]) === String(id));
};
const must = (name: any, id: any) => byId(name, id) || notFound(RES[tableOf(name)].entity, id);
const out = (row: any, key: any) => {
  if (!row) return row;
  const o: any = {};
  const wo = new Set((RES[key] ? RES[key].fields : []).filter((f) => f.writeOnly).map((f) => f.name));
  for (const k in row) if (k[0] !== "_" && !wo.has(k)) o[k] = row[k];
  return o;
};
const statusId = (table: any, name: any) => { const r = T(table).find((x: any) => x.statusName === name); return r ? r[idFieldOf(table)] : null; };
const statusName = (table: any, id: any) => { const r = byId(table, id); return r ? r.statusName : null; };

// ------------------------------------------------------------------ session and access
function session() { try { return JSON.parse(sessionStorage.getItem(SESSION_KEY) || 'null'); } catch (e) { return null; } }
function currentUser() {
  const s = session();
  if (!s) return null;
  return T("app-users").find((u: any) => u.userId === s.userId) || null;
}
function rolesOf(userId: any) {
  const ur = T("user-roles").find((x: any) => x.userId === userId);
  if (!ur) return [];
  const r = byId("roles", ur.roleId);
  return r && r.status === "Active" && r.roleCode ? [r.roleCode] : [];
}
function profileOf(u: any) {
  const du = T("distributor-users").find((x: any) => x.userId === u.userId);
  const mu = T("manufacturer-users").find((x: any) => x.userId === u.userId);
  return { userId: u.userId, email: u.email, userName: u.userName, status: u.status, roles: rolesOf(u.userId),
    distributorId: du ? du.distributorId : null, manufacturerId: mu ? mu.manufacturerId : null };
}
const normalise = (uri: any) => {
  let p = String(uri || "").trim();
  const q = p.indexOf("?");
  if (q >= 0) p = p.slice(0, q);
  p = p.replace(/^\/?api\/v1\//, "").replace(/^\/+|\/+$/g, "");
  return p.toLowerCase();
};
const matches = (pattern: any, path: any) => {
  const p = pattern.split("/"), s = path.split("/");
  if (s.length < p.length) return false;
  return p.every((seg: any, i: any) => seg === "*" || seg === s[i]);
};
const specificity = (r: any) => [r.split("/").length, r.split("/").filter((x: any) => x !== "*").length];
function rulesFor(role: any) {
  const roleRow = T("roles").find((r: any) => r.roleCode === role);
  if (!roleRow) return [];
  return T("role-permissions").filter((p: any) => p.roleId === roleRow.roleId)
    .sort((a: any, b: any) => { const x = specificity(a.resource), y = specificity(b.resource); return y[0] - x[0] || y[1] - x[1]; });
}
function decide(method: any, uri: any, roles: any) {
  const path = normalise(uri);
  if (roles.includes("SYSTEM_ADMIN")) return { allowed: true, resource: "SYSTEM_ADMIN (always allowed)" };
  if (path === "auth" || path.startsWith("auth/")) return { allowed: true, resource: "auth" };
  const read = ["GET", "HEAD", "OPTIONS"].includes(method.toUpperCase());
  let best: any = null, bestSpec: any = null;
  for (const role of roles) {
    const p = rulesFor(role).find((x: any) => matches(x.resource, path));
    if (!p) continue;
    const sp = specificity(p.resource), ok = read ? p.canRead : p.canWrite;
    if (!best || sp[0] > bestSpec[0] || (sp[0] === bestSpec[0] && sp[1] > bestSpec[1])) { best = { allowed: ok, resource: p.resource }; bestSpec = sp; }
    else if (sp[0] === bestSpec[0] && sp[1] === bestSpec[1] && ok) best.allowed = true;
  }
  return best || { allowed: false, resource: null };
}

// ------------------------------------------------------------------ validation (mirrors the DTO annotations and DB constraints)
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
function validate(key: any, body: any, mode: any, current?: any) {
  const errs: any = {};
  for (const f of fieldsOf(key)) {
    if (f.readOnly) continue;
    let v = body[f.name];
    const present = v !== undefined && v !== null && v !== "";
    if (f.required && mode === "create" && !present) { errs[f.name] = "is required"; continue; }
    if (!present) continue;
    if (f.type === "String") {
      v = String(v);
      if (f.max && v.length > f.max) errs[f.name] = `must be at most ${f.max} characters`;
      else if (f.email && !EMAIL_RE.test(v)) errs[f.name] = "must be a valid email address";
      else if (f.options && !f.options.includes(v)) errs[f.name] = `must be one of: ${f.options.join(", ")}`;
      else if (f.pattern && !new RegExp("^(?:" + f.pattern + ")$").test(v)) errs[f.name] = "has an invalid format";
    } else if (["Long", "Integer", "BigDecimal"].includes(f.type)) {
      const n = Number(v);
      if (Number.isNaN(n)) { errs[f.name] = "must be a number"; continue; }
      if (f.positive && n <= 0) errs[f.name] = "must be greater than 0";
      else if (f.zeroOrMore && n < 0) errs[f.name] = "must be 0 or greater";
      else if (f.min != null && n < Number(f.min)) errs[f.name] = `must be at least ${f.min}`;
      else if (f.maxValue != null && n > Number(f.maxValue)) errs[f.name] = `must be at most ${f.maxValue}`;
    } else if (f.type === "LocalDate" && !/^\d{4}-\d{2}-\d{2}$/.test(String(v))) errs[f.name] = "must be a date (yyyy-MM-dd)";
  }
  if (Object.keys(errs).length) invalid(errs);
  // references must exist
  for (const f of fieldsOf(key)) {
    const v = body[f.name];
    if (f.refPath && v != null && v !== "" && RES[f.refPath] && !byId(f.refPath, v)) fail(404, "REFERENCE_NOT_FOUND", `${RES[f.refPath].entity} not found with id ${v} (${f.name})`, { [f.name]: "does not exist" });
  }
  // unique groups
  const idf = idFieldOf(key);
  for (const group of RES[key].unique || []) {
    const merged = Object.assign({}, current || {}, body);
    if (group.some((g) => merged[g] == null || merged[g] === "")) continue;
    const clash = T(key).find((r: any) => (!current || r[idf] !== current[idf]) && group.every((g) => String(r[g]).toLowerCase() === String(merged[g]).toLowerCase()));
    if (clash) fail(409, "DUPLICATE_RESOURCE", `${RES[key].entity} with the same ${group.join(" + ")} already exists`, Object.fromEntries(group.map((g) => [g, "already exists"])));
  }
}
function coerce(key: any, body: any) {
  const o: any = {};
  for (const f of fieldsOf(key)) {
    if (!(f.name in body)) continue;
    let v = body[f.name];
    if (v === "") v = null;
    if (v != null && ["Long", "Integer", "BigDecimal"].includes(f.type)) v = Number(v);
    if (v != null && f.type === "Boolean") v = v === true || v === "true";
    o[f.name] = v;
  }
  if ("version" in body) o.version = body.version == null ? null : Number(body.version);
  return o;
}
function referencesTo(key: any, id: any) {
  const target = tableOf(key);
  const hits: any[] = [];
  for (const [k, r] of Object.entries(RES)) {
    if (ALIAS[k]) continue;
    for (const f of r.fields) if (f.refPath && tableOf(f.refPath) === target && (T(k) || []).some((row: any) => String(row[f.name]) === String(id))) hits.push(r.entity);
  }
  return [...new Set(hits)];
}

// ------------------------------------------------------------------ row scoping (a distributor sees only their own rows)
function scopeRows(key: any, rows: any, me: any) {
  if (!me || !me.roles.includes("DISTRIBUTOR") || !me.distributorId) return rows;
  const d = me.distributorId;
  const t = tableOf(key);
  const myOrders = new Set(T("distributor-orders").filter((o: any) => o.distributorId === d).map((o: any) => o.orderId));
  if (rows.length && "distributorId" in rows[0]) return rows.filter((r: any) => r.distributorId === d || r.distributorId == null && t === "warehouse-stocks");
  if (t === "warehouse-stocks") return rows.filter((r: any) => r.ownerDistributorId === d);
  if (["invoices", "order-items", "order-status-histories", "sales-records"].includes(t)) return rows.filter((r: any) => myOrders.has(r.orderId));
  if (t === "shipments") return rows.filter((r: any) => r._distributorId === d);
  if (t === "notifications") return rows.filter((r: any) => r.userId === me.userId);
  return rows;
}

// ------------------------------------------------------------------ generic CRUD
function list(key: any, query: any, me: any) {
  let rows = scopeRows(key, T(key).slice(), me);
  const reserved = new Set(["page", "size", "sort", "q"]);
  const fset = Object.fromEntries(fieldsOf(key).map((f) => [f.name, f]));
  for (const [k, v] of Object.entries(query)) {
    if (reserved.has(k) || v === "" || v == null) continue;
    if (!fset[k]) fail(400, "VALIDATION_FAILED", `Unknown filter "${k}". Filters must be fields of ${RES[key].entity}`, { [k]: "is not a field" });
    const f = fset[k];
    if (f.type === "String" && !f.options) rows = rows.filter((r: any) => String(r[k] ?? "").toLowerCase().includes(String(v).toLowerCase()));
    else rows = rows.filter((r: any) => String(r[k]) === String(v));
  }
  if (query.q) {
    const q = String(query.q).toLowerCase();
    rows = rows.filter((r: any) => Object.entries(r).some(([k, v]) => k[0] !== "_" && v != null && typeof v !== "object" && String(v).toLowerCase().includes(q)));
  }
  const sort = query.sort || `${idFieldOf(key)},desc`;
  const [sf, dir] = sort.split(",");
  if (!fset[sf]) fail(400, "VALIDATION_FAILED", `Cannot sort by "${sf}"`, { sort: "is not a field" });
  const sgn = (dir || "asc").toLowerCase() === "desc" ? -1 : 1;
  rows.sort((a: any, b: any) => {
    const x = a[sf], y = b[sf];
    if (x == null && y == null) return 0;
    if (x == null) return 1;
    if (y == null) return -1;
    return (typeof x === "number" && typeof y === "number" ? x - y : String(x).localeCompare(String(y), undefined, { numeric: true })) * sgn;
  });
  const total = rows.length;
  if (query.page != null || query.size != null) {
    if (query.size != null && (num(query.size) < 1 || num(query.size) > 100)) fail(400, "INVALID_PARAMETER", "size must be between 1 and 100");  // same cap as AbstractCrudService.MAX_PAGE_SIZE
    const size = Math.min(Math.max(num(query.size) || 20, 1), 100);
    const page = Math.max(num(query.page), 0);
    rows = rows.slice(page * size, page * size + size);
  }
  return { data: rows.map((r: any) => out(r, key)), headers: { "X-Total-Count": String(total) } };
}
function create(key: any, body: any, me: any) {
  if (RES[key].readOnlyResource) fail(405, "METHOD_NOT_ALLOWED", `${RES[key].entity} is written by the workflows and cannot be created directly`);
  const data = coerce(key, body);
  const idf = idFieldOf(key);
  const row: any = {};
  for (const f of fieldsOf(key)) row[f.name] = f.readOnly ? null : data[f.name] ?? null;
  // Like the backend (@Validated(OnCreate) on the request body): required fields are checked before any default is filled in.
  const missing: any = {};
  for (const f of fieldsOf(key)) if (!f.readOnly && f.required && (data[f.name] === undefined || data[f.name] === null || data[f.name] === "")) missing[f.name] = "is required";
  if (Object.keys(missing).length) invalid(missing);
  applyDefaults(key, row, me);
  validate(key, row, "create");
  // The six stakeholder tables share their key with app_user (user_id): the caller gives it, it is not generated.
  row[idf] = idf === "userId" && body && body.userId != null ? num(body.userId) : nextId(key);
  if (idf === "userId" && T(key).some((x: any) => x.userId === row.userId)) fail(409, "DUPLICATE_RESOURCE", `User ${row.userId} is already in this table`, { userId: "already exists" });
  row.version = 0;
  hooks.beforeCreate(key, row, me);
  T(key).push(row);
  hooks.afterCreate(key, row, me);
  audit(RES[key].entity, row[idf], "CREATE", me, null, row);
  save();
  return out(row, key);
}
function update(key: any, id: any, body: any, me: any) {
  if (RES[key].readOnlyResource) fail(405, "METHOD_NOT_ALLOWED", `${RES[key].entity} is read-only`);
  const row = must(key, id);
  if (scopeRows(key, [row], me).length === 0) fail(403, "ACCESS_DENIED", "You can only change your own records");
  const data = coerce(key, body);
  if (data.version != null && data.version !== row.version) fail(409, "OPTIMISTIC_LOCK_CONFLICT", `${RES[key].entity} ${id} was changed by someone else. Reload it and try again (your version ${data.version}, current ${row.version})`);
  validate(key, data, "update", row);
  const before = clone(row);
  hooks.beforeUpdate(key, row, data, me);
  for (const f of fieldsOf(key)) if (!f.readOnly && f.name in data && f.name !== "version") row[f.name] = data[f.name];
  if ("updatedAt" in row) row.updatedAt = isoTs(now());
  row.version = num(row.version) + 1;
  audit(RES[key].entity, id, "UPDATE", me, before, row);
  save();
  return out(row, key);
}
function remove(key: any, id: any, me: any) {
  if (RES[key].readOnlyResource) fail(405, "METHOD_NOT_ALLOWED", `${RES[key].entity} is read-only`);
  const row = must(key, id);
  hooks.beforeDelete(key, row, me);
  const used = referencesTo(key, id);
  if (used.length) fail(409, "RECORD_IN_USE", `${RES[key].entity} ${id} is still used by ${used.join(", ")}. Remove those first`);
  const rows = T(key);
  rows.splice(rows.indexOf(row), 1);
  audit(RES[key].entity, id, "DELETE", me, row, null);
  save();
  return null;
}
function applyDefaults(key: any, row: any, me: any) {
  const t = now();
  if ("createdAt" in row && !row.createdAt) row.createdAt = isoTs(t);
  if ("updatedAt" in row) row.updatedAt = isoTs(t);
  if ("createdBy" in row && !row.createdBy && me) row.createdBy = me.userId;
  if ("requestedBy" in row && !row.requestedBy && me) row.requestedBy = me.userId;
  if ("requestedAt" in row && !row.requestedAt) row.requestedAt = isoTs(t);
  if ("assignedAt" in row && !row.assignedAt) row.assignedAt = isoTs(t);
  if ("recordedAt" in row && !row.recordedAt) row.recordedAt = isoTs(t);
  if ("uploadedAt" in row && !row.uploadedAt) row.uploadedAt = isoTs(t);
  if ("status" in row && !row.status) { const f = fieldsOf(key).find((x) => x.name === "status"); row.status = f && f.options ? f.options[0] : "Active"; }
  const t2 = tableOf(key);
  if (t2 === "distributor-orders") {
    if (!row.orderStatusId) row.orderStatusId = statusId("order-statuses", "Placed");
    if (!row.orderNumber) row.orderNumber = `ORD-${t.getFullYear()}-${1040 + nextId("distributor-orders")}`;
    if (!row.orderDate) row.orderDate = isoDate(t);
    if (!row.distributorId && me && me.distributorId) row.distributorId = me.distributorId;
  }
  if (t2 === "tickets" && !row.ticketStatusId) row.ticketStatusId = statusId("ticket-statuses", "Open");
  if (t2 === "commitments" && !row.commitmentStatusId) row.commitmentStatusId = statusId("commitment-statuses", "Submitted");
  if (t2 === "exchange-requests" && !row.exchangeStatusId) row.exchangeStatusId = statusId("exchange-statuses", "Requested");
  if (me && me.distributorId && "distributorId" in row && !row.distributorId) row.distributorId = me.distributorId;
  if ("assessedBy" in row && !row.assessedBy && me) row.assessedBy = me.userId;
  if ("approvedBy" in row && !row.approvedBy && me && t2 === "distributor-credit-limits") row.approvedBy = me.userId;
  if ("userId" in row && !row.userId && me && t2 === "ticket-comments") row.userId = me.userId;
  if ("recordedBy" in row && !row.recordedBy && me) row.recordedBy = me.userId;
  if ("generatedBy" in row && !row.generatedBy && me) row.generatedBy = me.userId;
}
const hooks = {
  beforeCreate(key: any, row: any, me: any) {
    const t = tableOf(key);
    if (t === "app-users" && row.passwordHash && row.passwordHash.length < 8) invalid({ passwordHash: "must be at least 8 characters" });
    if (["system-admins", "manufacturer-users", "distributor-users", "sales-managers", "finance-managers", "recovery-managers"].includes(t)) must("app-users", row.userId);
    // CommitmentService.beforeCreate
    if (t === "commitments") {
      if (row.dueDate && row.dueDate < today()) rule("Due date cannot be in the past");
      if (row.targetValue != null && num(row.targetValue) <= 0) rule("Target value must be greater than 0");
    }
    if (t === "user-roles") {
      if (T("user-roles").some((x: any) => x.userId === row.userId)) fail(409, "DUPLICATE_RESOURCE", "This user already has a role. One user has one stakeholder role", { userId: "already has a role" });
      const r = byId("roles", row.roleId);
      if (r && !r.roleCode) rule("This role has no role code and cannot be given to a user");
    }
    if (t === "roles") {
      if (!row.roleCode) invalid({ roleCode: "is required" });
      if (T("roles").some((x: any) => x.roleCode === row.roleCode)) fail(409, "DUPLICATE_RESOURCE", `Role code ${row.roleCode} already exists`, { roleCode: "already exists" });
    }
    if (t === "role-permissions") {
      row.resource = normalise(row.resource);
      if (!/^[a-z0-9*\-]+(\/[a-z0-9*\-{}]+)*$/.test(row.resource)) invalid({ resource: "must look like distributor-orders or tickets/*/assign" });
      if (T("role-permissions").some((x: any) => x.roleId === row.roleId && x.resource === row.resource)) fail(409, "DUPLICATE_RESOURCE", "This role already has a rule for that resource", { resource: "already has a rule" });
      row.updatedAt = isoTs(now()); row.updatedBy = me && me.userId;
    }
    if (t === "products" && row.productCode && !validEan(row.productCode)) invalid({ productCode: "is not a valid 13-digit product code (check digit)" });
    if (t === "product-batches") {
      if (row.manufacturingDate && row.expiryDate && row.expiryDate <= row.manufacturingDate) invalid({ expiryDate: "must be after the manufacturing date" });
    }
    if (t === "product-returns") {
      const s = must("warehouse-stocks", row.warehouseStockId);
      if (num(row.quantity) > num(s.quantity)) rule(`Return quantity ${row.quantity} is more than the ${s.quantity} in that stock`);
      row.productBatchId = s.productBatchId; row.distributorId = row.distributorId || s.ownerDistributorId;
      row.returnNumber = `RET-${now().getFullYear()}-${400 + nextId("product-returns")}`; row.status = "REQUESTED";
    }
    if (t === "exchange-requests") {
      row.requestNumber = row.requestNumber || `EXR-${now().getFullYear()}-${100 + nextId("exchange-requests")}`;
      row.exchangeStatusId = statusId("exchange-statuses", "Requested");
    }
    if (t === "tickets") {
      row.referenceNumber = row.referenceNumber || `TKT-${now().getFullYear()}-${String(300 + nextId("tickets")).padStart(5, "0")}`;
      row.ticketStatusId = row.ticketStatusId || statusId("ticket-statuses", "Open");
      const pr = byId("ticket-priorities", row.ticketPriorityId);
      const sla = T("sla-policies").find((x: any) => x.ticketPriorityId === row.ticketPriorityId);
      if (sla) { const due = now(); due.setHours(due.getHours() + sla.resolutionHours); row.slaDueAt = isoTs(due); }
      row.reopenCount = 0; row.escalationLevel = 0;
      if (pr && !row.subject) invalid({ subject: "is required" });
    }
    if (t === "commitments") row.commitmentStatusId = row.commitmentStatusId || statusId("commitment-statuses", "Submitted");
    if (t === "distributor-orders" && !row.orderNumber) row.orderNumber = `ORD-${now().getFullYear()}-${1040 + nextId("distributor-orders")}`;
    if (t === "health-parameter-weights" && (num(row.weight) <= 0 || num(row.weight) > 1)) invalid({ weight: "must be between 0 and 1 (0.25 = 25%)" });
  },
  afterCreate(key: any, row: any, me: any) {
    const t = tableOf(key);
    const stake = ({ "system-admins": "SYSTEM_ADMIN", "manufacturer-users": "MANUFACTURER", "distributor-users": "DISTRIBUTOR", "sales-managers": "SALES_MANAGER", "finance-managers": "FINANCE_MANAGER", "recovery-managers": "RECOVERY_MANAGER" } as Record<string, string>)[t];
    if (stake) {
      const existing = T("user-roles").find((x: any) => x.userId === row.userId);
      const role = T("roles").find((r: any) => r.roleCode === stake);
      if (existing && existing.roleId !== role.roleId) { T(key).pop(); rule(`User ${row.userId} already has another stakeholder role. One user has one stakeholder role`); }
      if (!existing) T("user-roles").push({ userRoleId: nextId("user-roles"), userId: row.userId, roleId: role.roleId, assignedAt: isoTs(now()), version: 0 });
    }
    if (t === "distributor-orders") pushOrderHistory(row.orderId, row.orderStatusId, me, "Order placed");
    if (t === "tickets") T("ticket-status-histories").push({ ticketStatusHistoryId: nextId("ticket-status-histories"), ticketId: row.ticketId, fromStatusId: null, toStatusId: row.ticketStatusId, changedBy: me && me.userId, remarks: "Ticket raised", changedAt: isoTs(now()) });
    if (t === "commitments") T("commitment-histories").push({ historyId: nextId("commitment-histories"), commitmentId: row.commitmentId, action: "SUBMITTED", actionBy: me && me.userId, remarks: "Commitment submitted", actionAt: isoTs(now()), version: 0 });
    if (t === "exchange-requests") T("exchange-histories").push({ exchangeHistoryId: nextId("exchange-histories"), exchangeId: row.exchangeId, exchangeStatusId: row.exchangeStatusId, changedBy: me && me.userId, remarks: "Exchange requested", changedAt: isoTs(now()), version: 0 });
    if (t === "app-users") notifyRole("SYSTEM_ADMIN", 7, `New user ${row.email} was created`);
  },
  beforeUpdate(key: any, row: any, data: any, me: any) {
    const t = tableOf(key);
    if (t === "roles") {
      if (data.roleCode && data.roleCode !== row.roleCode) rule("The role code cannot be changed. Create a new role instead");
      if (row.roleCode === "SYSTEM_ADMIN" && data.status && data.status !== "Active") rule("The System Admin role cannot be made inactive");
    }
    if (t === "user-roles" && data.userId != null && data.userId !== row.userId) rule("The user of a role assignment cannot be changed. Delete it and give the new user a role");
    if (t === "user-roles" && data.roleId != null && data.roleId !== row.roleId) checkNotLastAdmin(row.userId);
    if (t === "role-permissions") { if (data.resource) data.resource = normalise(data.resource); row.updatedAt = isoTs(now()); row.updatedBy = me && me.userId; }
    if (t === "distributor-orders" && data.orderStatusId != null && data.orderStatusId !== row.orderStatusId) rule("Use POST /distributor-orders/{id}/status to change the status, so the history is kept");
    if (t === "app-users" && data.status && data.status !== "Active" && rolesOf(row.userId).includes("SYSTEM_ADMIN")) checkNotLastAdmin(row.userId);
  },
  beforeDelete(key: any, row: any, me?: any) {
    const t = tableOf(key);
    if (t === "roles" && row.roleCode === "SYSTEM_ADMIN") rule("The System Admin role cannot be deleted");
    if (t === "user-roles") checkNotLastAdmin(row.userId);
    if (t === "app-users") {
      checkNotLastAdmin(row.userId);
      const ur = T("user-roles").find((x: any) => x.userId === row.userId);
      if (ur) fail(409, "RECORD_IN_USE", "This user still has a role. Remove the stakeholder record first");
    }
    const stake = ["system-admins", "manufacturer-users", "distributor-users", "sales-managers", "finance-managers", "recovery-managers"];
    if (stake.includes(t)) {
      if (t === "system-admins") checkNotLastAdmin(row.userId);
      const rows = T("user-roles");
      const i = rows.findIndex((x: any) => x.userId === row.userId);
      if (i >= 0) rows.splice(i, 1);
    }
  }
};
function checkNotLastAdmin(userId: any) {
  const adminRole = T("roles").find((r: any) => r.roleCode === "SYSTEM_ADMIN");
  const admins = T("user-roles").filter((x: any) => x.roleId === adminRole.roleId);
  if (admins.length <= 1 && admins.some((x: any) => x.userId === userId)) rule("This is the last System Admin. Give another user the System Admin role first");
}
function validEan(code: any) {
  if (!/^\d{13}$/.test(String(code))) return false;
  const d = String(code).split("").map(Number);
  const s = d.slice(0, 12).reduce((a, x, i) => a + x * (i % 2 ? 3 : 1), 0);
  return (10 - (s % 10)) % 10 === d[12];
}
function eanCheckDigit(code: any): number {
  const d = String(code).split("").map(Number);
  const s = d.slice(0, 12).reduce((a, x, i) => a + x * (i % 2 ? 3 : 1), 0);
  return (10 - (s % 10)) % 10;
}
function audit(entityName: any, entityId: any, action: any, me: any, oldV: any, newV: any) {
  if (["AuditLog", "Notification", "UserActivityLog"].includes(entityName)) return;
  const strip = (o: any) => o && JSON.stringify(Object.fromEntries(Object.entries(o).filter(([k]) => k[0] !== "_" && k !== "passwordHash")));
  T("audit-logs").push({ auditId: nextId("audit-logs"), userId: me ? me.userId : null, action, entityName, entityId, oldValue: strip(oldV), newValue: strip(newV), ipAddress: null, requestId: null, createdAt: isoTs(now()) });
}
function notify(userId: any, typeId: any, message: any) {
  if (!userId) return;
  T("notifications").push({ notificationId: nextId("notifications"), userId, notificationTypeId: typeId, message, readStatus: false, createdAt: isoTs(now()), version: 0 });
}
function notifyRole(code: any, typeId: any, message: any) {
  const role = T("roles").find((r: any) => r.roleCode === code);
  if (role) T("user-roles").filter((x: any) => x.roleId === role.roleId).forEach((x: any) => notify(x.userId, typeId, message));
}
function distributorUsers(distributorId: any) { return T("distributor-users").filter((x: any) => x.distributorId === distributorId).map((x: any) => x.userId); }
function pushOrderHistory(orderId: any, orderStatusId: any, me: any, remarks: any) {
  T("order-status-histories").push({ orderStatusHistoryId: nextId("order-status-histories"), orderId, orderStatusId, changedBy: me ? me.userId : null, remarks, changedAt: isoTs(now()), version: 0 });
}

// ------------------------------------------------------------------ workflow helpers
const orderTotal = (orderId: any) => round2(T("order-items").filter((i: any) => i.orderId === orderId).reduce((a: any, i: any) => a + num(i.quantity) * num(i.unitPrice), 0));
function invoiceInfo(inv: any) {
  const paid = round2(T("payments").filter((p: any) => p.invoiceId === inv.invoiceId && statusName("payment-statuses", p.paymentStatusId) === "Completed").reduce((a: any, p: any) => a + num(p.amount), 0));
  const outstanding = round2(Math.max(num(inv.invoiceAmount) - paid, 0));
  const overdueDays = outstanding > 0 ? Math.max(daysBetween(inv.dueDate, today()), 0) : 0;
  return { paid, outstanding, overdueDays };
}
function distributorOfOrder(orderId: any) { const o = byId("distributor-orders", orderId); return o ? o.distributorId : null; }
function batchInfo(stock: any) {
  const b = byId("product-batches", stock.productBatchId) || ({} as any);
  const p = byId("products", b.productId) || ({} as any);
  const w = byId("warehouses", stock.warehouseId) || ({} as any);
  const days = b.expiryDate ? daysBetween(today(), b.expiryDate) : null;
  const nearDays = num((T("system-configs").find((c: any) => c.configKey === "expiry.near.days") || ({} as any)).configValue) || 30;
  const expiryState = days == null ? "UNKNOWN" : days < 0 ? "EXPIRED" : days <= nearDays ? "NEAR_EXPIRY" : "OK";
  return { b, p, w, days, expiryState };
}
function currentStock(q: any, me: any) {
  let rows = scopeRows("warehouse-stocks", T("warehouse-stocks").slice(), me);
  if (me && !me.roles.includes("DISTRIBUTOR") && q.owner !== "all") rows = rows.filter((s: any) => q.ownerDistributorId ? String(s.ownerDistributorId) === String(q.ownerDistributorId) : s.ownerDistributorId == null);
  return rows.map((s: any) => {
    const { b, p, w, days, expiryState } = batchInfo(s);
    return { warehouseStockId: s.warehouseStockId, warehouseId: s.warehouseId, warehouseName: w.warehouseName, productId: p.productId, sku: p.sku, productName: p.productName,
      productBatchId: s.productBatchId, batchNumber: b.batchNumber, expiryDate: b.expiryDate, daysToExpiry: days, expiryState, ownerDistributorId: s.ownerDistributorId,
      quantity: s.quantity, reorderLevel: s.reorderLevel, belowReorderLevel: num(s.quantity) < num(s.reorderLevel), isSellable: s.isSellable && expiryState !== "EXPIRED",
      stockType: s.stockType, unitCost: p.unitCost, stockValue: round2(num(s.quantity) * num(p.unitCost)) };
  }).filter((r: any) => (!q.warehouseId || String(r.warehouseId) === String(q.warehouseId)) && (!q.productId || String(r.productId) === String(q.productId)) &&
    (!q.expiryState || r.expiryState === q.expiryState) && (q.belowReorderLevel == null || q.belowReorderLevel === "" || String(r.belowReorderLevel) === String(q.belowReorderLevel)));
}
function healthScoreNow(distributorId: any): any {
  const weights = T("health-parameter-weights").filter((w: any) => !w.validTo || w.validTo >= today());
  const assess = T("distributor-health-assessments").filter((a: any) => a.distributorId === distributorId);
  if (!assess.length) return null;
  const latestPeriod = Math.max(...assess.map((a: any) => a.reportingPeriodId));
  let score = 0, wsum = 0;
  for (const w of weights) {
    const a = assess.filter((x: any) => x.parameterWeightId === w.parameterWeightId && x.reportingPeriodId === latestPeriod).pop();
    if (a) { score += num(a.score) * num(w.weight); wsum += num(w.weight); }
  }
  return { score: wsum ? round2(score / wsum) : null, reportingPeriodId: latestPeriod };
}
const riskBandIdOf = (score: any): any => {
  const band = T("risk-bands").find((b: any) => score >= num(b.minimumScore) && score <= num(b.maximumScore));
  return band ? band.riskBandId : score >= 70 ? 1 : score >= 40 ? 2 : 3;
};
const latestHistory = (distributorId: any): any => T("health-score-histories").filter((h: any) => h.distributorId === distributorId).sort((a: any, b: any) => String(a.calculatedAt).localeCompare(String(b.calculatedAt))).pop() || null;
function performanceOf(distributorId: any, periodId: any) {
  const per = byId("reporting-periods", periodId);
  const target = T("sales-targets").find((t: any) => t.distributorId === distributorId && t.reportingPeriodId === periodId);
  if (!per || !target) return null;
  const achieved = round2(T("sales-records").filter((s: any) => distributorOfOrder(s.orderId) === distributorId && s.saleDate >= per.startDate && s.saleDate <= per.endDate).reduce((a: any, s: any) => a + num(s.recognizedAmount), 0));
  const pct = target.targetValue ? round2((achieved / num(target.targetValue)) * 100) : 0;
  const threshold = num((T("system-configs").find((c: any) => c.configKey === "recovery.mode.threshold.pct") || ({} as any)).configValue) || 60;
  const d = byId("distributors", distributorId) || ({} as any);
  return { distributorId, distributorName: d.distributorName, reportingPeriodId: periodId, periodName: per.periodName, periodStart: per.startDate, periodEnd: per.endDate,
    target: num(target.targetValue), achieved, performancePercent: pct, thresholdPercent: threshold,
    status: pct >= 100 ? "ACHIEVED" : pct >= threshold ? "ON_TRACK" : "RECOVERY" };
}
function currentPeriod() {
  const t = today();
  return T("reporting-periods").filter((p: any) => p.periodType === "Month").find((p: any) => p.startDate <= t && p.endDate >= t) || T("reporting-periods")[0];
}
function continuityOf(distributorId: any) {
  const d = must("distributors", distributorId);
  const orders = T("distributor-orders").filter((o: any) => o.distributorId === distributorId && statusName("order-statuses", o.orderStatusId) !== "Cancelled");
  const last = orders.map((o: any) => o.orderDate).sort().pop() || null;
  const noOrderDays = last ? daysBetween(last, today()) : null;
  const limitDays = num((T("system-configs").find((c: any) => c.configKey === "continuity.no.order.days") || ({} as any)).configValue) || 21;
  const hs = healthScoreNow(distributorId);
  const lastActivity = T("distributor-activities").filter((a: any) => a.distributorId === distributorId).map((a: any) => String(a.activityDate).slice(0, 10)).sort().pop() || null;
  const latestAssessment = T("continuity-assessments").filter((a: any) => a.distributorId === distributorId && a.assessmentDate).sort((a: any, b: any) => String(a.assessmentDate).localeCompare(String(b.assessmentDate))).pop();
  const latestRiskLevel = latestAssessment ? ((byId("risk-levels", latestAssessment.riskLevelId) || ({} as any)).riskLevelName || null) : null;
  const overdue = T("invoices").filter((i: any) => distributorOfOrder(i.orderId) === distributorId).map(invoiceInfo).filter((x: any) => x.overdueDays > 0);
  const reasons = [], recommendations = [];
  if (noOrderDays == null || noOrderDays > limitDays) { reasons.push(noOrderDays == null ? "No orders yet" : `No orders for ${noOrderDays} days`); recommendations.push("Plan a visit and agree a reorder schedule"); }
  if (hs && hs.score != null && hs.score < 50) { reasons.push(`Health score ${hs.score} is below 50`); recommendations.push("Start a recovery plan with weekly milestones"); }
  if (overdue.length) { reasons.push(`${overdue.length} overdue invoice(s), ${round2(overdue.reduce((a: any, x: any) => a + x.outstanding, 0))} outstanding`); recommendations.push("Agree a payment plan with finance"); }
  if (d.status !== "Active") reasons.push(`Account is ${d.status}`);
  return { distributorId, distributorName: d.distributorName, status: d.status, lastActivity, lastOrder: last, latestHealthScore: hs ? hs.score : null,
    latestRiskLevel, atRisk: reasons.length > 0, reasons, recommendations };
}

// ------------------------------------------------------------------ workflow endpoints (path patterns as in the controllers)
const R: any[] = [];
const route = (method: any, pattern: any, handler: any) => R.push({ method, re: new RegExp("^" + pattern.replace(/\{[a-zA-Z]+\}/g, "([^/]+)") + "$"), handler });

// auth
route("POST", "auth/login", (m: any, b: any, q: any, me: any) => ({ ...profileOf(me.user), message: "Signed in" }));
route("GET", "auth/me", (m: any, b: any, q: any, me: any) => profileOf(me.user));
route("POST", "auth/logout", () => null);
route("POST", "auth/change-password", (m: any, b: any, q: any, me: any) => {
  if (!b.currentPassword || me.user.passwordHash !== b.currentPassword) fail(400, "VALIDATION_FAILED", "Current password is wrong", { currentPassword: "is wrong" });
  if (!b.newPassword || b.newPassword.length < 8 || !/[A-Za-z]/.test(b.newPassword) || !/\d/.test(b.newPassword)) invalid({ newPassword: "must be at least 8 characters with a letter and a digit" });
  if (b.newPassword === b.currentPassword) invalid({ newPassword: "must be different from the current password" });
  me.user.passwordHash = b.newPassword; save();
  return null;
});
route("POST", "auth/password-reset/request", (m: any, b: any) => {
  const u = T("app-users").find((x: any) => x.email.toLowerCase() === String(b.email || "").toLowerCase());
  const res = { message: "If the email is registered, a reset token has been issued. It is valid for 15 minutes." };
  if (u) {
    const token = Math.random().toString(36).slice(2, 10).toUpperCase();
    const exp = now(); exp.setMinutes(exp.getMinutes() + 15);
    T("password-resets").push({ passwordResetId: nextId("password-resets"), userId: u.userId, token, expiresAt: isoTs(exp), used: false, createdAt: isoTs(now()), version: 0 });
    Object.assign(res, { resetToken: token, expiresAt: isoTs(exp) });
    save();
  }
  return res;
});
route("POST", "auth/password-reset/confirm", (m: any, b: any) => {
  const r = T("password-resets").find((x: any) => x.token === String(b.token || "").trim().toUpperCase());
  if (!r || r.used) fail(400, "VALIDATION_FAILED", "The reset token is not valid", { token: "is not valid" });
  if (r.expiresAt < isoTs(now())) fail(400, "VALIDATION_FAILED", "The reset token has expired. Ask for a new one", { token: "has expired" });
  if (!b.newPassword || b.newPassword.length < 8 || !/[A-Za-z]/.test(b.newPassword) || !/\d/.test(b.newPassword)) invalid({ newPassword: "must be at least 8 characters with a letter and a digit" });
  must("app-users", r.userId).passwordHash = b.newPassword; r.used = true; save();
  return null;
});
// access rules
route("GET", "role-permissions/mine", (m: any, b: any, q: any, me: any) => ({ roles: me.roles, allowsEverything: me.roles.includes("SYSTEM_ADMIN"),
  permissions: me.roles.flatMap((r: any) => rulesFor(r).map((p: any) => ({ roleCode: r, resource: p.resource, canRead: p.canRead, canWrite: p.canWrite }))) }));
route("GET", "role-permissions/check", (m: any, b: any, q: any) => {
  if (!q.role || !q.method || !q.path) invalid({ role: q.role ? undefined : "is required", method: q.method ? undefined : "is required", path: q.path ? undefined : "is required" });
  const d = decide(q.method, q.path, [String(q.role).toUpperCase()]);
  return { role: String(q.role).toUpperCase(), method: String(q.method).toUpperCase(), path: q.path, allowed: d.allowed, decidedBy: d.resource == null ? "no matching resource (refused)" : d.resource };
});
route("POST", "role-permissions/reload", () => ({ permissionsLoaded: T("role-permissions").length }));
// stock
route("GET", "stocks/current", (m: any, b: any, q: any, me: any) => {
  const rows = currentStock(q, me);
  const page = q.page != null ? num(q.page) : null, size = num(q.size) || 20;
  return { data: page == null ? rows : rows.slice(page * size, page * size + size), headers: { "X-Total-Count": String(rows.length) } };
});
route("GET", "stocks/summary", (m: any, b: any, q: any, me: any) => {
  const by = q.groupBy === "warehouse" ? "warehouse" : "product";
  const groups: any = {};
  for (const r of currentStock(q, me)) {
    const k = by === "product" ? r.productId : r.warehouseId;
    const g = groups[k] || (groups[k] = by === "product" ? { productId: r.productId, sku: r.sku, productName: r.productName } : { warehouseId: r.warehouseId, warehouseName: r.warehouseName });
    g.totalQuantity = num(g.totalQuantity) + num(r.quantity);
    g.sellableQuantity = num(g.sellableQuantity) + (r.isSellable ? num(r.quantity) : 0);
    g.expiredQuantity = num(g.expiredQuantity) + (r.expiryState === "EXPIRED" ? num(r.quantity) : 0);
    g.nearExpiryQuantity = num(g.nearExpiryQuantity) + (r.expiryState === "NEAR_EXPIRY" ? num(r.quantity) : 0);
    g.stockValue = round2(num(g.stockValue) + r.stockValue);
  }
  return Object.values(groups);
});
// products
route("GET", "products/validate-code", (m: any, b: any, q: any) => {
  const code = String(q.code || "").trim();
  if (!/^\d{13}$/.test(code)) return { code, valid: false, message: "A product code has exactly 13 digits", expectedCheckDigit: null };
  if (!validEan(code)) return { code, valid: false, message: "The check digit (last digit) is wrong. The code was probably typed incorrectly", expectedCheckDigit: eanCheckDigit(code) };
  const p = T("products").find((x: any) => x.productCode === code);
  return { code, valid: true, message: p ? "Valid code of a registered product" : "Valid code, but no product has it yet", expectedCheckDigit: num(code.slice(12)) };
});
route("GET", "products/by-code/{code}", (m: any, b: any, q: any, me: any, code: any) => out(T("products").find((x: any) => x.productCode === code) || fail(404, "RESOURCE_NOT_FOUND", `No product has code ${code}`), "products"));
// shipments
function shipmentOf(id: any) { return must("shipments", id); }
function setShipmentStatus(s: any, to: any, me: any, remarks: any) {
  const from = statusName("shipment-statuses", s.shipmentStatusId);
  s.shipmentStatusId = statusId("shipment-statuses", to); s.version++;
  T("shipment-status-histories").push({ shipmentStatusHistoryId: nextId("shipment-status-histories"), shipmentId: s.shipmentId, shipmentStatusId: s.shipmentStatusId, changedBy: me && me.userId, remarks: remarks || null, changedAt: isoTs(now()) });
}
function setOrderStatus(o: any, to: any, me: any, remarks: any) {
  o.orderStatusId = statusId("order-statuses", to); o.updatedAt = isoTs(now()); o.version++;
  pushOrderHistory(o.orderId, o.orderStatusId, me, remarks || `Moved to ${to}`);
  distributorUsers(o.distributorId).forEach((u: any) => notify(u, 1, `Order ${o.orderNumber} moved to ${to}`));
}
route("POST", "shipments/{id}/items/{itemId}/verify", (m: any, b: any, q: any, me: any, id: any, itemId: any) => {
  const s = shipmentOf(id);
  const st = statusName("shipment-statuses", s.shipmentStatusId);
  if (!["Created", "Verified", "On Hold"].includes(st)) rule(`Items can only be verified before dispatch (shipment is ${st})`);
  const errs: any = {};
  if (!/^\d{13}$/.test(String(b.productCode || ""))) errs.productCode = b.productCode ? "Product code must be 13 digits" : "Product code is required";
  if (!b.batchNumber) errs.batchNumber = "Batch number is required";
  if (!(num(b.quantity) > 0)) errs.quantity = b.quantity ? "Quantity must be greater than 0" : "Quantity is required";
  if (Object.keys(errs).length) invalid(errs);
  const it = T("shipment-items").find((x: any) => String(x.shipmentItemId) === String(itemId) && x.shipmentId === s.shipmentId) || notFound("ShipmentItem", itemId);
  const batch = byId("product-batches", it.productBatchId) || ({} as any);
  const prod = byId("products", batch.productId) || ({} as any);
  let reason: any = null;
  if (b.productCode !== prod.productCode) reason = `Product code does not match. Expected ${prod.productName}`;
  else if (String(b.batchNumber).trim().toUpperCase() !== String(batch.batchNumber).toUpperCase()) reason = `Batch does not match. This item is packed from batch ${batch.batchNumber}`;
  else if (num(b.quantity) !== num(it.quantity)) reason = `Quantity does not match. ${it.quantity} were packed`;
  else if (batch.expiryDate < today()) reason = "The batch has expired and cannot be shipped";
  const result = reason ? "MISMATCH" : "MATCH";
  const v = { verificationId: nextId("product-verifications"), shipmentId: s.shipmentId, shipmentItemId: it.shipmentItemId, enteredCode: b.productCode, enteredBatchNumber: b.batchNumber,
    enteredQuantity: num(b.quantity), result, message: reason || "Item matches the packing record", verifiedBy: me.userId, verifiedAt: isoTs(now()) };
  T("product-verifications").push(v);
  it.verificationStatus = reason ? "MISMATCH" : "VERIFIED"; it.verifiedQuantity = reason ? null : num(b.quantity); it.version++;
  const items = T("shipment-items").filter((x: any) => x.shipmentId === s.shipmentId);
  if (items.every((x: any) => x.verificationStatus === "VERIFIED") && st === "Created") setShipmentStatus(s, "Verified", me, "All items verified");
  save();
  return { verificationId: v.verificationId, shipmentItemId: it.shipmentItemId, result, verificationStatus: it.verificationStatus, messages: reason ? [reason] : [],
    productName: prod.productName || null, batchNumber: batch.batchNumber || null };
});
route("GET", "shipments/{id}/verifications", (m: any, b: any, q: any, me: any, id: any) => { shipmentOf(id); return T("product-verifications").filter((v: any) => String(v.shipmentId) === String(id)).map(({ shipmentId, ...v }: any) => v); });
route("POST", "shipments/{id}/dispatch", (m: any, b: any, q: any, me: any, id: any) => {
  const s = shipmentOf(id);
  const st = statusName("shipment-statuses", s.shipmentStatusId);
  if (!["Created", "Verified"].includes(st)) rule(`Only a shipment that is not yet dispatched can be dispatched (it is ${st})`);
  const items = T("shipment-items").filter((x: any) => x.shipmentId === s.shipmentId);
  if (!items.length) rule("The shipment has no items");
  const pending = items.filter((x: any) => x.verificationStatus !== "VERIFIED");
  if (pending.length) rule(`${pending.length} item(s) are not verified yet. Verify every item before dispatch`);
  const pickStock = (it: any) => T("warehouse-stocks").filter((w: any) => w.productBatchId === it.productBatchId && w.ownerDistributorId == null && num(w.quantity) >= num(it.quantity))
    .sort((x: any, y: any) => (x.warehouseId === s.warehouseId ? -1 : 0) - (y.warehouseId === s.warehouseId ? -1 : 0))[0];
  for (const it of items) {
    if (!pickStock(it)) rule(`Not enough stock of batch ${(byId("product-batches", it.productBatchId) || ({} as any)).batchNumber} to dispatch ${it.quantity}`);
  }
  for (const it of items) {
    const stock = pickStock(it);
    stock.quantity = num(stock.quantity) - num(it.quantity); stock.version++;
    T("inventory-movements").push({ movementId: nextId("inventory-movements"), inventoryDocumentId: null, warehouseStockId: stock.warehouseStockId, movementTypeId: 2, quantity: num(it.quantity), movementDate: isoTs(now()), version: 0 });
  }
  s._handoverCode = String(Math.floor(100000 + Math.random() * 900000));
  s.dispatchDate = today(); s.dispatchedBy = me.userId;
  setShipmentStatus(s, "In Transit", me, b.remarks || "Dispatched");
  const o = s._orderId && byId("distributor-orders", s._orderId);
  if (o && statusName("order-statuses", o.orderStatusId) !== "Dispatched") setOrderStatus(o, "Dispatched", me, "Shipment dispatched");
  distributorUsers(s._distributorId).forEach((u: any) => notify(u, 2, `Shipment ${s.trackingNumber} has been dispatched. Handover code: ${s._handoverCode}`));
  const d = byId("distributors", s._distributorId) || ({} as any);
  const ta: any = { transportationActivityId: nextId("transportation-activities"), shipmentId: s.shipmentId, emissionFactorId: 1, origin: (byId("warehouses", s.warehouseId) || ({} as any)).location || "Warehouse",
    destination: (d.address || "").split(", ").pop() || "Distributor", distanceKm: 300 + (s.shipmentId * 37) % 500, activityDate: today(), version: 0 };
  ta.emissionKg = round2(ta.distanceKm * num((byId("emission-factors", 1) || ({} as any)).factorValue)); T("transportation-activities").push(ta);
  audit("Shipment", s.shipmentId, "STATUS_CHANGE", me, null, { status: "DISPATCHED", items: items.length });
  save();
  return { shipment: out(s, "shipments"), handoverCode: s._handoverCode, itemsDispatched: items.length,
    note: "Give this 6-digit handover code to the driver. The distributor types it in to confirm the delivery." };
});
route("POST", "shipments/{id}/status", (m: any, b: any, q: any, me: any, id: any) => {
  const s = shipmentOf(id);
  if (!b.status) invalid({ status: "Status is required" });
  const to = T("shipment-statuses").find((x: any) => x.statusName.toLowerCase() === String(b.status).toLowerCase()) || fail(400, "VALIDATION_FAILED", `Unknown shipment status ${b.status}`, { status: "is not a shipment status" });
  const from = statusName("shipment-statuses", s.shipmentStatusId);
  if (from === "Delivered") rule("A delivered shipment cannot change status");
  if (to.statusName === "Delivered") rule("A shipment becomes Delivered only when the distributor confirms it with the handover code");
  if (to.statusName === "In Transit" && !["Verified", "On Hold"].includes(from)) rule("Use dispatch to send a shipment on its way");
  setShipmentStatus(s, to.statusName, me, b.remarks); save();
  return out(s, "shipments");
});
route("GET", "shipments/{id}/status-history", (m: any, b: any, q: any, me: any, id: any) => { shipmentOf(id); return T("shipment-status-histories").filter((h: any) => String(h.shipmentId) === String(id)).sort((a: any, b2: any) => String(a.changedAt).localeCompare(String(b2.changedAt))); });
route("POST", "delivery-receipts/{shipmentId}/confirm", (m: any, b: any, q: any, me: any, id: any) => {
  const s = shipmentOf(id);
  if (me.distributorId && s._distributorId !== me.distributorId) fail(403, "ACCESS_DENIED", "This shipment is not for your distributor");
  const st = statusName("shipment-statuses", s.shipmentStatusId);
  if (st === "Delivered") rule("This delivery has already been confirmed");
  if (st !== "In Transit") rule(`Only a shipment in transit can be confirmed (it is ${st})`);
  if (!/^\d{6}$/.test(String(b.handoverCode || ""))) invalid({ handoverCode: b.handoverCode ? "Handover code is 6 digits" : "Handover code is required" });
  if (s._handoverCode !== String(b.handoverCode)) rule("The handover code is wrong. Check the code on the delivery note");
  const items = T("shipment-items").filter((x: any) => x.shipmentId === s.shipmentId);
  const lines = Array.isArray(b.items) && b.items.length ? b.items : items.map((i: any) => ({ shipmentItemId: i.shipmentItemId, receivedQuantity: i.quantity, damagedQuantity: 0 }));
  const errs: any = {};
  lines.forEach((l: any, i: any) => {
    if (l.shipmentItemId == null) errs[`items[${i}].shipmentItemId`] = "Shipment item id is required";
    if (l.receivedQuantity == null || l.receivedQuantity === "") errs[`items[${i}].receivedQuantity`] = "Received quantity is required";
    else if (num(l.receivedQuantity) < 0) errs[`items[${i}].receivedQuantity`] = "Received quantity must be 0 or greater";
    if (num(l.damagedQuantity) < 0) errs[`items[${i}].damagedQuantity`] = "Damaged quantity must be 0 or greater";
  });
  if (Object.keys(errs).length) invalid(errs);
  const receipt = { deliveryReceiptId: nextId("delivery-receipts"), shipmentId: s.shipmentId, distributorId: s._distributorId, receivedBy: me.userId, receivedAt: isoTs(now()), remarks: b.remarks || null, status: "CONFIRMED", version: 0 };
  T("delivery-receipts").push(receipt);
  const discrepancies: any[] = [];
  for (const l of lines) {
    const it = items.find((x: any) => String(x.shipmentItemId) === String(l.shipmentItemId)) || notFound("ShipmentItem", l.shipmentItemId);
    const rec = num(l.receivedQuantity), dmg = num(l.damagedQuantity);
    if (rec + dmg > num(it.quantity)) { const msg = `Item ${it.shipmentItemId}: received (${rec}) + damaged (${dmg}) is more than the ${it.quantity} shipped`; fail(400, "VALIDATION_FAILED", msg, { items: msg }); }
    const good = rec;
    if (good > 0) {
      let stock = T("warehouse-stocks").find((w: any) => w.ownerDistributorId === s._distributorId && w.productBatchId === it.productBatchId);
      if (!stock) { stock = { warehouseStockId: nextId("warehouse-stocks"), warehouseId: b.destinationWarehouseId || s.warehouseId, productBatchId: it.productBatchId, ownerDistributorId: s._distributorId, quantity: 0, reorderLevel: 20, isSellable: true, receivedAt: isoTs(now()), stockType: "STOCK_SELL", version: 0 }; T("warehouse-stocks").push(stock); }
      stock.quantity = num(stock.quantity) + good; stock.version++;
    }
    if (rec + dmg < num(it.quantity) || dmg > 0) {
      const type = dmg > 0 ? "DAMAGED" : "SHORTAGE";
      const cat = T("ticket-categories").find((c: any) => c.categoryName === (dmg > 0 ? "Damaged goods" : "Delivery shortage"));
      const ticket = { ticketId: nextId("tickets"), referenceNumber: `TKT-${now().getFullYear()}-${String(300 + nextId("tickets")).padStart(5, "0")}`, distributorId: s._distributorId, ticketCategoryId: cat ? cat.ticketCategoryId : 1,
        ticketStatusId: statusId("ticket-statuses", "Open"), ticketPriorityId: 2, subject: `${type === "DAMAGED" ? "Damaged goods" : "Shortage"} on shipment ${s.trackingNumber}`,
        description: `Expected ${it.quantity}, received ${rec}, damaged ${dmg}`, createdBy: me.userId, createdAt: isoTs(now()), closedAt: null, findings: null, correctiveAction: null, assignedTo: null,
        slaDueAt: isoTs(new Date(Date.now() + 24 * 3600e3)), resolvedAt: null, reopenCount: 0, escalationLevel: 0, version: 0 };
      T("tickets").push(ticket);
      const dsc = { discrepancyId: nextId("delivery-discrepancies"), deliveryReceiptId: receipt.deliveryReceiptId, shipmentItemId: it.shipmentItemId, discrepancyType: type, quantity: type === "DAMAGED" ? dmg : num(it.quantity) - rec - dmg, ticketId: ticket.ticketId, createdAt: isoTs(now()), version: 0 };
      T("delivery-discrepancies").push(dsc); discrepancies.push(dsc);
      notifyRole("RECOVERY_MANAGER", 3, `New ticket ${ticket.referenceNumber}: ${ticket.subject}`);
    }
  }
  receipt.status = discrepancies.length ? "CONFIRMED_WITH_DISCREPANCY" : "CONFIRMED";
  s.deliveryDate = today();
  setShipmentStatus(s, "Delivered", me, "Delivery confirmed with the handover code");
  const o = s._orderId && byId("distributor-orders", s._orderId);
  if (o) {
    setOrderStatus(o, "Delivered", me, "Delivery confirmed");
    const total = orderTotal(o.orderId);
    const due = now(); due.setDate(due.getDate() + 30);
    if (!T("invoices").some((i: any) => i.orderId === o.orderId)) T("invoices").push({ invoiceId: nextId("invoices"), invoiceNumber: `INV-${now().getFullYear()}-${5200 + nextId("invoices")}`, orderId: o.orderId, invoiceStatusId: statusId("invoice-statuses", "Unpaid"), invoiceDate: today(), dueDate: isoDate(due), invoiceAmount: total, version: 0 });
    T("sales-records").push({ salesRecordId: nextId("sales-records"), orderId: o.orderId, saleDate: today(), recognizedAmount: total, version: 0 });
  }
  save();
  return { receipt, items: lines, discrepancies };
});
// orders
route("POST", "distributor-orders/{id}/status", (m: any, b: any, q: any, me: any, id: any) => {
  const o = must("distributor-orders", id);
  if (!b.status) invalid({ status: "Status is required" });
  const to = T("order-statuses").find((x: any) => x.statusName.toLowerCase() === String(b.status).toLowerCase()) || fail(400, "VALIDATION_FAILED", `Unknown order status ${b.status}`, { status: "is not an order status" });
  const from = byId("order-statuses", o.orderStatusId);
  if (from.isTerminal) rule(`The order is ${from.statusName} and cannot change any more`);
  if (to.statusName === "Cancelled") rule("Use POST /distributor-orders/{id}/cancel to cancel an order");
  if (num(to.sequenceNumber) <= num(from.sequenceNumber)) rule(`An order only moves forward. It is ${from.statusName}, so ${to.statusName} is not allowed`);
  if (to.statusName === "Delivered") rule("An order becomes Delivered when the distributor confirms the delivery");
  if (to.statusName === "Dispatched") rule("An order becomes Dispatched when its shipment is dispatched");
  if (to.statusName === "Approved") {
    const lim = T("distributor-credit-limits").filter((c: any) => c.distributorId === o.distributorId && (!c.validTo || c.validTo >= today())).pop();
    const outstanding = T("invoices").filter((i: any) => distributorOfOrder(i.orderId) === o.distributorId).reduce((a: any, i: any) => a + invoiceInfo(i).outstanding, 0);
    if (lim && outstanding + orderTotal(o.orderId) > num(lim.creditLimit)) rule(`Approving this order would take the distributor over the credit limit (${Math.round(outstanding + orderTotal(o.orderId))} > ${lim.creditLimit})`);
  }
  if (to.statusName === "Processing" && !T("shipments").some((s: any) => s._orderId === o.orderId)) {
    const items = T("order-items").filter((i: any) => i.orderId === o.orderId);
    const sh = { shipmentId: nextId("shipments"), trackingNumber: `TRK${884200 + nextId("shipments") * 13}`, warehouseId: 1, shipmentStatusId: statusId("shipment-statuses", "Created"), dispatchDate: null, deliveryDate: null, dispatchedBy: null, version: 0, _orderId: o.orderId, _distributorId: o.distributorId, _handoverCode: null };
    T("shipments").push(sh);
    let first = true;
    for (const it of items) {
      // first expiring sellable batch with enough stock (FEFO); otherwise the batch with the most stock
      const rows = T("warehouse-stocks").filter((w: any) => w.ownerDistributorId == null).map((w: any) => ({ w, b: byId("product-batches", w.productBatchId) })).filter((x: any) => x.b && x.b.productId === it.productId && x.b.expiryDate > today());
      const pick = rows.filter((x: any) => num(x.w.quantity) >= num(it.quantity)).sort((x: any, y: any) => x.b.expiryDate.localeCompare(y.b.expiryDate))[0] || rows.sort((x: any, y: any) => num(y.w.quantity) - num(x.w.quantity))[0];
      if (pick && first) { sh.warehouseId = pick.w.warehouseId; first = false; }
      T("shipment-items").push({ shipmentItemId: nextId("shipment-items"), shipmentId: sh.shipmentId, orderItemId: it.orderItemId, quantity: it.quantity, productBatchId: pick ? pick.b.productBatchId : (T("product-batches").find((x: any) => x.productId === it.productId) || ({} as any)).productBatchId, verifiedQuantity: null, verificationStatus: "PENDING", version: 0 });
    }
    notifyRole("MANUFACTURER", 1, `Order ${o.orderNumber} is ready to pack. Shipment ${sh.trackingNumber} created`);
  }
  setOrderStatus(o, to.statusName, me, b.remarks); save();
  return out(o, "distributor-orders");
});
route("POST", "distributor-orders/{id}/cancel", (m: any, b: any, q: any, me: any, id: any) => {
  const o = must("distributor-orders", id);
  if (!b.reason) invalid({ reason: "Reason is required" });
  const st = byId("order-statuses", o.orderStatusId);
  if (["Dispatched", "Delivered", "Cancelled"].includes(st.statusName)) rule(`An order can be cancelled only until it is shipped (it is ${st.statusName})`);
  T("shipments").filter((s: any) => s._orderId === o.orderId).forEach((s: any) => setShipmentStatus(s, "On Hold", me, "Order cancelled"));
  setOrderStatus(o, "Cancelled", me, b.reason); save();
  return out(o, "distributor-orders");
});
route("GET", "distributor-orders/{id}/history", (m: any, b: any, q: any, me: any, id: any) => { must("distributor-orders", id); return T("order-status-histories").filter((h: any) => String(h.orderId) === String(id)).map((h: any) => out(h, "order-status-histories")); });
// returns
const retStep = (from: any, to: any, fn: any) => (m: any, b: any, q: any, me: any, id: any) => {
  const r = must("product-returns", id);
  if (!from.includes(r.status)) rule(`This return is ${r.status}. It must be ${from.join(" or ")} first`);
  fn && fn(r, b, me);
  r.status = to; r.version++; save();
  distributorUsers(r.distributorId).forEach((u: any) => notify(u, 5, `Return ${r.returnNumber} is now ${to}`));
  return out(r, "product-returns");
};
route("POST", "product-returns/{id}/approve", retStep(["REQUESTED"], "APPROVED", (r: any, b: any) => { r.targetWarehouseId = b.targetWarehouseId ? num(b.targetWarehouseId) : 1; if (!byId("warehouses", r.targetWarehouseId)) notFound("Warehouse", r.targetWarehouseId); }));
route("POST", "product-returns/{id}/reject", retStep(["REQUESTED"], "REJECTED", (r: any, b: any) => { if (!b.reason) invalid({ reason: "Reason is required" }); r.reason = `${r.reason} | Rejected: ${b.reason}`; }));
route("POST", "product-returns/{id}/ship", retStep(["APPROVED"], "SHIPPED", (r: any) => { const s = must("warehouse-stocks", r.warehouseStockId); if (num(s.quantity) < num(r.quantity)) rule("The holder no longer has that much stock"); s.quantity = num(s.quantity) - num(r.quantity); s.version++; }));
route("POST", "product-returns/{id}/receive", retStep(["SHIPPED"], "RECEIVED", (r: any) => {
  T("warehouse-stocks").push({ warehouseStockId: nextId("warehouse-stocks"), warehouseId: r.targetWarehouseId, productBatchId: r.productBatchId, ownerDistributorId: null, quantity: num(r.quantity), reorderLevel: 0, isSellable: false, receivedAt: isoTs(now()), stockType: "STOCK_SELL", version: 0 });
  r.warehouseReceivedAt = isoTs(now());
}));
// exchange
const exStep = (from: any, to: any, fn: any) => (m: any, b: any, q: any, me: any, id: any) => {
  const e = must("exchange-requests", id);
  const cur = statusName("exchange-statuses", e.exchangeStatusId);
  if (!from.includes(cur)) rule(`This exchange is ${cur}. It must be ${from.join(" or ")} first`);
  fn && fn(e, b, me);
  e.exchangeStatusId = statusId("exchange-statuses", to); e.version++;
  T("exchange-histories").push({ exchangeHistoryId: nextId("exchange-histories"), exchangeId: e.exchangeId, exchangeStatusId: e.exchangeStatusId, changedBy: me.userId, remarks: b.remarks || b.reason || `Moved to ${to}`, changedAt: isoTs(now()), version: 0 });
  distributorUsers(e.distributorId).forEach((u: any) => notify(u, 1, `Exchange ${e.requestNumber} is now ${to}`));
  save();
  return out(e, "exchange-requests");
};
route("POST", "exchange-requests/{id}/approve", exStep(["Requested"], "Approved", (e: any, b: any, me: any) => {
  const errs: any = {};
  if (!b.sourceWarehouseStockId) errs.sourceWarehouseStockId = "Source warehouse stock id is required";
  if (!b.destinationWarehouseId) errs.destinationWarehouseId = "Destination warehouse id is required";
  if (Object.keys(errs).length) invalid(errs);
  const s = must("warehouse-stocks", b.sourceWarehouseStockId);
  const bt = byId("product-batches", s.productBatchId);
  if (!bt || bt.productId !== e.productId) rule("The source stock is a different product");
  if (num(s.quantity) < num(e.requestedQuantity)) rule(`The source stock has only ${s.quantity}, ${e.requestedQuantity} requested`);
  must("warehouses", b.destinationWarehouseId);
  Object.assign(e, { sourceWarehouseStockId: num(b.sourceWarehouseStockId), destinationWarehouseId: num(b.destinationWarehouseId), decidedBy: me.userId, decidedAt: isoTs(now()), decisionRemarks: b.remarks || null });
}));
route("POST", "exchange-requests/{id}/reject", exStep(["Requested"], "Rejected", (e: any, b: any, me: any) => { if (!b.reason) invalid({ reason: "Reason is required" }); Object.assign(e, { decidedBy: me.userId, decidedAt: isoTs(now()), decisionRemarks: b.reason }); }));
route("POST", "exchange-requests/{id}/complete", exStep(["Approved"], "Completed", (e: any) => {
  const s = must("warehouse-stocks", e.sourceWarehouseStockId);
  if (num(s.quantity) < num(e.requestedQuantity)) rule("The source stock no longer has enough quantity");
  s.quantity = num(s.quantity) - num(e.requestedQuantity); s.version++;
  let dest = T("warehouse-stocks").find((w: any) => w.ownerDistributorId === e.distributorId && w.productBatchId === s.productBatchId);
  if (!dest) { dest = { warehouseStockId: nextId("warehouse-stocks"), warehouseId: e.destinationWarehouseId, productBatchId: s.productBatchId, ownerDistributorId: e.distributorId, quantity: 0, reorderLevel: 20, isSellable: true, receivedAt: isoTs(now()), stockType: "STOCK_SELL", version: 0 }; T("warehouse-stocks").push(dest); }
  dest.quantity = num(dest.quantity) + num(e.requestedQuantity);
}));
route("GET", "exchange-requests/{id}/history", (m: any, b: any, q: any, me: any, id: any) => { must("exchange-requests", id); return T("exchange-histories").filter((h: any) => String(h.exchangeId) === String(id)); });
// tickets
function ticketStatus(t: any, to: any, me: any, remarks: any) {
  const fromId = t.ticketStatusId;
  t.ticketStatusId = statusId("ticket-statuses", to); t.version++;
  T("ticket-status-histories").push({ ticketStatusHistoryId: nextId("ticket-status-histories"), ticketId: t.ticketId, fromStatusId: fromId, toStatusId: t.ticketStatusId, changedBy: me.userId, remarks: remarks || null, changedAt: isoTs(now()) });
  distributorUsers(t.distributorId).forEach((u: any) => notify(u, 3, `Ticket ${t.referenceNumber} is now ${to}`));
}
const tk = (id: any) => must("tickets", id);
const tStatus = (t: any) => statusName("ticket-statuses", t.ticketStatusId);
route("POST", "tickets/{id}/assign", (m: any, b: any, q: any, me: any, id: any) => {
  const t = tk(id);
  if (!b.assignedTo) invalid({ assignedTo: "assignedTo (user id) is required" });
  if (["Closed"].includes(tStatus(t))) rule("A closed ticket cannot be assigned");
  const u = must("app-users", b.assignedTo);
  if (!rolesOf(u.userId).some((r) => ["RECOVERY_MANAGER", "SYSTEM_ADMIN"].includes(r))) rule(`${u.userName} is not a Recovery Manager`);
  if (u.status !== "Active") rule(`${u.userName} is not an active user`);
  T("ticket-assignment-histories").push({ historyId: nextId("ticket-assignment-histories"), ticketId: t.ticketId, assignedFrom: t.assignedTo, assignedTo: u.userId, assignedBy: me.userId, remarks: b.remarks || null, assignedAt: isoTs(now()) });
  t.assignedTo = u.userId; t.version++;
  if (tStatus(t) === "Open" || tStatus(t) === "Reopened") ticketStatus(t, "In Progress", me, "Assigned");
  notify(u.userId, 3, `Ticket ${t.referenceNumber} was assigned to you`);
  save(); return out(t, "tickets");
});
route("POST", "tickets/{id}/status", (m: any, b: any, q: any, me: any, id: any) => {
  const t = tk(id);
  if (!b.status) invalid({ status: "Status is required" });
  const to = T("ticket-statuses").find((x: any) => x.statusName.toLowerCase() === String(b.status).toLowerCase()) || fail(400, "VALIDATION_FAILED", `Unknown ticket status ${b.status}`, { status: "is not a ticket status" });
  if (["Resolved", "Closed", "Reopened"].includes(to.statusName)) rule(`Use the ${to.statusName === "Resolved" ? "resolve" : to.statusName === "Closed" ? "close" : "reopen"} action for that`);
  if (tStatus(t) === "Closed") rule("A closed ticket must be reopened first");
  ticketStatus(t, to.statusName, me, b.remarks); save(); return out(t, "tickets");
});
route("POST", "tickets/{id}/resolve", (m: any, b: any, q: any, me: any, id: any) => {
  const t = tk(id);
  const e: any = {};
  if (!b.findings) e.findings = "Findings are required";
  if (!b.correctiveAction) e.correctiveAction = "Corrective action is required";
  if (Object.keys(e).length) invalid(e);
  if (["Resolved", "Closed"].includes(tStatus(t))) rule(`The ticket is already ${tStatus(t)}`);
  if (!t.assignedTo) rule("Assign the ticket before resolving it");
  Object.assign(t, { findings: b.findings, correctiveAction: b.correctiveAction, resolvedAt: isoTs(now()) });
  ticketStatus(t, "Resolved", me, "Resolved"); save(); return out(t, "tickets");
});
route("POST", "tickets/{id}/close", (m: any, b: any, q: any, me: any, id: any) => {
  const t = tk(id);
  if (tStatus(t) !== "Resolved") rule("Only a resolved ticket can be closed");
  t.closedAt = isoTs(now()); ticketStatus(t, "Closed", me, b.remarks || "Closed"); save(); return out(t, "tickets");
});
route("POST", "tickets/{id}/reopen", (m: any, b: any, q: any, me: any, id: any) => {
  const t = tk(id);
  if (!b.reason) invalid({ reason: "Reason is required" });
  if (!["Resolved", "Closed"].includes(tStatus(t))) rule("Only a resolved or closed ticket can be reopened");
  t.reopenCount = num(t.reopenCount) + 1; t.closedAt = null; t.resolvedAt = null;
  ticketStatus(t, "Reopened", me, b.reason); save(); return out(t, "tickets");
});
route("POST", "tickets/{id}/escalate", (m: any, b: any, q: any, me: any, id: any) => {
  const t = tk(id);
  if (!b.reason) invalid({ reason: "Reason is required" });
  if (["Resolved", "Closed"].includes(tStatus(t))) rule("A resolved or closed ticket cannot be escalated");
  const max = num((T("system-configs").find((c: any) => c.configKey === "ticket.max.escalation.level") || ({} as any)).configValue) || 3;
  if (num(t.escalationLevel) >= max) rule(`The ticket is already at the highest escalation level (${max})`);
  t.escalationLevel = num(t.escalationLevel) + 1; t.version++;
  const to = b.escalatedTo ? num(b.escalatedTo) : 8;
  T("escalations").push({ escalationId: nextId("escalations"), ticketId: t.ticketId, escalatedTo: to, escalationLevel: t.escalationLevel, reason: b.reason, createdAt: isoTs(now()), version: 0 });
  notify(to, 3, `Ticket ${t.referenceNumber} escalated to level ${t.escalationLevel}: ${b.reason}`);
  save(); return out(t, "tickets");
});
route("GET", "tickets/{id}/history", (m: any, b: any, q: any, me: any, id: any) => {
  const f = (x: any) => String(x.ticketId) === String(id);
  const t = tk(id);
  const sorted = (rows: any[], k: string) => [...rows].sort((a: any, b2: any) => String(a[k]).localeCompare(String(b2[k])));
  return { ticketId: t.ticketId, referenceNumber: t.referenceNumber,
    statusChanges: sorted(T("ticket-status-histories").filter(f), "changedAt").map((h: any) => out(h, "ticket-status-histories")),
    assignments: sorted(T("ticket-assignment-histories").filter(f), "assignedAt").map((a: any) => out(a, "ticket-assignment-histories")),
    escalations: sorted(T("escalations").filter(f), "createdAt").map((e: any) => out(e, "escalations")) };
});
route("GET", "tickets/{id}/attachments", (m: any, b: any, q: any, me: any, id: any) => { tk(id); return T("ticket-attachments").filter((a: any) => String(a.ticketId) === String(id)); });
route("POST", "tickets/{id}/attachments", (m: any, b: any, q: any, me: any, id: any) => {
  const t = tk(id);
  const allowed = ["application/pdf", "image/png", "image/jpeg", "image/gif", "image/webp", "text/plain"];
  if (!b.fileName) invalid({ file: "A file is required" });
  if (!allowed.includes(b.contentType)) fail(400, "VALIDATION_FAILED", "Only PDF, image or text files can be attached", { file: "type not allowed" });
  if (num(b.sizeBytes) > 5 * 1024 * 1024) fail(400, "VALIDATION_FAILED", "The file is larger than 5 MB", { file: "is larger than 5 MB" });
  const a = { attachmentId: nextId("ticket-attachments"), ticketId: t.ticketId, fileName: b.fileName, contentType: b.contentType, sizeBytes: num(b.sizeBytes), uploadedBy: me.userId, uploadedAt: isoTs(now()) };
  T("ticket-attachments").push(a); save(); return a;
});
route("GET", "tickets/{id}/attachments/{attachmentId}/download", (m: any, b: any, q: any, me: any, id: any, aid: any) => {
  const a = T("ticket-attachments").find((x: any) => String(x.attachmentId) === String(aid) && String(x.ticketId) === String(id)) || notFound("TicketAttachment", aid);
  return { file: { name: a.fileName, type: "text/plain", text: `Demo copy of ${a.fileName}\nThe live backend sends the stored file here.` } };
});
// commitments
const cmStep = (to: any, need?: any) => (m: any, b: any, q: any, me: any, id: any) => {
  const c = must("commitments", id);
  const cur = statusName("commitment-statuses", c.commitmentStatusId);
  if (cur !== "Submitted") rule(`Only a submitted commitment can be ${to.toLowerCase()} (it is ${cur})`);
  if (need && !b.reason) invalid({ reason: "Reason is required" });
  c.commitmentStatusId = statusId("commitment-statuses", to); c.version++; c.updatedAt = isoTs(now());
  if (to === "Approved") { c.approvedBy = me.userId; c.approvedAt = isoTs(now()); } else c.rejectionReason = b.reason;
  T("commitment-histories").push({ historyId: nextId("commitment-histories"), commitmentId: c.commitmentId, action: to.toUpperCase(), actionBy: me.userId, remarks: b.reason || b.remarks || null, actionAt: isoTs(now()), version: 0 });
  distributorUsers(c.distributorId).forEach((u: any) => notify(u, 1, `Commitment "${c.targetName}" was ${to.toLowerCase()}`));
  save(); return out(c, "commitments");
};
route("POST", "commitments/{id}/approve", cmStep("Approved"));
route("POST", "commitments/{id}/reject", cmStep("Rejected", true));
route("GET", "commitments/{id}/completion", (m: any, b: any, q: any, me: any, id: any) => {
  const c = must("commitments", id);
  const progress = T("commitment-progresses").filter((p: any) => p.commitmentId === c.commitmentId);
  const latest = progress.length ? Math.max(...progress.map((p: any) => num(p.progressValue))) : 0;
  const daysLeft = daysBetween(today(), c.dueDate);
  return { commitmentId: c.commitmentId, targetName: c.targetName, targetValue: num(c.targetValue), achieved: latest, completionPercent: c.targetValue ? round2(Math.min(latest / num(c.targetValue) * 100, 100)) : 0,
    status: statusName("commitment-statuses", c.commitmentStatusId), dueDate: c.dueDate, daysLeft, overdue: daysLeft < 0 && latest < num(c.targetValue) };
});
route("GET", "commitments/{id}/history", (m: any, b: any, q: any, me: any, id: any) => { must("commitments", id); return T("commitment-histories").filter((h: any) => String(h.commitmentId) === String(id)); });
// health and risk
route("GET", "health-scores/weights/check", () => {
  const active = T("health-parameter-weights").filter((w: any) => !w.validTo || w.validTo >= today());
  const total = round2(active.reduce((a: any, w: any) => a + num(w.weight), 0) * 100);
  return { date: today(), totalPercent: total, valid: Math.abs(total - 100) < 0.01,
    weights: active.map((w: any) => ({ parameterWeightId: w.parameterWeightId, parameter: ((byId("health-parameters", w.parameterId) || {}) as any).parameterName || null, weightPercent: round2(num(w.weight) * 100) })) };
});
route("POST", "health-scores/calculate/{distributorId}", (m: any, b: any, q: any, me: any, did: any) => {
  const d = must("distributors", did);
  const check = R.find((r) => r.re.test("health-scores/weights/check")).handler();
  if (!check.valid) rule(`Active weights total ${check.totalPercent}%; they must total 100%`);
  const hs = healthScoreNow(d.distributorId) || rule("No health assessments exist for this distributor yet");
  const bandId = riskBandIdOf(hs.score);
  const h = { healthScoreHistoryId: nextId("health-score-histories"), distributorId: d.distributorId, reportingPeriodId: hs.reportingPeriodId, totalScore: hs.score, riskBandId: bandId,
    breakdown: null, calculatedBy: me.userId, calculatedAt: isoTs(now()), version: 0 };
  T("health-score-histories").push(h);
  const limit = num((T("system-configs").find((c: any) => c.configKey === "health.alert.threshold") || ({} as any)).configValue) || 50;
  if (hs.score < limit) notifyRole("SALES_MANAGER", 6, `Health score of ${d.distributorName} is ${hs.score}, below ${limit}`);
  const band = byId("risk-bands", bandId) || ({} as any);
  save();
  return { distributorId: d.distributorId, distributorName: d.distributorName, reportingPeriodId: hs.reportingPeriodId, totalScore: hs.score, riskBandId: bandId, riskCategory: band.riskCategory || null,
    breakdown: [], missingParameters: [], alertRaised: hs.score < limit, healthScoreHistoryId: h.healthScoreHistoryId, calculatedAt: h.calculatedAt };
});
route("GET", "health-scores/{distributorId}/trend", (m: any, b: any, q: any, me: any, did: any) => { must("distributors", did); return T("health-score-histories").filter((h: any) => String(h.distributorId) === String(did)).sort((a: any, b2: any) => a.calculatedAt.localeCompare(b2.calculatedAt)); });
route("POST", "credit-risk/calculate/{distributorId}", (m: any, b: any, q: any, me: any, did: any) => {
  const d = must("distributors", did);
  const lim = T("distributor-credit-limits").filter((c: any) => c.distributorId === d.distributorId && (!c.validFrom || c.validFrom <= today()) && (!c.validTo || c.validTo >= today())).pop()
    || rule(`${d.distributorName} has no credit limit that is valid today. Add one under Credit limits (valid from today or earlier), then calculate again.`);
  const infos = T("invoices").filter((i: any) => distributorOfOrder(i.orderId) === d.distributorId).map(invoiceInfo);
  const outstanding = infos.reduce((a: any, x: any) => a + x.outstanding, 0);
  const overdue = infos.filter((x: any) => x.overdueDays > 0);
  const util = num(lim.creditLimit) ? outstanding / num(lim.creditLimit) : 1;
  const hs = healthScoreNow(d.distributorId);
  const score = Math.round(Math.min(100, util * 55 + Math.min(overdue.length * 8, 25) + (hs && hs.score != null ? (100 - hs.score) * 0.2 : 10)));
  const a = { riskAssessmentId: nextId("credit-risk-assessments"), distributorId: d.distributorId, creditLimitId: lim.creditLimitId, riskScore: score, assessedBy: me.userId, assessedAt: isoTs(now()), version: 0 };
  T("credit-risk-assessments").push(a); save();
  const paidTotal = round2(infos.reduce((x: any, i: any) => x + i.paid, 0));
  const invoiced = round2(paidTotal + outstanding);
  const overdueAmount = round2(overdue.reduce((x: any, i: any) => x + i.outstanding, 0));
  return { distributorId: d.distributorId, distributorName: d.distributorName, creditLimitId: lim.creditLimitId, creditLimit: num(lim.creditLimit), invoiced,
    paid: paidTotal, outstanding: round2(outstanding), overdueAmount, overdueInvoices: overdue.length, utilisationPercent: round2(util * 100),
    riskScore: score, riskLevel: score < 40 ? "LOW" : score < 70 ? "MEDIUM" : "HIGH", riskAssessmentId: a.riskAssessmentId };
});
route("GET", "continuity/at-risk", () => T("distributors").filter((d: any) => d.status === "Active").map((d: any) => continuityOf(d.distributorId)).filter((c: any) => c.atRisk).sort((a: any, b: any) => b.reasons.length - a.reasons.length));
route("GET", "continuity/{distributorId}", (m: any, b: any, q: any, me: any, did: any) => continuityOf(num(did)));
route("GET", "performance", (m: any, b: any, q: any, me: any) => {
  const per = q.reportingPeriodId ? num(q.reportingPeriodId) : currentPeriod().reportingPeriodId;
  let rows = T("sales-targets").filter((t: any) => t.reportingPeriodId === per).map((t: any) => performanceOf(t.distributorId, per)).filter(Boolean);
  if (me.distributorId) rows = rows.filter((r: any) => r.distributorId === me.distributorId);
  return rows.sort((a: any, b2: any) => a.performancePercent - b2.performancePercent);
});
route("GET", "performance/{distributorId}", (m: any, b: any, q: any, me: any, did: any) => {
  must("distributors", did);
  const per = q.reportingPeriodId ? num(q.reportingPeriodId) : currentPeriod().reportingPeriodId;
  return performanceOf(num(did), per) || rule("This distributor has no sales target for the period");
});
// recovery
route("POST", "recovery-milestones/{id}/complete", (m: any, b: any, q: any, me: any, id: any) => {
  const ms = must("recovery-milestones", id);
  if (b.achievedAmount == null || b.achievedAmount === "") invalid({ achievedAmount: "Achieved amount is required" });
  if (num(b.achievedAmount) < 0) invalid({ achievedAmount: "Achieved amount must be 0 or greater" });
  if (ms.status === "COMPLETED") rule("This milestone is already completed");
  const plan = must("recovery-plans", ms.recoveryPlanId);
  if (plan.closedAt) rule("The recovery plan is closed");
  Object.assign(ms, { achievedAmount: num(b.achievedAmount), status: "COMPLETED", completedAt: isoTs(now()) }); ms.version++;
  plan.recoveredAmount = round2(num(plan.recoveredAmount) + num(b.achievedAmount)); plan.version++;
  save(); return out(ms, "recovery-milestones");
});
route("GET", "recovery-plans/{id}/progress", (m: any, b: any, q: any, me: any, id: any) => {
  const p = must("recovery-plans", id);
  const ms = T("recovery-milestones").filter((x: any) => x.recoveryPlanId === p.recoveryPlanId);
  return { recoveryPlanId: p.recoveryPlanId, distributorId: p.distributorId, status: statusName("recovery-plan-statuses", p.recoveryStatusId), recoveryMode: !!p.recoveryMode,
    targetAmount: num(p.targetAmount), recoveredAmount: num(p.recoveredAmount),
    progressPercent: p.targetAmount ? round2(num(p.recoveredAmount) / num(p.targetAmount) * 100) : 0, milestones: ms.map((x: any) => out(x, "recovery-milestones")),
    daysLeft: daysBetween(today(), p.endDate), outcome: p.outcome || null };
});
route("POST", "recovery-plans/{id}/close", (m: any, b: any, q: any, me: any, id: any) => {
  const p = must("recovery-plans", id);
  const ok = ["RECOVERED", "PARTIALLY_RECOVERED", "NOT_RECOVERED", "CANCELLED"];
  if (!b.outcome) invalid({ outcome: "Outcome is required" });
  if (!ok.includes(b.outcome)) invalid({ outcome: "Outcome must be one of: " + ok.join(", ") });
  if (p.closedAt) rule("The recovery plan is already closed");
  Object.assign(p, { outcome: b.outcome, outcomeRemarks: b.remarks || null, closedAt: isoTs(now()), recoveryStatusId: 4 }); p.version++;
  save(); return out(p, "recovery-plans");
});
// sustainability
route("GET", "emissions/summary", (m: any, b: any, q: any) => {
  const year = q.year ? num(q.year) : now().getFullYear();
  const target = num((T("system-configs").find((c: any) => c.configKey === "emission.monthly.limit.kg") || ({} as any)).configValue) || 12000;
  const months: any[] = Array.from({ length: 12 }, (_, i) => ({ month: i + 1, activities: 0, emissionKg: 0, targetKg: target, aboveTarget: false }));
  for (const a of T("transportation-activities")) {
    if (!a.activityDate || num(a.activityDate.slice(0, 4)) !== year) continue;
    const mm = months[num(a.activityDate.slice(5, 7)) - 1];
    mm.emissionKg = round2(mm.emissionKg + num(a.emissionKg)); mm.activities++;
  }
  months.forEach((mm) => { mm.aboveTarget = mm.emissionKg > mm.targetKg; });
  return { year, totalEmissionKg: round2(months.reduce((a, x) => a + x.emissionKg, 0)), yearlyTargetKg: round2(target * 12), months };
});
route("POST", "emissions/calculate/{activityId}", (m: any, b: any, q: any, me: any, id: any) => {
  const a = must("transportation-activities", id);
  const f = byId("emission-factors", a.emissionFactorId) || rule("The activity has no emission factor");
  a.emissionKg = round2(num(a.distanceKm) * num(f.factorValue)); a.version++; save();
  return out(a, "transportation-activities");
});
// notifications
route("GET", "notifications/mine", (m: any, b: any, q: any, me: any) => T("notifications").filter((n: any) => n.userId === me.userId).sort((a: any, b2: any) => b2.createdAt.localeCompare(a.createdAt)).map((n: any) => out(n, "notifications")));
route("POST", "notifications/{id}/read", (m: any, b: any, q: any, me: any, id: any) => {
  const n = must("notifications", id);
  if (n.userId !== me.userId) fail(403, "ACCESS_DENIED", "This notification is not yours");
  n.readStatus = true; n.version++; save(); return out(n, "notifications");
});
// jobs
const JOBS: Record<string, string> = { "expiry-check": "Marks expired batches as not sellable and warns about near-expiry stock", "recovery-mode": "Opens recovery plans for distributors below the performance threshold",
  "recovery-milestone-check": "Marks missed recovery milestones", "ticket-sla-escalation": "Escalates tickets that passed their SLA", "emission-recalculation": "Recalculates emissions of transport activities",
  "continuity-check": "Flags distributors at continuity risk", "commitment-reminders": "Reminds distributors of commitments that are due", "health-score-recalculation": "Recalculates every distributor's health score" };
route("GET", "jobs", () => Object.entries(JOBS).map(([name, description]) => ({ name, description })));
route("POST", "jobs/{name}/run", (m: any, b: any, q: any, me: any, name: any) => {
  if (!JOBS[name]) notFound("Job", name);
  let processed = 0, message = "Finished";
  if (name === "expiry-check") { for (const s of T("warehouse-stocks")) { const { expiryState } = batchInfo(s); if (expiryState === "EXPIRED" && s.isSellable) { s.isSellable = false; processed++; } } message = `${processed} stock rows marked not sellable`; }
  if (name === "ticket-sla-escalation") { for (const t of T("tickets")) { if (!["Resolved", "Closed"].includes(tStatus(t)) && t.slaDueAt && t.slaDueAt < isoTs(now()) && num(t.escalationLevel) < 3) { t.escalationLevel = num(t.escalationLevel) + 1; processed++; T("escalations").push({ escalationId: nextId("escalations"), ticketId: t.ticketId, escalatedTo: 8, escalationLevel: t.escalationLevel, reason: "SLA passed (automatic)", createdAt: isoTs(now()), version: 0 }); } } message = `${processed} ticket(s) escalated`; }
  if (name === "recovery-milestone-check") { for (const ms of T("recovery-milestones")) if (ms.status === "PENDING" && ms.dueDate < today()) { ms.status = "MISSED"; processed++; } message = `${processed} milestone(s) marked missed`; }
  if (name === "health-score-recalculation") { for (const d of T("distributors")) if (healthScoreNow(d.distributorId)) processed++; message = `${processed} distributors checked`; }
  if (name === "continuity-check") { processed = T("distributors").filter((d: any) => d.status === "Active" && continuityOf(d.distributorId).atRisk).length; message = `${processed} distributor(s) at continuity risk`; }
  if (name === "recovery-mode") {
    const per = currentPeriod().reportingPeriodId; let opened = 0, already = 0;
    for (const t of T("sales-targets").filter((x: any) => x.reportingPeriodId === per)) {
      const p = performanceOf(t.distributorId, per);
      if (p && p.status === "RECOVERY") {
        if (T("recovery-plans").some((rp: any) => rp.distributorId === t.distributorId && !rp.closedAt)) already++;
        else { opened++; T("recovery-plans").push({ recoveryPlanId: nextId("recovery-plans"), distributorId: t.distributorId, recoveryStatusId: 1, targetAmount: round2(p.target - p.achieved), startDate: today(), endDate: isoDate(new Date(Date.now() + 60 * 864e5)), createdBy: me.userId, createdAt: isoTs(now()), recoveryMode: true, recoveredAmount: 0, outcome: null, outcomeRemarks: null, closedAt: null, version: 0 }); }
      }
    }
    processed = opened; message = `${opened} recovery plan(s) opened, ${already} already in recovery`;
  }
  if (name === "emission-recalculation") { for (const a of T("transportation-activities")) { const f = byId("emission-factors", a.emissionFactorId); if (f) { a.emissionKg = round2(num(a.distanceKm) * num(f.factorValue)); processed++; } } message = `${processed} activities recalculated`; }
  if (name === "commitment-reminders") { for (const c of T("commitments")) if (statusName("commitment-statuses", c.commitmentStatusId) === "Approved" && daysBetween(today(), c.dueDate) <= 7) { distributorUsers(c.distributorId).forEach((u: any) => notify(u, 1, `Commitment "${c.targetName}" is due on ${c.dueDate}`)); processed++; } message = `${processed} reminder(s) sent`; }
  const start = now();
  const run = { jobRunId: nextId("job-runs"), jobName: name, status: "SUCCESS", startedAt: isoTs(start), finishedAt: isoTs(new Date(start.getTime() + 900)), summary: message, triggeredBy: me.userId };
  T("job-runs").push(run); save();
  return { job: name, jobRunId: run.jobRunId, status: run.status, processedCount: processed, message };
});
// exports and dashboard
const EXPORTABLE = ["distributors", "distributor-orders", "invoices", "payments", "tickets", "products", "warehouse-stocks", "shipments", "commitments", "recovery-plans", "sales-targets", "credit-risk-assessments", "health-score-histories", "audit-logs", "app-users", "transportation-activities"];
route("GET", "exports", () => EXPORTABLE);
route("GET", "exports/{entity}", (m: any, b: any, q: any, me: any, entity: any) => {
  if (!EXPORTABLE.includes(entity)) fail(404, "RESOURCE_NOT_FOUND", `Nothing called ${entity} can be exported`);
  const rows = list(entity, {}, me).data;
  const cols = rows.length ? Object.keys(rows[0]) : RES[entity].fields.map((f) => f.name);
  const cell = (v: any) => (v == null ? "" : /[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v));
  const csv = [cols.join(","), ...rows.map((r: any) => cols.map((c) => cell(r[c])).join(","))].join("\n");
  const format = (q.format || "xlsx").toLowerCase();
  return { file: { name: `${entity}_${today()}.${format === "csv" ? "csv" : "csv"}`, type: "text/csv", text: csv }, note: format !== "csv" ? "The demo downloads CSV. The live backend returns a real .xlsx or .pdf here." : null };
});
route("GET", "dashboard/summary", (m: any, b: any, q: any, me: any) => {
  const tickets = scopeRows("tickets", T("tickets"), me);
  const openTickets = tickets.filter((t: any) => !["Resolved", "Closed"].includes(tStatus(t)));
  const mine = (d: any) => !me.distributorId || d.distributorId === me.distributorId;
  const dists = T("distributors").filter(mine);
  const stock = currentStock({}, me);
  const scores = dists.map((d: any) => ({ id: d.distributorId, h: latestHistory(d.distributorId) })).filter((x: any) => x.h && x.h.totalScore != null);
  const lowest = scores.length ? scores.reduce((a: any, x: any) => (num(x.h.totalScore) < num(a.h.totalScore) ? x : a)) : null;
  const rows = [
    ["Distributors", dists.length],
    ["Active distributors", dists.filter((d: any) => d.status === "Active").length],
    ["Open tickets", openTickets.length],
    ["Tickets past SLA", openTickets.filter((t: any) => t.slaDueAt && t.slaDueAt < isoTs(now())).length],
    ["Stock value", round2(stock.reduce((a: any, s: any) => a + s.stockValue, 0))],
    ["Expired stock quantity", stock.filter((s: any) => s.expiryState === "EXPIRED").reduce((a: any, s: any) => a + num(s.quantity), 0)],
    ["Stock rows near expiry", stock.filter((s: any) => s.expiryState === "NEAR_EXPIRY").length],
    ["Stock rows at/below reorder level", stock.filter((s: any) => s.belowReorderLevel).length],
    ["Open inventory alerts", T("inventory-alerts").filter((a: any) => a.status === "Active").length],
    ["Returns in progress", scopeRows("product-returns", T("product-returns"), me).filter((r: any) => ["REQUESTED", "APPROVED", "SHIPPED"].includes(r.status)).length],
    ["Distributors in Recovery Mode", T("recovery-plans").filter((p: any) => p.recoveryMode && !p.closedAt && dists.some((d: any) => d.distributorId === p.distributorId)).length],
    ["Average health score", scores.length ? round2(scores.reduce((a: any, x: any) => a + num(x.h.totalScore), 0) / scores.length) : null],
    ["Lowest health score (distributor id)", lowest ? `${num(lowest.h.totalScore)} (${lowest.id})` : null]
  ].map(([metric, value]) => ({ metric, value }));
  return { title: "Dashboard", columns: ["metric", "value"], rows, totals: { generatedAt: isoTs(now()) } };
});

// ------------------------------------------------------------------ the mock request handler
function resolveCrud(path: any) {
  for (const key of resourceKeys) {
    if (path === key) return { key, id: null };
    if (path.startsWith(key + "/")) {
      const rest = path.slice(key.length + 1);
      if (!rest.includes("/")) return { key, id: decodeURIComponent(rest) };
    }
  }
  return null;
}
function authenticate(headers: any) {
  const auth = headers && headers.Authorization;
  if (!auth || !auth.startsWith("Basic ")) return null;
  const [email, ...pw] = atob(auth.slice(6)).split(":");
  const u = T("app-users").find((x: any) => x.email.toLowerCase() === email.toLowerCase());
  if (!u || u.passwordHash !== pw.join(":")) return null;
  return u;
}
async function mockRequest(method: string, rawPath: string, { query = {}, body = null, headers = {} }: RequestOptions = {}): Promise<MockResponse> {
  load();
  const [min, max] = environment.mockLatency || [0, 0];
  await new Promise((r) => setTimeout(r, min + Math.random() * (max - min)));
  const path = normalise(rawPath);
  const full = environment.apiPrefix + "/" + path;
  try {
    const publicPaths = ["auth/password-reset/request", "auth/password-reset/confirm"];
    let user = null;
    if (!publicPaths.includes(path)) {
      const s = session();
      user = headers['Authorization'] ? authenticate(headers) : s ? T("app-users").find((x: any) => x.userId === s.userId) : null;
      if (!user) fail(401, "UNAUTHORIZED", headers['Authorization'] ? "Wrong email or password" : "Sign in first");
      if (user.status !== "Active") fail(401, "UNAUTHORIZED", `This account is ${user.status}. Ask the System Admin to activate it`);
    }
    const me = user ? Object.assign(profileOf(user), { user }) : null;
    if (me && !me.roles.length && path !== "auth/me" && path !== "auth/login") fail(403, "ACCESS_DENIED", "Your account has no stakeholder role yet. Ask the System Admin to give you one");
    if (me) {
      const d = decide(method, path, me.roles);
      if (!d.allowed) fail(403, "ACCESS_DENIED", `Your role (${me.roles.join(", ") || "none"}) may not ${["GET", "HEAD"].includes(method) ? "read" : "change"} ${path}`);
    }
    const b = body || ({} as any);
    for (const r of R) {
      if (r.method !== method) continue;
      const mm = path.match(r.re);
      if (mm) {
        const res = r.handler(method, b, query, me, ...mm.slice(1).map(decodeURIComponent));
        const wrapped = res && res.data !== undefined && res.headers ? res : { data: res, headers: {} };
        return { status: method === "POST" && /\/(attachments)$/.test(path) ? 201 : wrapped.data == null ? 204 : 200, data: wrapped.data, headers: wrapped.headers, path: full };
      }
    }
    const c = resolveCrud(path);
    if (!c) return fail(404, "RESOURCE_NOT_FOUND", `No endpoint ${method} ${full}`);
    if (method === "GET" && c.id == null) { const r = list(c.key, query, me); return { status: 200, data: r.data, headers: r.headers, path: full }; }
    if (method === "GET") { const row = must(c.key, c.id); if (!scopeRows(c.key, [row], me).length) fail(403, "ACCESS_DENIED", "This record belongs to another distributor"); return { status: 200, data: out(row, c.key), headers: {}, path: full }; }
    if (method === "POST" && c.id == null) return { status: 201, data: create(c.key, b, me), headers: {}, path: full };
    if (method === "PUT" && c.id != null) return { status: 200, data: update(c.key, c.id, b, me), headers: {}, path: full };
    if (method === "DELETE" && c.id != null) return { status: 204, data: remove(c.key, c.id, me), headers: {}, path: full };
    return fail(405, "METHOD_NOT_ALLOWED", `${method} is not supported on ${full}`);
  } catch (e: any) {
    if (e instanceof ApiError) { e.path = full; e.body.path = full; throw e; }
    console.error(e);
    throw new ApiError(500, "INTERNAL_ERROR", "Something went wrong in the demo API: " + e.message, null, full);
  }
}


// ------------------------------------------------------------------ public service
@Injectable({ providedIn: 'root' })
export class MockApiService {
  /** Same contract as the backend: resolves with {status, data, headers} or rejects with ApiError. */
  request(method: string, path: string, opts: RequestOptions = {}): Promise<MockResponse> {
    return mockRequest(method, path, opts) as Promise<MockResponse>;
  }
  /** Checks the e-mail and password and returns the profile, like POST /auth/login with HTTP Basic. */
  login(email: string, password: string): Promise<MockResponse> {
    return mockRequest('POST', '/auth/login', { headers: { Authorization: 'Basic ' + btoa(`${email}:${password}`) } }) as Promise<MockResponse>;
  }
  resetDemo(): void { localStorage.removeItem(STORE_KEY); db = null; load(); }
  decide(method: string, path: string, roles: string[]) { return decide(method, path, roles); }
  validEan(code: string): boolean { return validEan(code); }
  normalise(path: string): string { return normalise(path); }
}
