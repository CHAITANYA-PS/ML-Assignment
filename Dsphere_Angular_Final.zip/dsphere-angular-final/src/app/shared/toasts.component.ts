/* The toast stack; placed once in the layout and in the login page. */
import { Component } from '@angular/core';
import { ToastService } from '../core/toast.service';

@Component({
  selector: 'app-toasts', standalone: true,
  template: `
  <div class="toasts" role="status" aria-live="polite">
    @for (t of toast.list(); track t.id) {
      <div class="toast {{ t.kind }}"><div>{{ t.text }}@if (t.detail) {<small>{{ t.detail }}</small>}</div></div>
    }
  </div>`
})
export class ToastsComponent { constructor(public toast: ToastService) {} }
