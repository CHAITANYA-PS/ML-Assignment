/*
 * Tabs (replaces DS.ui.tabs):
 *   <app-tabs [tabs]="[{ key: 'returns', label: 'Product returns' }, { key: 'exchange', label: 'Exchange requests' }]" [(active)]="tab" />
 *   @if (tab === 'returns') { … } @else { … }
 */
import { Component, EventEmitter, Input, Output } from '@angular/core';

export interface TabDef { key: string; label: string; count?: number; }

@Component({
  selector: 'app-tabs', standalone: true,
  template: `
  <div class="tabs" role="tablist">
    @for (t of tabs; track t.key) {
      <button type="button" role="tab" [class.active]="t.key === active" (click)="select(t.key)">{{ t.label }}@if (t.count != null) { <span class="badge">{{ t.count }}</span> }</button>
    }
  </div>`
})
export class TabsComponent {
  @Input() tabs: TabDef[] = [];
  @Input() active = '';
  @Output() activeChange = new EventEmitter<string>();
  select(key: string): void { this.active = key; this.activeChange.emit(key); }
}
