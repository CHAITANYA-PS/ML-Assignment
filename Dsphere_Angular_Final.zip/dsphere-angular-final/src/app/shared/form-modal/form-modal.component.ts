/*
 * Create / edit pop-up built from field specs (replaces DS.ui.formModal).
 *
 *   <app-form-modal title="New distributor" [fields]="fields" [value]="{}" [submit]="save" (closed)="show = false" />
 *   save = (v: any) => this.api.post('/distributors', v);      // a rejected promise shows the backend's message
 *
 * Client checks run first; the backend's fieldErrors are then shown under the matching fields.
 */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RefService } from '../../core/ref.service';
import { ModalComponent } from '../modal.component';
import { nice } from '../format';
import { FieldSpec, checkFields } from './form-fields';

@Component({
  selector: 'app-form-modal', standalone: true, imports: [FormsModule, ModalComponent],
  templateUrl: './form-modal.component.html'
})
export class FormModalComponent implements OnInit {
  @Input() title = '';
  @Input() sub?: string;
  @Input() fields: FieldSpec[] = [];
  @Input() value: Record<string, any> = {};
  @Input() mode: 'create' | 'edit' = 'create';
  @Input() submitLabel?: string;
  @Input() size: '' | 'wide' | 'narrow' = '';
  @Input() intro?: string;
  @Input() submit!: (value: Record<string, any>) => Promise<any>;
  @Output() closed = new EventEmitter<void>();
  @Output() saved = new EventEmitter<any>();

  model: Record<string, any> = {};
  errors: Record<string, string> = {};
  alert = '';
  busy = false;
  ready = false;

  constructor(public ref: RefService) {}

  async ngOnInit(): Promise<void> {
    await this.ref.ensure([...new Set(this.fields.filter(f => f.ref).map(f => f.ref!))]);
    this.model = {};
    for (const f of this.fields) {
      const v = this.value[f.name] ?? f.default ?? (f.type === 'checkbox' ? false : '');
      this.model[f.name] = f.type === 'datetime' && v ? String(v).slice(0, 16) : v;
    }
    this.ready = true;
  }

  options(f: FieldSpec): [any, string][] {
    if (f.options) return f.options.map(o => (Array.isArray(o) ? o : [o, nice(o)]));
    return f.ref ? this.ref.options(f.ref) : [];
  }
  inputType(f: FieldSpec): string {
    return f.type === 'number' || f.type === 'decimal' ? 'number' : f.type === 'datetime' ? 'datetime-local' : f.type || 'text';
  }
  clearError(name: string): void { delete this.errors[name]; }
  /** Opens the calendar when a date field is clicked anywhere (not only on the small calendar icon). */
  openPicker(ev: Event, f: FieldSpec): void {
    if (f.readonly || (f.type !== 'date' && f.type !== 'datetime')) return;
    const el = ev.target as HTMLInputElement & { showPicker?: () => void };
    try { el.showPicker?.(); if (ev.type === 'keydown') ev.preventDefault(); } catch { /* the browser has no picker or blocks it: typing still works */ }
  }

  /** Values in the types the backend expects (numbers as numbers, empty as null, version kept). */
  private values(): Record<string, any> {
    const out: Record<string, any> = {};
    for (const f of this.fields) {
      let v = this.model[f.name];
      if (v === '' || v === undefined) v = null;
      else if (f.type === 'number' || f.type === 'decimal') v = Number(v);
      else if (f.type === 'select' && f.ref && /^-?\d+$/.test(String(v))) v = Number(v);
      else if (f.type === 'datetime' && String(v).length === 16) v = v + ':00+05:30';
      out[f.name] = v;
    }
    if (this.value['version'] != null) out['version'] = this.value['version'];
    return out;
  }

  async save(): Promise<void> {
    if (this.busy) return;
    this.alert = '';
    const v = this.values();
    this.errors = checkFields(this.fields, v, this.mode);
    if (Object.keys(this.errors).length) { this.alert = 'Please fix the highlighted fields.'; return; }
    this.busy = true;
    try {
      const r = await this.submit(v);
      this.saved.emit(r);
      this.closed.emit();
    } catch (e: any) {
      const fe: Record<string, string> = e?.fieldErrors || {};
      for (const [k, m] of Object.entries(fe)) {
        const f = this.fields.find(x => x.name === k);
        if (f && m) this.errors[k] = /^(is|must|has|does|already)\b/.test(m) ? `${f.label || k} ${m}` : m;
      }
      const marked = Object.keys(fe).some(k => this.fields.some(x => x.name === k));
      this.alert = marked && /^Please check/.test(e?.message || '') ? 'Please fix the highlighted fields.' : (e?.message || 'Something went wrong. Please try again.');
    } finally {
      this.busy = false;
    }
  }
}
