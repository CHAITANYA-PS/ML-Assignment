/* Field definitions for <app-form-modal>, built from the backend DTO rules in core/schema.ts (replaces the form part of ui.js). */
import { SCHEMA } from '../../core/schema';
import { fmt } from '../format';

export type FieldType = 'text' | 'number' | 'decimal' | 'date' | 'datetime' | 'email' | 'password' | 'textarea' | 'select' | 'checkbox';

export interface FieldSpec {
  name: string;
  label?: string;
  type?: FieldType;
  required?: boolean;
  /** Max length for text. */
  max?: number;
  /** Lowest and highest number. */
  min?: number;
  maxValue?: number;
  positive?: boolean;
  zeroOrMore?: boolean;
  email?: boolean;
  pattern?: string;
  patternMessage?: string;
  /** Fixed choices: ['Active', 'Pending'] or [[1, 'Placed']]. */
  options?: (string | [any, string])[];
  /** Choices from a reference list, e.g. 'distributors'. */
  ref?: string;
  hint?: string;
  placeholder?: string;
  full?: boolean;
  readonly?: boolean;
  default?: any;
  mono?: boolean;
  /** Extra check: return a message to show, or null. */
  validate?: (value: any, all: Record<string, any>) => string | null;
}

/**
 * Builds field specs from the backend schema, with your overrides:
 *   fieldsFor('distributors', ['distributorCode', 'distributorName', { name: 'address', full: true }])
 */
export function fieldsFor(resource: string, fields: (string | FieldSpec)[]): FieldSpec[] {
  const r = SCHEMA.resources[resource];
  return fields.map(f => {
    const base: FieldSpec = typeof f === 'string' ? { name: f } : { ...f };
    const sf = r?.fields.find(x => x.name === base.name);
    if (!sf) return { label: fmt.label(base.name), type: 'text', ...base };
    const type: FieldType = sf.options || sf.refPath ? 'select'
      : sf.type === 'Boolean' ? 'checkbox'
      : sf.type === 'LocalDate' ? 'date'
      : sf.type === 'OffsetDateTime' || sf.type === 'LocalDateTime' ? 'datetime'
      : sf.type === 'BigDecimal' ? 'decimal'
      : sf.type === 'Long' || sf.type === 'Integer' ? 'number'
      : sf.email ? 'email'
      : sf.type === 'String' && sf.max && sf.max > 255 ? 'textarea' : 'text';
    return {
      label: sf.label.replace(/ id$/i, ''), type, required: sf.required, max: sf.max, email: sf.email, positive: sf.positive,
      zeroOrMore: sf.zeroOrMore, pattern: sf.pattern, options: sf.options, ref: sf.refPath,
      min: sf.min != null ? Number(sf.min) : undefined, maxValue: sf.maxValue != null ? Number(sf.maxValue) : undefined,
      ...base
    };
  });
}

/** Checks the values the same way the backend does; returns field -> message. */
export function checkFields(specs: FieldSpec[], v: Record<string, any>, mode: 'create' | 'edit'): Record<string, string> {
  const errs: Record<string, string> = {};
  for (const s of specs) {
    const x = v[s.name];
    const isEmpty = x == null || x === '';
    const label = s.label || s.name;
    if (s.required && isEmpty && s.type !== 'checkbox' && !(mode === 'edit' && s.readonly)) errs[s.name] = `${label} is required`;
    else if (!isEmpty && s.max && String(x).length > s.max) errs[s.name] = `${label} must be at most ${s.max} characters`;
    else if (!isEmpty && (s.email || s.type === 'email') && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(x))) errs[s.name] = `${label} must be a valid email address`;
    else if (!isEmpty && s.pattern && !new RegExp('^(?:' + s.pattern + ')$').test(String(x))) errs[s.name] = s.patternMessage || `${label} has an invalid format`;
    else if (!isEmpty && s.positive && Number(x) <= 0) errs[s.name] = `${label} must be greater than 0`;
    else if (!isEmpty && s.zeroOrMore && Number(x) < 0) errs[s.name] = `${label} must be 0 or greater`;
    else if (!isEmpty && s.min != null && Number(x) < s.min) errs[s.name] = `${label} must be at least ${s.min}`;
    else if (!isEmpty && s.maxValue != null && Number(x) > s.maxValue) errs[s.name] = `${label} must be at most ${s.maxValue}`;
    else if (s.validate) { const m = s.validate(x, v); if (m) errs[s.name] = m; }
  }
  return errs;
}

/** A form opened by a page: set it to show <app-form-modal>, set it to null to close. */
export interface FormState {
  title: string; sub?: string; intro?: string; fields: FieldSpec[]; value?: Record<string, any>;
  submitLabel?: string; size?: '' | 'wide' | 'narrow'; submit: (v: any) => Promise<any>;
}
