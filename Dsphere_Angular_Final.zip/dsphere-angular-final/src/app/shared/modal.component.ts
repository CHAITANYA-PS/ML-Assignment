/*
 * Pop-up and side drawer (replaces DS.ui.modal and DS.ui.drawer).
 *   <app-modal title="New order" (closed)="show = false"> body … <div foot> buttons </div> </app-modal>
 *   <app-modal [drawer]="true" …> for the side panel.
 */
import { Component, EventEmitter, HostListener, Input, Output } from '@angular/core';

@Component({
  selector: 'app-modal', standalone: true,
  template: `
  <div class="overlay" [class.drawer-overlay]="drawer" (mousedown)="backdrop($event)">
    <div [class]="drawer ? 'drawer' : 'modal ' + size" role="dialog" aria-modal="true" [attr.aria-label]="title">
      <div class="modal-head">
        <div><h3>{{ title }}</h3>@if (sub) { <p>{{ sub }}</p> }</div>
        <button class="icon-btn" type="button" aria-label="Close" (click)="closed.emit()">✕</button>
      </div>
      <div class="modal-body"><ng-content /></div>
      <div class="modal-foot"><span class="spacer"></span><ng-content select="[foot]" /></div>
    </div>
  </div>`
})
export class ModalComponent {
  @Input() title = '';
  @Input() sub?: string;
  @Input() drawer = false;
  /** '', 'wide' or 'narrow' (classes in dsphere.css). */
  @Input() size: '' | 'wide' | 'narrow' = '';
  @Output() closed = new EventEmitter<void>();

  @HostListener('document:keydown.escape') onEscape(): void { this.closed.emit(); }
  backdrop(e: MouseEvent): void { if (e.target === e.currentTarget) this.closed.emit(); }
}
