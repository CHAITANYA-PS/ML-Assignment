/* Progress bar: <app-meter [pct]="72" /> (green from 80%, amber from 50%, red below; or a fixed tone). */
import { Component, Input } from '@angular/core';
import { fmt } from './format';

@Component({
  selector: 'app-meter', standalone: true,
  template: `<div class="meter {{ cls }}" [title]="label"><i [style.width.%]="width"></i></div>`
})
export class MeterComponent {
  @Input() pct: number | null | undefined = 0;
  @Input() tone?: string;
  get value(): number { return Number(this.pct) || 0; }
  get width(): number { return Math.max(0, Math.min(100, this.value)); }
  get cls(): string { return this.tone || (this.value >= 80 ? 'ok' : this.value >= 50 ? 'warn' : 'danger'); }
  get label(): string { return fmt.pct(this.value, 1); }
}
