/* Draws a chart string from charts.ts: <app-chart [html]="ordersChart" />. The SVG is built by our own code from numbers, so it is trusted. */
import { Component, Input } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({ selector: 'app-chart', standalone: true, template: `<div [innerHTML]="safe"></div>` })
export class ChartComponent {
  safe: SafeHtml = '';
  constructor(private sanitizer: DomSanitizer) {}
  @Input() set html(v: string) { this.safe = this.sanitizer.bypassSecurityTrustHtml(v || ''); }
}
