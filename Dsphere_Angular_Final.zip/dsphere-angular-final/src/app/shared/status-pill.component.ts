/* <app-pill [value]="status" /> or <app-pill value="High" tone="danger" /> (replaces DS.ui.pill). */
import { Component, Input } from '@angular/core';
import { nice, toneOf } from './format';

@Component({
  selector: 'app-pill', standalone: true,
  template: `@if (value == null || value === '') { <span class="muted">–</span> } @else { <span class="pill {{ tone || toneOf(value) }}">{{ nice(value) }}</span> }`
})
export class StatusPillComponent {
  @Input() value: any;
  @Input() tone?: string;
  toneOf = toneOf;
  nice = nice;
}
