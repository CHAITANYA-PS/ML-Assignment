/* Shows ConfirmService questions; placed once in the layout. */
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ConfirmService } from '../core/confirm.service';
import { ModalComponent } from './modal.component';

@Component({
  selector: 'app-confirm-dialog', standalone: true, imports: [FormsModule, ModalComponent],
  template: `
  @if (confirm.current(); as c) {
    <app-modal [title]="c.title" size="narrow" (closed)="cancel()">
      @if (c.text) { <p class="muted" style="margin:0">{{ c.text }}</p> }
      @if (c.input) {
        <div class="field mt">
          <label>{{ c.input.label }}@if (c.input.required) { <span class="req"> *</span> }</label>
          <textarea class="input" rows="3" [class.invalid]="error" [attr.maxlength]="c.input.max || 500" [placeholder]="c.input.placeholder || ''" [(ngModel)]="text" name="text"></textarea>
          <div class="error">{{ error }}</div>
        </div>
      }
      <div foot>
        <button class="btn ghost" type="button" (click)="cancel()">Cancel</button>
        <button class="btn {{ c.tone || 'primary' }}" type="button" (click)="ok()">{{ c.okLabel || 'Confirm' }}</button>
      </div>
    </app-modal>
  }`
})
export class ConfirmDialogComponent {
  text = '';
  error = '';
  constructor(public confirm: ConfirmService) {}
  ok(): void {
    const c = this.confirm.current();
    if (!c) return;
    if (c.input) {
      const v = this.text.trim();
      if (c.input.required && !v) { this.error = `${c.input.label} is required`; return; }
      this.reset(); this.confirm.close(v);
    } else { this.reset(); this.confirm.close(true); }
  }
  cancel(): void { const c = this.confirm.current(); this.reset(); this.confirm.close(c?.input ? null : false); }
  private reset(): void { this.text = ''; this.error = ''; }
}
