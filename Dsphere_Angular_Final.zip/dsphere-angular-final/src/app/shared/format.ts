/* Number, money and date formatting plus status colours (replaces DS.ui.fmt, DS.ui.toneOf, DS.ui.nice). */
import { environment } from '../../environments/environment';

const nf = new Intl.NumberFormat(environment.locale);
const nf2 = new Intl.NumberFormat(environment.locale, { maximumFractionDigits: 2 });
const mf = new Intl.NumberFormat(environment.locale, { style: 'currency', currency: environment.currency, maximumFractionDigits: 0 });
const empty = (v: unknown) => v == null || v === '';
const toDate = (v: string) => new Date(String(v).length === 10 ? v + 'T00:00:00' : v);

export const fmt = {
  num: (v: any) => (empty(v) ? '–' : nf.format(Math.round(Number(v)))),
  dec: (v: any) => (empty(v) ? '–' : nf2.format(Number(v))),
  money: (v: any) => (empty(v) ? '–' : mf.format(Number(v))),
  moneyShort(v: any): string {
    if (empty(v)) return '–';
    const n = Number(v), a = Math.abs(n);
    if (a >= 1e7) return '₹' + nf2.format(n / 1e7) + ' Cr';
    if (a >= 1e5) return '₹' + nf2.format(n / 1e5) + ' L';
    if (a >= 1e3) return '₹' + nf2.format(n / 1e3) + 'K';
    return mf.format(n);
  },
  pct: (v: any, d = 0) => (empty(v) ? '–' : `${Number(v).toFixed(d)}%`),
  date(v: any): string {
    if (!v) return '–';
    const d = toDate(v);
    return isNaN(+d) ? String(v) : d.toLocaleDateString(environment.locale, { day: '2-digit', month: 'short', year: 'numeric' });
  },
  dateTime(v: any): string {
    if (!v) return '–';
    const d = new Date(v);
    return isNaN(+d) ? String(v) : d.toLocaleString(environment.locale, { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  },
  ago(v: any): string {
    if (!v) return '–';
    const s = (Date.now() - new Date(v).getTime()) / 1000, a = Math.abs(s);
    const f = (n: number, u: string) => `${Math.round(n)} ${u}${Math.round(n) === 1 ? '' : 's'} ${s < 0 ? 'from now' : 'ago'}`;
    if (a < 60) return 'just now';
    if (a < 3600) return f(a / 60, 'minute');
    if (a < 86400) return f(a / 3600, 'hour');
    if (a < 86400 * 30) return f(a / 86400, 'day');
    return fmt.date(v);
  },
  daysTo(v: any): number | null {
    if (!v) return null;
    return Math.round((toDate(String(v).slice(0, 10)).getTime() - new Date(new Date().toDateString()).getTime()) / 86400000);
  },
  bytes: (v: any) => (v == null ? '–' : v > 1048576 ? (v / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(v / 1024)) + ' KB'),
  initials: (name: any) => String(name || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(x => x[0].toUpperCase()).join(''),
  label: (key: string) => String(key).replace(/Id$/, '').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^./, c => c.toUpperCase())
};

/** "NEAR_EXPIRY" -> "Near expiry"; other text unchanged. */
export function nice(v: any): string {
  const s = String(v ?? '');
  return /^[A-Z_]+$/.test(s) ? s.replace(/_/g, ' ').toLowerCase().replace(/^./, c => c.toUpperCase()) : s;
}

const TONES: Record<string, string[]> = {
  ok: ['active', 'delivered', 'paid', 'completed', 'approved', 'verified', 'match', 'received', 'achieved', 'resolved', 'success', 'low', 'on_track', 'stable', 'recovered', 'ok', 'true', 'yes', 'allowed', 'valid', 'sellable', 'low risk', 'up', 'stock_sell'],
  warn: ['pending', 'processing', 'in progress', 'partially paid', 'submitted', 'requested', 'near_expiry', 'medium', 'watch', 'on hold', 'shipped', 'reopened', 'placed', 'partially_recovered', 'medium risk', 'at risk', 'pre_sell'],
  danger: ['suspended', 'cancelled', 'overdue', 'failed', 'rejected', 'expired', 'high', 'critical', 'mismatch', 'recovery', 'missed', 'discontinued', 'not_recovered', 'high risk', 'false', 'no', 'refused', 'invalid', 'down', 'breached', 'shortage', 'damaged'],
  info: ['dispatched', 'in transit', 'open', 'created', 'new', 'super admin', 'senior'],
  neutral: ['inactive', 'closed', 'standard', 'unknown']
};
/** Colour of a status pill: ok, warn, danger, info or neutral (same classes as dsphere.css). */
export function toneOf(v: any): string {
  const s = String(v ?? '').toLowerCase();
  for (const [tone, words] of Object.entries(TONES)) if (words.includes(s)) return tone;
  return 'neutral';
}
export const todayIso = (): string => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

/** Saves a Blob as a file (exports, attachments). */
export function saveFile(name: string, blob: Blob): void {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name || 'download';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
