/* Shows its element only when the role may call the endpoint: <button *appCan="['POST', '/tickets']">Raise ticket</button>. */
import { Directive, Input, TemplateRef, ViewContainerRef, effect } from '@angular/core';
import { AuthService } from '../core/auth.service';

@Directive({ selector: '[appCan]', standalone: true })
export class CanDirective {
  private rule: [string, string] = ['GET', '/'];
  private shown = false;

  constructor(private tpl: TemplateRef<any>, private vcr: ViewContainerRef, private auth: AuthService) {
    effect(() => { this.auth.mine(); this.render(); });
  }
  @Input() set appCan(rule: [string, string]) { this.rule = rule; this.render(); }

  private render(): void {
    const ok = this.auth.can(this.rule[0], this.rule[1]);
    if (ok && !this.shown) { this.vcr.createEmbeddedView(this.tpl); this.shown = true; }
    if (!ok && this.shown) { this.vcr.clear(); this.shown = false; }
  }
}
