/* <app-icon name="truck" /> (replaces DS.ui.icon). */
import { Component, Input } from '@angular/core';
import { ICONS } from './icons';

@Component({
  selector: 'app-icon', standalone: true,
  template: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path [attr.d]="path"/></svg>`,
  host: { style: 'display:inline-flex' }
})
export class IconComponent {
  @Input() name = 'info';
  get path(): string { return ICONS[this.name] ?? ICONS['info']; }
}
