/* Column, filter and row-action definitions for <app-data-table>. */
export type ColumnType = 'text' | 'strong' | 'mono' | 'money' | 'num' | 'pct' | 'date' | 'dateTime' | 'ago' | 'pill' | 'ref' | 'status' | 'bool' | 'html';

export interface Column {
  /** Field of the row (also the sort key). */
  key: string;
  label: string;
  type?: ColumnType;
  /** For 'ref' and 'status': the resource whose name is shown, e.g. 'distributors' or 'order-statuses'. */
  ref?: string;
  /** Computed value instead of row[key]. */
  value?: (row: any) => any;
  /** Small grey second line under the value. */
  sub?: (row: any) => string;
  /** Pill colour override for 'pill' / 'status'. */
  tone?: (row: any) => string | undefined;
  /** For type 'html': markup built with esc() (spans, pills, meters). */
  html?: (row: any) => string;
  sortable?: boolean;
}

export interface Filter {
  key: string;
  label: string;
  /** Fixed values: ['Active', 'Pending'] or [[1, 'Placed'], [2, 'Approved']]. */
  options?: (string | [any, string])[];
  /** Or the values of a reference list, e.g. 'order-statuses'. */
  ref?: string;
}

export interface RowAction {
  label: string;
  tone?: 'primary' | 'danger' | 'ghost' | '';
  /** Hide the button for some rows (wrong status, role not allowed …). */
  show?: (row: any) => boolean;
  run: (row: any) => void;
}

/** Escapes text for Column.html. */
export const esc = (v: any): string => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } as Record<string, string>)[c]);
