/*
 * The list used by almost every page (replaces DS.ui.table): server-side paging, sorting, filters and search,
 * skeleton while loading, empty and error states.
 *
 *   <app-data-table path="/distributor-orders" [columns]="columns" [filters]="filters" searchField="orderNumber"
 *                   sort="orderDate,desc" (rowClick)="open($event)" [actions]="actions">
 *     <button tools class="btn sm primary">New order</button>
 *   </app-data-table>
 *
 * Search sends a real field filter (searchField), because the backend refuses unknown filters.
 * For computed endpoints (e.g. /stocks/current) pass [source] instead of path: paging then happens in the browser.
 */
import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { environment } from '../../../environments/environment';
import { ApiService, Query } from '../../core/api.service';
import { RefService } from '../../core/ref.service';
import { fmt, nice, toneOf } from '../format';
import { Column, Filter, RowAction } from './data-table.types';

@Component({
  selector: 'app-data-table', standalone: true, imports: [FormsModule],
  templateUrl: './data-table.component.html'
})
export class DataTableComponent implements OnInit, OnChanges {
  @Input() path?: string;
  @Input() source?: (query: Query) => Promise<any[]>;
  @Input() query: Query = {};
  @Input() columns: Column[] = [];
  @Input() filters: Filter[] = [];
  @Input() actions: RowAction[] = [];
  @Input() sort?: string;
  @Input() pageSize = environment.pageSize;
  @Input() searchField?: string;
  @Input() searchPlaceholder = 'Search';
  @Input() emptyTitle = 'Nothing here yet';
  @Input() emptyText = '';
  @Input() initialFilters: Record<string, any> = {};
  @Output() rowClick = new EventEmitter<any>();

  rows: any[] = [];
  total = 0;
  page = 0;
  q = '';
  values: Record<string, any> = {};
  loading = true;
  error: any = null;
  private seq = 0;
  private cache: any[] | null = null;
  private searchTimer: any;

  private htmlCache = new Map<string, SafeHtml>();

  constructor(private api: ApiService, public ref: RefService, private sanitizer: DomSanitizer) {}

  /** Column.html is built by the page with esc(), so it is trusted (keeps the inline widths of meters). */
  html(c: Column, row: any): SafeHtml {
    const s = c.html ? c.html(row) : '';
    let v = this.htmlCache.get(s);
    if (!v) { v = this.sanitizer.bypassSecurityTrustHtml(s); if (this.htmlCache.size > 500) this.htmlCache.clear(); this.htmlCache.set(s, v); }
    return v;
  }

  async ngOnInit(): Promise<void> {
    this.values = { ...this.initialFilters };
    for (const f of this.filters) if (this.values[f.key] == null) this.values[f.key] = '';
    const refs = [...this.columns.filter(c => c.ref).map(c => c.ref!), ...this.filters.filter(f => f.ref).map(f => f.ref!)];
    await this.ref.ensure([...new Set(refs)]);
    await this.load();
  }
  ngOnChanges(): void {
    for (const f of this.filters) if (this.values[f.key] == null) this.values[f.key] = '';
    if (this.rows.length || this.error) this.reload();
  }

  /** Reloads the current page (keepPage) or goes back to page 1. */
  reload(keepPage = false): Promise<void> { this.cache = null; if (!keepPage) this.page = 0; return this.load(); }

  options(f: Filter): [any, string][] {
    if (f.options) return f.options.map(o => (Array.isArray(o) ? o : [o, nice(o)]));
    return f.ref ? this.ref.options(f.ref) : [];
  }
  onFilter(): void { this.page = 0; this.cache = null; this.load(); }
  clearSearch(ev?: Event): void { ev?.stopPropagation(); this.q = ''; clearTimeout(this.searchTimer); this.page = 0; this.load(); }
  onSearch(): void { clearTimeout(this.searchTimer); this.searchTimer = setTimeout(() => { this.page = 0; this.load(); }, 260); }
  sortBy(c: Column): void {
    if (c.sortable === false || c.value || c.html) return;
    const [k, d] = (this.sort || '').split(',');
    this.sort = `${c.key},${k === c.key && d !== 'desc' ? 'desc' : 'asc'}`;
    this.page = 0;
    this.load();
  }
  arrow(c: Column): string { const [k, d] = (this.sort || '').split(','); return k === c.key ? (d === 'desc' ? ' ↓' : ' ↑') : ''; }
  prev(): void { this.page--; this.load(); }
  next(): void { this.page++; this.load(); }
  get from(): number { return this.total ? this.page * this.pageSize + 1 : 0; }
  get to(): number { return Math.min(this.total, (this.page + 1) * this.pageSize); }
  get pages(): number { return Math.max(1, Math.ceil(this.total / this.pageSize)); }
  visibleActions(row: any): RowAction[] { return this.actions.filter(a => !a.show || a.show(row)); }
  runAction(a: RowAction, row: any, e: Event): void { e.stopPropagation(); a.run(row); }

  // ---------------------------------------------------------------- cell rendering
  raw(c: Column, row: any): any { return c.value ? c.value(row) : row[c.key]; }
  text(c: Column, row: any): string {
    const v = this.raw(c, row);
    switch (c.type) {
      case 'money': return fmt.money(v);
      case 'num': return fmt.dec(v);
      case 'pct': return fmt.pct(v);
      case 'date': return fmt.date(v);
      case 'dateTime': return fmt.dateTime(v);
      case 'ago': return fmt.ago(v);
      case 'ref': case 'status': return this.ref.name(c.ref!, v);
      case 'pill': return nice(v);
      default: return v == null || v === '' ? '–' : String(v);
    }
  }
  tone(c: Column, row: any): string { return (c.tone && c.tone(row)) || toneOf(this.text(c, row)); }
  isNum(c: Column): boolean { return c.type === 'money' || c.type === 'num' || c.type === 'pct'; }

  // ---------------------------------------------------------------- loading
  private async load(): Promise<void> {
    const seq = ++this.seq;
    this.loading = true;
    this.error = null;
    try {
      if (this.source) {
        if (!this.cache) this.cache = await this.source({ ...this.query });
        let all = this.cache.slice();
        for (const [k, v] of Object.entries(this.values)) if (v !== '' && v != null) all = all.filter(r => String(r[k]) === String(v));
        if (this.q) { const q = this.q.toLowerCase(); all = all.filter(r => Object.values(r).some(x => x != null && typeof x !== 'object' && String(x).toLowerCase().includes(q))); }
        if (this.sort) {
          const [k, d] = this.sort.split(','); const sg = d === 'desc' ? -1 : 1;
          all.sort((a, b) => (a[k] == null ? 1 : b[k] == null ? -1 : typeof a[k] === 'number' ? (a[k] - b[k]) * sg : String(a[k]).localeCompare(String(b[k]), undefined, { numeric: true }) * sg));
        }
        if (seq !== this.seq) return;
        this.total = all.length;
        this.rows = all.slice(this.page * this.pageSize, (this.page + 1) * this.pageSize);
      } else if (this.path) {
        const q: Query = { ...this.query, ...this.values, page: this.page, size: this.pageSize };
        if (this.sort) q['sort'] = this.sort;
        if (this.q && this.searchField) q[this.searchField] = this.q;
        Object.keys(q).forEach(k => (q[k] === '' || q[k] == null) && delete q[k]);
        const r = await this.api.page(this.path, q);
        if (seq !== this.seq) return;
        this.rows = r.rows;
        this.total = r.total;
      }
    } catch (e) {
      if (seq !== this.seq) return;
      this.error = e;
      this.rows = [];
      this.total = 0;
    } finally {
      if (seq === this.seq) this.loading = false;
    }
  }
}
