/* Template formatting: {{ amount | money }}, {{ d | dateIn }}, {{ t | ago }} … (replace fmt.* calls in templates). */
import { Pipe, PipeTransform } from '@angular/core';
import { fmt, nice } from './format';

@Pipe({ name: 'money', standalone: true }) export class MoneyPipe implements PipeTransform { transform(v: any) { return fmt.money(v); } }
@Pipe({ name: 'moneyShort', standalone: true }) export class MoneyShortPipe implements PipeTransform { transform(v: any) { return fmt.moneyShort(v); } }
@Pipe({ name: 'num', standalone: true }) export class NumPipe implements PipeTransform { transform(v: any) { return fmt.num(v); } }
@Pipe({ name: 'dec', standalone: true }) export class DecPipe implements PipeTransform { transform(v: any) { return fmt.dec(v); } }
@Pipe({ name: 'pct', standalone: true }) export class PctPipe implements PipeTransform { transform(v: any, d = 0) { return fmt.pct(v, d); } }
@Pipe({ name: 'dateIn', standalone: true }) export class DateInPipe implements PipeTransform { transform(v: any) { return fmt.date(v); } }
@Pipe({ name: 'dateTimeIn', standalone: true }) export class DateTimeInPipe implements PipeTransform { transform(v: any) { return fmt.dateTime(v); } }
@Pipe({ name: 'ago', standalone: true }) export class AgoPipe implements PipeTransform { transform(v: any) { return fmt.ago(v); } }
@Pipe({ name: 'nice', standalone: true }) export class NicePipe implements PipeTransform { transform(v: any) { return nice(v); } }
@Pipe({ name: 'initials', standalone: true }) export class InitialsPipe implements PipeTransform { transform(v: any) { return fmt.initials(v); } }

/** Import this one array into a component to get every pipe. */
export const FORMAT_PIPES = [MoneyPipe, MoneyShortPipe, NumPipe, DecPipe, PctPipe, DateInPipe, DateTimeInPipe, AgoPipe, NicePipe, InitialsPipe];
