/* <app-kpi label="Open orders" [value]="12" foot="of 40" tone="warn" /> (replaces DS.ui.kpi). */
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-kpi', standalone: true,
  template: `
  <div class="kpi" [class]="'kpi ' + (tone ? 'tone-' + tone : '')">
    <div class="kpi-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path [attr.d]="iconPath"/></svg></div>
    <div><div class="kpi-label">{{ label }}</div><div class="kpi-value">{{ value }}@if (unit) {<small>{{ unit }}</small>}</div>
      @if (foot) { <div class="kpi-foot">{{ foot }}</div> }</div>
  </div>`
})
export class KpiCardComponent {
  @Input() label = '';
  @Input() value: string | number | null = '';
  @Input() unit?: string;
  @Input() foot?: string;
  @Input() tone?: 'ok' | 'warn' | 'danger' | 'info' | null;
  /** SVG path of the icon (see shared/icons.ts). */
  @Input() iconPath = 'M4 20V4M4 20h16M8 16v-4M12 16V8M16 16v-6M20 16v-9';
}
