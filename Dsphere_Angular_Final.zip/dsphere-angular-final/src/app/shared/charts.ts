/* SVG charts as strings (replaces DS.ui.barChart, lineChart, donut, hbars, meter). Draw them with <app-chart [html]="…" />. */
import { fmt } from './format';

const esc = (v: any) => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } as Record<string, string>)[c]);
const nf2 = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 });
const num = (v: any) => (v == null || v === '' ? 0 : Number(v));
export interface Series { name?: string; values: (number | null)[]; color?: string; dashed?: boolean; noArea?: boolean; }
export interface DonutItem { label: string; value: number; color?: string; }
export interface BarItem { label: string; labelHtml?: string; value: number; tone?: string; }
export const meter = (pct: number, tone?: string) => `<div class="meter ${tone || (pct >= 80 ? 'ok' : pct >= 50 ? 'warn' : 'danger')}" title="${fmt.pct(pct, 1)}"><i style="width:${Math.max(0, Math.min(100, num(pct)))}%"></i></div>`;

export const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)", "var(--chart-6)"];
function niceMax(v: number): number { if (v <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(v))); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p; }
export function barChart({ labels, series, height = 220, format = fmt.num, stacked = false, target, wide }: { labels: string[]; series: Series[]; height?: number; format?: (v: any) => string; stacked?: boolean; target?: number; wide?: boolean }): string {
  const W = wide ? 1100 : 640, H = height, L = 46, B = 26, T = 12, R = 8;
  const totals = labels.map((_, i) => (stacked ? series.reduce((a, s) => a + num(s.values[i]), 0) : Math.max(...series.map((s) => num(s.values[i])))));
  const max = niceMax(Math.max(...totals, target || 0));
  const pw = (W - L - R) / labels.length, bw = Math.min(34, (pw * 0.62) / (stacked ? 1 : series.length));
  const y = (v: any) => T + (H - T - B) * (1 - v / max);
  let g = "";
  for (let i = 0; i <= 4; i++) { const v = (max / 4) * i; g += `<line class="grid-line" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"/><text class="lbl" x="${L - 8}" y="${y(v) + 4}" text-anchor="end">${esc(fmtAxis(v, format))}</text>`; }
  labels.forEach((lab, i) => {
    const cx = L + pw * i + pw / 2;
    let acc = 0;
    series.forEach((s, j) => {
      const v = num(s.values[i]);
      const x = stacked ? cx - bw / 2 : cx - (bw * series.length) / 2 + j * bw;
      const y0 = stacked ? y(acc + v) : y(v), h = stacked ? y(acc) - y(acc + v) : H - B - y(v);
      acc += v;
      g += `<rect class="bar" x="${x + 1}" y="${y0}" width="${Math.max(bw - 2, 2)}" height="${Math.max(h, 0)}" rx="4" fill="${s.color || COLORS[j % 6]}"><title>${esc(s.name ? s.name + ": " : "")}${esc(lab)} · ${esc(format(v))}</title></rect>`;
    });
    g += `<text class="lbl" x="${cx}" y="${H - 8}" text-anchor="middle">${esc(lab)}</text>`;
  });
  if (target) g += `<line x1="${L}" x2="${W - R}" y1="${y(target)}" y2="${y(target)}" stroke="var(--danger)" stroke-dasharray="5 4" stroke-width="1.5"/><text class="lbl" x="${W - R}" y="${y(target) - 5}" text-anchor="end" style="fill:var(--danger)">Target ${esc(format(target))}</text>`;
  return `<div class="chart"><svg viewBox="0 0 ${W} ${H}" role="img">${g}</svg>${legend(series)}</div>`;
}
function fmtAxis(v: number, f: (v: any) => string): string { if (f === fmt.money || f === fmt.moneyShort) return fmt.moneyShort(v); if (v >= 1000) return nf2.format(v / 1000) + "K"; return nf2.format(v); }
function legend(series: Series[]): string { return series.length > 1 || (series[0] && series[0].name) ? `<div class="chart-legend">${series.map((s, j) => `<span><i style="background:${s.color || COLORS[j % 6]}"></i>${esc(s.name || "")}</span>`).join("")}</div>` : ""; }
export function lineChart({ labels, series, height = 220, format = fmt.num, min = 0, maxValue, bands, wide }: { labels: string[]; series: Series[]; height?: number; format?: (v: any) => string; min?: number; maxValue?: number; bands?: { from: number; to: number; color: string }[]; wide?: boolean }): string {
  const W = wide ? 1100 : 640, H = height, L = 46, B = 26, T = 12, R = 12;
  const all = series.flatMap((s) => s.values.filter((v) => v != null).map(Number));
  const max = maxValue || niceMax(Math.max(...all, 1));
  const x = (i: any) => L + ((W - L - R) * i) / Math.max(labels.length - 1, 1);
  const y = (v: any) => T + (H - T - B) * (1 - (v - min) / (max - min));
  let g = "";
  if (bands) bands.forEach((b) => { g += `<rect x="${L}" width="${W - L - R}" y="${y(b.to)}" height="${y(b.from) - y(b.to)}" fill="${b.color}" opacity=".5"/>`; });
  for (let i = 0; i <= 4; i++) { const v = min + ((max - min) / 4) * i; g += `<line class="grid-line" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"/><text class="lbl" x="${L - 8}" y="${y(v) + 4}" text-anchor="end">${esc(fmtAxis(v, format))}</text>`; }
  const every = Math.ceil(labels.length / 8);
  labels.forEach((lab, i) => { if (i % every === 0 || i === labels.length - 1) g += `<text class="lbl" x="${x(i)}" y="${H - 8}" text-anchor="middle">${esc(lab)}</text>`; });
  series.forEach((s, j) => {
    const c = s.color || COLORS[j % 6];
    const pts = s.values.map((v, i) => (v == null ? null : [x(i), y(Number(v))])).filter((p): p is number[] => p != null);
    if (!pts.length) return;
    const d = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
    if (j === 0 && !s.noArea) g += `<path d="${d} L${pts[pts.length - 1][0]} ${H - B} L${pts[0][0]} ${H - B}Z" fill="${c}" opacity=".10"/>`;
    g += `<path d="${d}" fill="none" stroke="${c}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" ${s.dashed ? 'stroke-dasharray="6 5"' : ""}/>`;
    s.values.forEach((v, i) => { if (v != null) g += `<circle cx="${x(i)}" cy="${y(Number(v))}" r="3.5" fill="var(--surface)" stroke="${c}" stroke-width="2"><title>${esc(s.name ? s.name + ": " : "")}${esc(labels[i])} · ${esc(format(v))}</title></circle>`; });
  });
  return `<div class="chart"><svg viewBox="0 0 ${W} ${H}" role="img">${g}</svg>${legend(series)}</div>`;
}
export function donut({ items, center, sub, format = fmt.num, size = 168 }: { items: DonutItem[]; center?: string; sub?: string; format?: (v: any) => string; size?: number }): string {
  const total = items.reduce((a, x) => a + num(x.value), 0);
  const r = 60, c = 2 * Math.PI * r;
  let off = 0, arcs = "";
  items.forEach((it, i) => {
    const len = total ? (num(it.value) / total) * c : 0;
    arcs += `<circle r="${r}" cx="80" cy="80" fill="none" stroke="${it.color || COLORS[i % 6]}" stroke-width="20" stroke-dasharray="${len} ${c - len}" stroke-dashoffset="${-off}" transform="rotate(-90 80 80)"><title>${esc(it.label)} · ${esc(format(it.value))}</title></circle>`;
    off += len;
  });
  if (!total) arcs = `<circle r="${r}" cx="80" cy="80" fill="none" stroke="var(--line-2)" stroke-width="20"/>`;
  return `<div class="donut-wrap"><div class="chart" style="width:${size}px;position:relative;flex:none"><svg viewBox="0 0 160 160">${arcs}</svg><div class="donut-center"><b>${center != null ? center : esc(format(total))}</b>${sub ? `<div class="donut-sub">${esc(sub)}</div>` : ""}</div></div>
    <div class="legend-list">${items.map((it, i) => `<div><i style="background:${it.color || COLORS[i % 6]}"></i><span>${esc(it.label)}</span><b>${esc(format(it.value))}</b></div>`).join("")}</div></div>`;
}
export function hbars(items: BarItem[], { format = fmt.num, max, tone }: { format?: (v: any) => string; max?: number; tone?: string } = {}): string {
  const m = max || Math.max(...items.map((x) => num(x.value)), 1);
  return `<div class="list">${items.map((it) => `<div class="list-item" style="display:block"><div class="row" style="justify-content:space-between;margin-bottom:6px"><span>${it.labelHtml || esc(it.label)}</span><b class="num">${esc(format(it.value))}</b></div>${meter((num(it.value) / m) * 100, it.tone || tone || "brand")}</div>`).join("")}</div>`;
}

