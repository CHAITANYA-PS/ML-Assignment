/* Page title block: <app-page-head eyebrow="Buying" title="Orders" text="…"> buttons </app-page-head> (replaces DS.pageHead). */
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-page-head', standalone: true,
  template: `
  <div class="page-head">
    <div>
      @if (eyebrow) { <div class="eyebrow">{{ eyebrow }}</div> }
      <h1>{{ title }}</h1>
      @if (text) { <p>{{ text }}</p> }
    </div>
    <div class="actions"><ng-content /></div>
  </div>`
})
export class PageHeadComponent {
  @Input() eyebrow?: string;
  @Input() title = '';
  @Input() text?: string;
}
