/*
 * The app shell for every stakeholder (replaces shellHtml() and the menus in shell.js):
 * sidebar from nav.config.ts filtered by the role's access rules, top bar with page search, notifications and user menu.
 */
import { Component, HostListener, OnInit, computed, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { environment } from '../../environments/environment';
import { ApiService } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { ConfirmService } from '../core/confirm.service';
import { ToastService } from '../core/toast.service';
import { ConfirmDialogComponent } from '../shared/confirm-dialog.component';
import { FormModalComponent } from '../shared/form-modal/form-modal.component';
import { FieldSpec } from '../shared/form-modal/form-fields';
import { IconComponent } from '../shared/icon.component';
import { FORMAT_PIPES } from '../shared/pipes';
import { ToastsComponent } from '../shared/toasts.component';
import { COMMON, NAV, NavItem } from './nav.config';

@Component({
  selector: 'app-layout', standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, FormsModule, IconComponent, ToastsComponent, ConfirmDialogComponent, FormModalComponent, ...FORMAT_PIPES],
  templateUrl: './layout.component.html'
})
export class LayoutComponent implements OnInit {
  readonly env = environment;
  collapsed = localStorage.getItem('dsphere.collapsed') === '1';
  mobileOpen = false;
  menu: 'none' | 'notifications' | 'user' = 'none';
  search = '';
  notifications = signal<any[]>([]);
  unread = computed(() => this.notifications().filter(n => !n.readStatus).length);
  showPassword = false;

  readonly nav = computed(() => {
    const groups = (NAV[this.auth.folder()] ?? [])
      .map(g => ({ label: g.label, items: g.items.filter(i => this.auth.can(i.needs[0], i.needs[1])) }))
      .filter(g => g.items.length);
    return [...groups, { label: 'You', items: COMMON }];
  });

  readonly passwordFields: FieldSpec[] = [
    { name: 'currentPassword', label: 'Current password', type: 'password', required: true, full: true },
    { name: 'newPassword', label: 'New password', type: 'password', required: true, full: true,
      validate: v => (String(v).length < 8 || !/[A-Za-z]/.test(v) || !/\d/.test(v) ? 'Use at least 8 characters with a letter and a digit' : null) },
    { name: 'confirm', label: 'Repeat new password', type: 'password', required: true, full: true,
      validate: (v, all) => (v !== all['newPassword'] ? 'The two passwords are different' : null) }
  ];

  constructor(public auth: AuthService, private api: ApiService, private router: Router, private toast: ToastService, private confirm: ConfirmService) {}

  ngOnInit(): void { this.loadNotifications(); }

  link(page: string): string[] { return ['/', this.auth.folder(), page]; }
  get pageHits(): NavItem[] {
    const q = this.search.trim().toLowerCase();
    return q ? this.nav().flatMap(g => g.items).filter(i => i.label.toLowerCase().includes(q)) : [];
  }
  go(i: NavItem): void { this.search = ''; this.router.navigate(this.link(i.page)); }

  toggleNav(): void {
    if (window.innerWidth <= 900) { this.mobileOpen = !this.mobileOpen; return; }
    this.collapsed = !this.collapsed;
    localStorage.setItem('dsphere.collapsed', this.collapsed ? '1' : '0');
  }
  toggleMenu(m: 'notifications' | 'user', e: Event): void {
    e.stopPropagation();
    this.menu = this.menu === m ? 'none' : m;
    if (m === 'notifications' && this.menu === m) this.loadNotifications();
  }
  @HostListener('document:click') closeMenus(): void { this.menu = 'none'; }
  @HostListener('document:keydown.escape') onEscape(): void { this.menu = 'none'; this.mobileOpen = false; }

  async loadNotifications(): Promise<void> {
    try { this.notifications.set(await this.api.get<any[]>('/notifications/mine')); } catch { this.notifications.set([]); }
  }
  async markRead(n: any, e: Event): Promise<void> {
    e.stopPropagation();
    if (n.readStatus) return;
    try { await this.api.post(`/notifications/${n.notificationId}/read`); await this.loadNotifications(); } catch (err) { this.toast.error(err); }
  }
  async markAllRead(e: Event): Promise<void> {
    e.stopPropagation();
    const unread = this.notifications().filter(n => !n.readStatus);
    if (!unread.length) { this.toast.show('Nothing to mark: all notifications are already read'); return; }
    const results = await Promise.allSettled(unread.map(n => this.api.post(`/notifications/${n.notificationId}/read`)));
    const failed = results.filter(r => r.status === 'rejected') as PromiseRejectedResult[];
    await this.loadNotifications();
    if (failed.length) this.toast.error(failed[0].reason);
    else this.toast.show('All notifications marked as read');
  }
  /** The Notifications page tells the bell to refresh after it marks messages read. */
  @HostListener('window:dsphere-notifications') onNotificationsChanged(): void { this.loadNotifications(); }

  changePassword = (v: any) => this.api.post('/auth/change-password', { currentPassword: v.currentPassword, newPassword: v.newPassword })
    .then(() => this.toast.show('Password changed'));

  async resetDemo(): Promise<void> {
    const ok = await this.confirm.ask({ title: 'Reset demo data?', text: 'Every change you made in this browser is thrown away and the starting demo data comes back.', okLabel: 'Reset', tone: 'danger' });
    if (!ok) return;
    this.api.resetDemo();
    this.toast.show('Demo data reset');
    setTimeout(() => location.reload(), 500);
  }
  async signOut(): Promise<void> {
    await this.auth.logout();
    this.router.navigate(['/login'], { queryParams: { signedOut: 1 } });
  }
}
