/* The sidebar of each stakeholder (replaces NAV in shell.js). "needs" = the backend call the page cannot work without:
 * the link shows only when the role's role_permission rules allow it, so access changes in the database change the menu. */
export interface NavItem { page: string; label: string; icon: string; needs: [string, string]; }
export interface NavGroup { label: string; items: NavItem[]; }

export const NAV: Record<string, NavGroup[]> = {
  admin: [
    { label: 'Overview', items: [{ page: 'dashboard', label: 'Dashboard', icon: 'home', needs: ['GET', '/dashboard/summary'] }] },
    { label: 'People and access', items: [{ page: 'users', label: 'Users', icon: 'users', needs: ['GET', '/app-users'] }, { page: 'stakeholders', label: 'Stakeholders', icon: 'building', needs: ['GET', '/distributor-users'] }, { page: 'access', label: 'Roles and access', icon: 'shield', needs: ['GET', '/role-permissions'] }] },
    { label: 'Business data', items: [{ page: 'distributors', label: 'Distributors', icon: 'map', needs: ['GET', '/distributors'] }, { page: 'master-data', label: 'Master data', icon: 'database', needs: ['GET', '/regions'] }, { page: 'configuration', label: 'Configuration', icon: 'sliders', needs: ['GET', '/system-configs'] }] },
    { label: 'Monitoring', items: [{ page: 'audit', label: 'Audit trail', icon: 'log', needs: ['GET', '/audit-logs'] }, { page: 'jobs', label: 'Jobs', icon: 'play', needs: ['GET', '/jobs'] }, { page: 'exports', label: 'Exports', icon: 'download', needs: ['GET', '/exports'] }] }
  ],
  manufacturer: [
    { label: 'Overview', items: [{ page: 'dashboard', label: 'Dashboard', icon: 'home', needs: ['GET', '/dashboard/summary'] }] },
    { label: 'Products and stock', items: [{ page: 'products', label: 'Products and batches', icon: 'barcode', needs: ['GET', '/products'] }, { page: 'stock', label: 'Warehouse stock', icon: 'warehouse', needs: ['GET', '/stocks/current'] }, { page: 'shelf-life', label: 'Shelf life', icon: 'clock', needs: ['GET', '/stocks/current'] }] },
    { label: 'Fulfilment', items: [{ page: 'shipments', label: 'Shipments', icon: 'truck', needs: ['GET', '/shipments'] }, { page: 'returns', label: 'Returns and exchange', icon: 'swap', needs: ['GET', '/product-returns'] }] },
    { label: 'Insight', items: [{ page: 'carbon', label: 'Carbon footprint', icon: 'leaf', needs: ['GET', '/emissions/summary'] }, { page: 'reports', label: 'Reports', icon: 'download', needs: ['GET', '/exports'] }] }
  ],
  distributor: [
    { label: 'Overview', items: [{ page: 'dashboard', label: 'Dashboard', icon: 'home', needs: ['GET', '/dashboard/summary'] }] },
    { label: 'Buying', items: [{ page: 'orders', label: 'Orders', icon: 'cart', needs: ['GET', '/distributor-orders'] }, { page: 'deliveries', label: 'Deliveries', icon: 'truck', needs: ['GET', '/shipments'] }, { page: 'inventory', label: 'My stock', icon: 'box', needs: ['GET', '/stocks/current'] }] },
    { label: 'After sales', items: [{ page: 'returns', label: 'Returns and exchange', icon: 'swap', needs: ['GET', '/product-returns'] }, { page: 'tickets', label: 'Support tickets', icon: 'ticket', needs: ['GET', '/tickets'] }] },
    { label: 'Growth', items: [{ page: 'commitments', label: 'Commitments', icon: 'target', needs: ['GET', '/commitments'] }, { page: 'performance', label: 'Performance', icon: 'trend', needs: ['GET', '/performance'] }, { page: 'reports', label: 'Reports', icon: 'download', needs: ['GET', '/exports'] }] }
  ],
  sales: [
    { label: 'Overview', items: [{ page: 'dashboard', label: 'Dashboard', icon: 'home', needs: ['GET', '/dashboard/summary'] }] },
    { label: 'Network', items: [{ page: 'distributors', label: 'Distributors', icon: 'map', needs: ['GET', '/distributors'] }, { page: 'orders', label: 'Orders', icon: 'cart', needs: ['GET', '/distributor-orders'] }, { page: 'tickets', label: 'Support tickets', icon: 'ticket', needs: ['GET', '/tickets'] }] },
    { label: 'Performance', items: [{ page: 'targets', label: 'Targets and sales', icon: 'target', needs: ['GET', '/sales-targets'] }, { page: 'health', label: 'Health scores', icon: 'heart', needs: ['GET', '/health-score-histories'] }, { page: 'continuity', label: 'Continuity', icon: 'activity', needs: ['GET', '/continuity/at-risk'] }, { page: 'commitments', label: 'Commitments', icon: 'flag', needs: ['GET', '/commitments'] }] },
    { label: 'Insight', items: [{ page: 'reports', label: 'Reports', icon: 'download', needs: ['GET', '/exports'] }] }
  ],
  finance: [
    { label: 'Overview', items: [{ page: 'dashboard', label: 'Dashboard', icon: 'home', needs: ['GET', '/dashboard/summary'] }] },
    { label: 'Receivables', items: [{ page: 'invoices', label: 'Invoices', icon: 'receipt', needs: ['GET', '/invoices'] }, { page: 'payments', label: 'Payments', icon: 'wallet', needs: ['GET', '/payments'] }] },
    { label: 'Credit', items: [{ page: 'credit-limits', label: 'Credit limits', icon: 'card', needs: ['GET', '/distributor-credit-limits'] }, { page: 'credit-risk', label: 'Credit risk', icon: 'shield', needs: ['GET', '/credit-risk-assessments'] }] },
    { label: 'Insight', items: [{ page: 'stock-value', label: 'Stock value', icon: 'coins', needs: ['GET', '/stocks/summary'] }, { page: 'reports', label: 'Reports', icon: 'download', needs: ['GET', '/exports'] }] }
  ],
  recovery: [
    { label: 'Overview', items: [{ page: 'dashboard', label: 'Dashboard', icon: 'home', needs: ['GET', '/dashboard/summary'] }] },
    { label: 'Tickets', items: [{ page: 'tickets', label: 'Ticket queue', icon: 'ticket', needs: ['GET', '/tickets'] }, { page: 'sla', label: 'SLA and escalations', icon: 'clock', needs: ['GET', '/escalations'] }, { page: 'disputes', label: 'Delivery disputes', icon: 'alert', needs: ['GET', '/delivery-discrepancies'] }] },
    { label: 'Recovery', items: [{ page: 'plans', label: 'Recovery plans', icon: 'lifebuoy', needs: ['GET', '/recovery-plans'] }, { page: 'underperformers', label: 'Underperformers', icon: 'trend', needs: ['GET', '/performance'] }] },
    { label: 'Insight', items: [{ page: 'reports', label: 'Reports', icon: 'download', needs: ['GET', '/exports'] }] }
  ]
};

/** Pages every stakeholder has. */
export const COMMON: NavItem[] = [
  { page: 'notifications', label: 'Notifications', icon: 'bell', needs: ['GET', '/notifications/mine'] },
  { page: 'profile', label: 'My profile', icon: 'user', needs: ['GET', '/auth/me'] }
];
