/* Manufacturer › Carbon footprint: emissions of every shipment trip (distance × the vehicle's emission factor). */
import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { barChart } from '../../shared/charts';
import { ChartComponent } from '../../shared/chart.component';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, RowAction } from '../../shared/data-table/data-table.types';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { MONTHS } from '../dashboard/dashboard.component';

@Component({
  selector: 'app-manufacturer-carbon', standalone: true, imports: [PageHeadComponent, KpiCardComponent, ChartComponent, DataTableComponent],
  templateUrl: './carbon.component.html'
})
export class CarbonComponent implements OnInit {
  @ViewChild(DataTableComponent) table?: DataTableComponent;
  readonly ICONS = ICONS;
  readonly year = new Date().getFullYear();
  em: any = null;
  chart = '';
  over = 0;
  trips = 0;
  limit = 0;
  ready = false;
  columns: Column[] = [];
  actions: RowAction[] = [];
  f = fmt;

  constructor(private api: ApiService, private auth: AuthService, private ref: RefService, private toast: ToastService) {}

  async ngOnInit(): Promise<void> {
    await this.ref.ensure(['shipments', 'emission-factors', 'vehicle-types']);
    this.columns = [
      { key: 'activityDate', label: 'Date', type: 'date' },
      { key: 'origin', label: 'Route', value: r => `${r.origin} → ${r.destination}` },
      { key: 'shipmentId', label: 'Shipment', type: 'ref', ref: 'shipments' },
      { key: 'distanceKm', label: 'Distance km', type: 'num' },
      { key: 'emissionFactorId', label: 'Vehicle', value: r => { const f = this.ref.get('emission-factors', r.emissionFactorId); return f ? this.ref.name('vehicle-types', f.vehicleTypeId) : '–'; } },
      { key: 'emissionKg', label: 'kg CO₂', type: 'num' }
    ];
    this.actions = [{ label: 'Recalculate', show: r => this.auth.can('POST', `/emissions/calculate/${r.transportationActivityId}`), run: r => this.recalc(r) }];
    this.ready = true;
    await this.load();
  }
  async load(): Promise<void> {
    this.em = await this.api.get('/emissions/summary', { year: this.year });
    this.over = this.em.months.filter((m: any) => m.aboveTarget).length;
    this.trips = this.em.months.reduce((a: number, m: any) => a + m.activities, 0);
    this.limit = Number(this.em.months?.[0]?.targetKg ?? 0);
    this.chart = barChart({ labels: MONTHS, series: [{ name: 'kg CO₂', values: this.em.months.map((m: any) => m.emissionKg) }], target: this.limit, wide: true, height: 260 });
  }
  async recalc(r: any): Promise<void> {
    try {
      await this.api.post(`/emissions/calculate/${r.transportationActivityId}`);
      this.toast.show('Emission recalculated', 'ok', `POST /emissions/calculate/${r.transportationActivityId}`);
      this.table?.reload(true);
      await this.load();
    } catch (e) { this.toast.error(e); }
  }
}
