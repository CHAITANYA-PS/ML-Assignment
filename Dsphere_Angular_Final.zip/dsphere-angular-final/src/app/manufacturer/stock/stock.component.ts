/* Manufacturer › Warehouse stock: current stock, totals per product, movements, write-offs and alerts. */
import { Component } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { RefService } from '../../core/ref.service';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { StockTableComponent } from '../../common/stock-table/stock-table.component';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter, esc } from '../../shared/data-table/data-table.types';
import { FieldSpec } from '../../shared/form-modal/form-fields';
import { PageHeadComponent } from '../../shared/page-head.component';
import { TabsComponent } from '../../shared/tabs.component';
import { FORMAT_PIPES } from '../../shared/pipes';

@Component({
  selector: 'app-manufacturer-stock', standalone: true, imports: [PageHeadComponent, TabsComponent, StockTableComponent, DataTableComponent, CrudTableComponent, ...FORMAT_PIPES],
  templateUrl: './stock.component.html'
})
export class StockComponent {
  readonly tabs = [{ key: 'current', label: 'Current stock' }, { key: 'summary', label: 'Totals per product' }, { key: 'movements', label: 'Movements' }, { key: 'writeoffs', label: 'Write-offs' }, { key: 'alerts', label: 'Alerts' }];
  tab = 'current';
  summary: any[] | null = null;

  readonly movementColumns: Column[] = [
    { key: 'movementDate', label: 'When', type: 'dateTime' },
    { key: 'movementTypeId', label: 'Type', html: r => { const t = this.ref.get('movement-types', r.movementTypeId) ?? {}; const inn = t.movementDirection === 'IN'; return `<span class="pill ${inn ? 'ok' : 'info'}">${inn ? 'In' : 'Out'}</span> ${esc(t.movementTypeName ?? '')}`; } },
    { key: 'warehouseStockId', label: 'Stock row', value: r => `#${r.warehouseStockId}` },
    { key: 'quantity', label: 'Quantity', type: 'num' },
    { key: 'inventoryDocumentId', label: 'Document', value: r => (r.inventoryDocumentId ? this.ref.name('inventory-documents', r.inventoryDocumentId) : '–') }
  ];
  readonly movementFilters: Filter[] = [{ key: 'movementTypeId', label: 'Type', ref: 'movement-types' }];
  readonly writeOffColumns: Column[] = [
    { key: 'warehouseStockId', label: 'Stock row', value: r => `#${r.warehouseStockId}` },
    { key: 'quantity', label: 'Quantity', type: 'num' }, { key: 'writeOffValue', label: 'Value', type: 'money' },
    { key: 'reason', label: 'Reason' }, { key: 'writtenOffAt', label: 'When', type: 'dateTime' }
  ];
  readonly writeOffFields: (string | FieldSpec)[] = [{ name: 'warehouseStockId', label: 'Stock row id', type: 'number', required: true }, 'quantity', { name: 'reason', full: true }];
  readonly alertColumns: Column[] = [
    { key: 'alertType', label: 'Alert', type: 'pill' }, { key: 'message', label: 'Message' },
    { key: 'warehouseStockId', label: 'Stock row', value: r => `#${r.warehouseStockId}` },
    { key: 'status', label: 'Status', type: 'pill' }, { key: 'createdAt', label: 'Raised', type: 'ago' }
  ];

  constructor(private api: ApiService, private ref: RefService) {
    this.ref.ensure(['movement-types', 'inventory-documents']);
  }

  async tabChanged(t: string): Promise<void> {
    if (t === 'summary' && !this.summary) {
      const rows = await this.api.get<any[]>('/stocks/summary', { groupBy: 'product' });
      this.summary = [...rows].sort((a, b) => b.stockValue - a.stockValue);
    }
  }
}
