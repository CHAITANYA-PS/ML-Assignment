/* Manufacturer › Shipments: verify each packed item, then dispatch with a handover code. */
import { Component } from '@angular/core';
import { ShipmentsListComponent } from '../../common/shipments-list/shipments-list.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-manufacturer-shipments', standalone: true, imports: [PageHeadComponent, ShipmentsListComponent],
  template: `
  <app-page-head eyebrow="Fulfilment" title="Shipments" text="Open a shipment to verify each packed item by typing its product code, batch and quantity, then dispatch it. Dispatch gives a 6-digit handover code for the driver." />
  <section class="card"><div class="card-body flush"><app-shipments-list [manufacturer]="true" /></div></section>`
})
export class ShipmentsComponent {}
