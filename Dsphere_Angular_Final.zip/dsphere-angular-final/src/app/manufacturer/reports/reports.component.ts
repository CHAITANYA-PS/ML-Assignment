/* Manufacturer › Reports. */
import { Component } from '@angular/core';
import { ReportsComponent } from '../../common/reports/reports.component';

@Component({
  selector: 'app-manufacturer-reports', standalone: true, imports: [ReportsComponent],
  template: `<app-reports [defaults]="defaults" />`
})
export class ManufacturerReportsComponent { readonly defaults = ['products', 'warehouse-stocks', 'shipments', 'transportation-activities']; }
