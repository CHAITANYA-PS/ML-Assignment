/* Manufacturer › Dashboard: stock, shipments to pack and dispatch, shelf life, returns and emissions. */
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { inTransit } from '../../common/shipment-state';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { metric } from '../../core/dashboard-summary';
import { RefService } from '../../core/ref.service';
import { ShipmentDrawerComponent } from '../../common/shipment-drawer/shipment-drawer.component';
import { barChart } from '../../shared/charts';
import { ChartComponent } from '../../shared/chart.component';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';

export const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

@Component({
  selector: 'app-manufacturer-dashboard', standalone: true,
  imports: [RouterLink, PageHeadComponent, KpiCardComponent, ChartComponent, StatusPillComponent, ShipmentDrawerComponent, ...FORMAT_PIPES],
  templateUrl: './dashboard.component.html'
})
export class ManufacturerDashboardComponent implements OnInit {
  readonly ICONS = ICONS;
  loaded = false;
  stockValue = 0;
  lowStockItems = 0;
  nearExpiryItems = 0;
  expiredItems = 0;
  monthlyLimit = 0;
  toPack: any[] = [];
  inTransit = 0;
  returns = 0;
  exchanges = 0;
  em: any = null;
  stockChart = '';
  emissionChart = '';
  openId: any = null;

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService) {}

  get firstName(): string { return (this.auth.me()?.userName ?? '').split(' ')[0]; }
  f = fmt;

  async ngOnInit(): Promise<void> { await this.load(); }
  async load(): Promise<void> {
    const [sum, byWh, ships, rets, ex, em, current] = await Promise.all([
      this.api.get('/dashboard/summary'), this.api.get<any[]>('/stocks/summary', { groupBy: 'warehouse' }), this.api.all('/shipments'),
      this.api.all('/product-returns', { status: 'REQUESTED' }), this.api.all('/exchange-requests'), this.api.get('/emissions/summary').catch(() => null),
      this.api.all('/stocks/current')
    ]);
    await this.ref.ensure(['shipment-statuses', 'warehouses', 'exchange-statuses']);
    const st = (s: any) => this.ref.name('shipment-statuses', s.shipmentStatusId);
    this.stockValue = Number(metric(sum, 'Stock value') ?? 0);
    this.lowStockItems = Number(metric(sum, 'Stock rows at/below reorder level') ?? 0);
    this.nearExpiryItems = Number(metric(sum, 'Stock rows near expiry') ?? 0);
    this.expiredItems = current.filter((r: any) => r.expiryState === 'EXPIRED').length;
    this.em = em; this.monthlyLimit = Number(em?.months?.[0]?.targetKg ?? 0);
    this.toPack = ships.filter(s => ['Created', 'Verified'].includes(st(s))).slice(0, 6);
    this.inTransit = ships.filter(s => inTransit(s, st(s))).length;
    this.returns = rets.length;
    this.exchanges = ex.filter(e => this.ref.name('exchange-statuses', e.exchangeStatusId) === 'Requested').length;
    this.stockChart = barChart({
      labels: byWh.map(w => String(w.warehouseName).replace(/ (Warehouse|Distribution Centre|Hub)$/, '')), stacked: true,
      series: [
        { name: 'Sellable', values: byWh.map(w => w.sellableQuantity - w.nearExpiryQuantity) },
        { name: 'Near expiry', values: byWh.map(w => w.nearExpiryQuantity), color: 'var(--warn)' },
        { name: 'Expired / blocked', values: byWh.map(w => w.totalQuantity - w.sellableQuantity), color: 'var(--danger)' }
      ]
    });
    if (em) this.emissionChart = barChart({ labels: MONTHS, series: [{ name: 'kg CO₂', values: em.months.map((m: any) => m.emissionKg) }], target: this.monthlyLimit, height: 220, wide: true });
    this.loaded = true;
  }
}
