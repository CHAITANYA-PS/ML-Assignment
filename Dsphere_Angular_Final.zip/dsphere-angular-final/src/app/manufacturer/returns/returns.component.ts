/* Manufacturer › Returns and exchange. */
import { Component } from '@angular/core';
import { ReturnsComponent } from '../../common/returns/returns.component';

@Component({
  selector: 'app-manufacturer-returns', standalone: true, imports: [ReturnsComponent],
  template: `<app-returns text="Approve or reject returns and exchange requests from distributors. Received returns come back as not sellable stock." />`
})
export class ManufacturerReturnsComponent {}
