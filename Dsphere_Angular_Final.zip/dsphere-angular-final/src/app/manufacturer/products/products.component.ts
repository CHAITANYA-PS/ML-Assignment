/* Manufacturer › Products and batches. Product codes have 13 digits; the last one is a check digit. */
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService } from '../../core/toast.service';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { Column, Filter, esc } from '../../shared/data-table/data-table.types';
import { fmt } from '../../shared/format';
import { FieldSpec } from '../../shared/form-modal/form-fields';
import { PageHeadComponent } from '../../shared/page-head.component';
import { TabsComponent } from '../../shared/tabs.component';

/** EAN-13 check digit, the same rule as the backend ProductCodeValidator. */
export function validProductCode(code: string): boolean {
  if (!/^\d{13}$/.test(code)) return false;
  const d = code.split('').map(Number);
  const sum = d.slice(0, 12).reduce((a, n, i) => a + n * (i % 2 ? 3 : 1), 0);
  return (10 - (sum % 10)) % 10 === d[12];
}

@Component({
  selector: 'app-manufacturer-products', standalone: true, imports: [FormsModule, PageHeadComponent, TabsComponent, CrudTableComponent],
  templateUrl: './products.component.html'
})
export class ProductsComponent implements OnInit {
  readonly tabs = [{ key: 'products', label: 'Products' }, { key: 'batches', label: 'Batches' }, { key: 'check', label: 'Check a product code' }];
  tab = 'products';
  code = '';
  result: any = null;
  checking = false;

  readonly productColumns: Column[] = [
    { key: 'productName', label: 'Product', type: 'strong', sub: r => r.sku },
    { key: 'productCode', label: 'Product code', type: 'mono' },
    { key: 'categoryId', label: 'Category', type: 'ref', ref: 'categories' },
    { key: 'unit', label: 'Unit' },
    { key: 'shelfLifeDays', label: 'Shelf life', value: r => `${fmt.num(r.shelfLifeDays)} days` },
    { key: 'unitCost', label: 'Unit cost', type: 'money' },
    { key: 'status', label: 'Status', type: 'pill' }
  ];
  readonly productFilters: Filter[] = [{ key: 'categoryId', label: 'Category', ref: 'categories' }, { key: 'status', label: 'Status', options: ['Active', 'Inactive', 'Discontinued'] }];
  readonly productFields: (string | FieldSpec)[] = ['productName', 'sku',
    { name: 'productCode', mono: true, hint: '13 digits, the last one is the check digit', validate: v => (v && !validProductCode(String(v)) ? 'Product code is not valid (wrong check digit)' : null) },
    'categoryId', 'unit', 'shelfLifeDays', 'unitCost', 'status'];
  readonly batchColumns: Column[] = [
    { key: 'batchNumber', label: 'Batch', type: 'mono' },
    { key: 'productId', label: 'Product', type: 'ref', ref: 'products' },
    { key: 'manufacturingDate', label: 'Made', type: 'date' },
    { key: 'expiryDate', label: 'Expiry', html: r => { const d = fmt.daysTo(r.expiryDate) ?? 999; return `${esc(fmt.date(r.expiryDate))} ${d < 0 ? '<span class="pill danger">Expired</span>' : d <= 30 ? `<span class="pill warn">${d} days</span>` : ''}`; } },
    { key: 'operationalStatus', label: 'Status', type: 'pill' }
  ];
  readonly batchFilters: Filter[] = [{ key: 'productId', label: 'Product', ref: 'products' }];
  readonly batchFields: (string | FieldSpec)[] = ['productId', { name: 'batchNumber', mono: true }, 'manufacturingDate',
    { name: 'expiryDate', validate: (v, all) => (v && all['manufacturingDate'] && v <= all['manufacturingDate'] ? 'Expiry date must be after the manufacturing date' : null) }, 'operationalStatus'];

  constructor(private api: ApiService, private toast: ToastService) {}

  async ngOnInit(): Promise<void> {
    const rows = await this.api.all('/products', { size: 1 }).catch(() => []);
    if (rows[0]?.productCode) { this.code = rows[0].productCode; }
  }
  async check(): Promise<void> {
    this.checking = true;
    try { this.result = await this.api.get('/products/validate-code', { code: this.code }); }
    catch (e) { this.toast.error(e); } finally { this.checking = false; }
  }
  tabChanged(t: string): void { if (t === 'check' && this.code && !this.result) this.check(); }
}
