/* Manufacturer › Shelf life: batches close to or past expiry. The nightly expiry job marks expired stock as not sellable. */
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { StockTableComponent } from '../../common/stock-table/stock-table.component';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-manufacturer-shelf-life', standalone: true, imports: [PageHeadComponent, KpiCardComponent, StockTableComponent],
  template: `
  <app-page-head eyebrow="Products and stock" title="Shelf life" text="Batches close to or past their expiry date. The nightly expiry job marks expired stock as not sellable." />
  <div class="grid cols-3">
    <app-kpi label="Expired" [value]="count('EXPIRED')" [foot]="value('EXPIRED') + ' of stock'" tone="danger" [iconPath]="ICONS['alert']" />
    <app-kpi label="Near expiry" [value]="count('NEAR_EXPIRY')" [foot]="value('NEAR_EXPIRY') + ' at risk'" tone="warn" [iconPath]="ICONS['clock']" />
    <app-kpi label="Healthy" [value]="count('OK')" [foot]="value('OK') + ' of stock'" tone="ok" [iconPath]="ICONS['check']" />
  </div>
  <section class="card mt">
    <div class="card-head"><div><h2>Batches to act on</h2><div class="sub">Sell first, return, or write off</div></div></div>
    <div class="card-body flush"><app-stock-table expiryState="NEAR_EXPIRY" /></div>
  </section>`
})
export class ShelfLifeComponent implements OnInit {
  readonly ICONS = ICONS;
  rows: any[] = [];
  constructor(private api: ApiService) {}
  async ngOnInit(): Promise<void> { this.rows = await this.api.get<any[]>('/stocks/current'); }
  private by(s: string): any[] { return this.rows.filter(r => r.expiryState === s); }
  count(s: string): string { return fmt.num(this.by(s).length); }
  value(s: string): string { return fmt.moneyShort(this.by(s).reduce((a, r) => a + Number(r.stockValue || 0), 0)); }
}
