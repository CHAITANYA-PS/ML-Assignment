/* Pages of the manufacturer stakeholder. Each page is lazy-loaded and guarded by the backend call it needs
 * (canGuard checks the role_permission rules, the same as the sidebar). */
import { Routes } from '@angular/router';
import { canGuard } from '../core/guards';

export const MANUFACTURER_ROUTES: Routes = [
  { path: 'dashboard', title: 'Dashboard · Dsphere', canActivate: [canGuard('GET', '/dashboard/summary')], loadComponent: () => import('./dashboard/dashboard.component').then(m => m.ManufacturerDashboardComponent) },
  { path: 'products', title: 'Products and batches · Dsphere', canActivate: [canGuard('GET', '/products')], loadComponent: () => import('./products/products.component').then(m => m.ProductsComponent) },
  { path: 'stock', title: 'Warehouse stock · Dsphere', canActivate: [canGuard('GET', '/stocks/current')], loadComponent: () => import('./stock/stock.component').then(m => m.StockComponent) },
  { path: 'shelf-life', title: 'Shelf life · Dsphere', canActivate: [canGuard('GET', '/stocks/current')], loadComponent: () => import('./shelf-life/shelf-life.component').then(m => m.ShelfLifeComponent) },
  { path: 'shipments', title: 'Shipments · Dsphere', canActivate: [canGuard('GET', '/shipments')], loadComponent: () => import('./shipments/shipments.component').then(m => m.ShipmentsComponent) },
  { path: 'returns', title: 'Returns and exchange · Dsphere', canActivate: [canGuard('GET', '/product-returns')], loadComponent: () => import('./returns/returns.component').then(m => m.ManufacturerReturnsComponent) },
  { path: 'carbon', title: 'Carbon footprint · Dsphere', canActivate: [canGuard('GET', '/emissions/summary')], loadComponent: () => import('./carbon/carbon.component').then(m => m.CarbonComponent) },
  { path: 'reports', title: 'Reports · Dsphere', canActivate: [canGuard('GET', '/exports')], loadComponent: () => import('./reports/reports.component').then(m => m.ManufacturerReportsComponent) },
  { path: 'notifications', title: 'Notifications · Dsphere', loadComponent: () => import('../common/notifications/notifications.component').then(m => m.NotificationsComponent) },
  { path: 'profile', title: 'My profile · Dsphere', loadComponent: () => import('../common/profile/profile.component').then(m => m.ProfileComponent) },
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
];
