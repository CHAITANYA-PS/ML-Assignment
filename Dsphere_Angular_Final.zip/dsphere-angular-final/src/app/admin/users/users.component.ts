/* Admin › Users: every account, and the two-step "new user" (account, then the one stakeholder role). */
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { Column, Filter, RowAction, esc } from '../../shared/data-table/data-table.types';
import { fmt } from '../../shared/format';
import { FormModalComponent } from '../../shared/form-modal/form-modal.component';
import { FieldSpec, fieldsFor } from '../../shared/form-modal/form-fields';
import { ModalComponent } from '../../shared/modal.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { STAKEHOLDERS, Stakeholder } from '../stakeholders';

const LINK_REF: Record<string, string> = { manufacturerId: 'manufacturers', distributorId: 'distributors', regionId: 'regions', departmentId: 'departments' };

@Component({
  selector: 'app-admin-users', standalone: true, imports: [FormsModule, PageHeadComponent, CrudTableComponent, FormModalComponent, ModalComponent],
  templateUrl: './users.component.html'
})
export class UsersComponent implements OnInit {
  @ViewChild(CrudTableComponent) table?: CrudTableComponent;
  readonly STAKEHOLDERS = STAKEHOLDERS;
  ready = false;
  columns: Column[] = [];
  readonly filters: Filter[] = [{ key: 'status', label: 'Status', options: ['Active', 'Pending', 'Suspended', 'Inactive'] }];
  readonly fields = ['userName', 'email', 'passwordHash', 'phone', 'status', 'mfaEnabled'];
  readonly editFields = ['userName', 'email', 'phone', 'status', 'mfaEnabled'];
  actions: RowAction[] = [];

  // the wizard
  step = 0;               // 0 closed, 1 account, 2 stakeholder
  account: any = null;
  created: any = null;
  stake = 'DISTRIBUTOR';
  link: any = '';
  linkError = '';
  error = '';
  busy = false;
  accountFields: FieldSpec[] = fieldsFor('app-users', [
    { name: 'userName', label: 'Full name', full: true }, { name: 'email', full: true },
    { name: 'passwordHash', label: 'Starting password', type: 'password', hint: 'The user should change it after the first sign-in.', validate: v => (v && String(v).length < 8 ? 'Use at least 8 characters' : null) },
    'phone', { name: 'status', default: 'Active' }, { name: 'mfaEnabled', label: 'Two-step sign-in' }
  ]);

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService, private toast: ToastService) {}

  async ngOnInit(): Promise<void> {
    this.ref.invalidate('user-roles');
    await this.ref.ensure(['user-roles', 'roles', 'manufacturers', 'distributors', 'regions', 'departments']);
    this.columns = [
      { key: 'userName', label: 'User', html: r => `<div class="row"><span class="avatar">${esc(fmt.initials(r.userName))}</span><div><b>${esc(r.userName)}</b><div class="cell-sub">${esc(r.email)}</div></div></div>` },
      { key: 'role', label: 'Stakeholder role', html: r => { const ro = this.roleOf(r.userId); return ro ? `<span class="pill brand">${esc(ro.roleName)}</span>` : '<span class="pill warn">No role</span>'; } },
      { key: 'status', label: 'Status', type: 'pill' },
      { key: 'mfaEnabled', label: 'Two-step', type: 'bool' },
      { key: 'phone', label: 'Phone' },
      { key: 'createdAt', label: 'Created', type: 'ago' }
    ];
    this.actions = [
      { label: 'Activate', show: r => r.status !== 'Active' && this.auth.can('PUT', '/app-users/' + r.userId), run: r => this.setStatus(r, 'Active') },
      { label: 'Suspend', show: r => r.status === 'Active' && this.auth.can('PUT', '/app-users/' + r.userId), run: r => this.setStatus(r, 'Suspended') }
    ];
    this.ready = true;
  }
  roleOf(userId: number): any {
    const ur = this.ref.rows('user-roles').find((x: any) => x.userId === userId);
    return ur ? this.ref.get('roles', ur.roleId) : null;
  }
  describe = (r: any) => `${r.userName} (${r.email})`;
  async setStatus(r: any, status: string): Promise<void> {
    try {
      await this.api.put(`/app-users/${r.userId}`, { status, version: r.version });
      this.toast.show(`${r.userName} ${status === 'Active' ? 'activated' : 'suspended'}`, 'ok', `PUT /app-users/${r.userId}`);
      this.table?.reload();
    } catch (e) { this.toast.error(e); }
  }

  // ---------------------------------------------------------------- wizard
  get s(): Stakeholder { return STAKEHOLDERS.find(x => x.code === this.stake)!; }
  get linkOptions(): [any, string][] {
    const l = this.s.link;
    if (l.options) return l.options.map(o => (Array.isArray(o) ? o : [o, o]));
    return this.ref.options(LINK_REF[l.name]);
  }
  start(): void { this.step = 1; this.account = null; this.created = null; this.link = ''; this.error = ''; }
  keepAccount = (v: any) => { this.account = v; return Promise.resolve(v); };
  accountClosed(): void { this.step = this.account ? 2 : 0; }
  stakeChanged(): void { this.link = ''; this.linkError = ''; }
  back(): void { if (!this.created) this.step = 1; }

  async createUser(): Promise<void> {
    this.error = ''; this.linkError = '';
    if (this.link === '' || this.link == null) { this.linkError = `${this.s.link.label} is required`; return; }
    this.busy = true;
    try {
      if (!this.created) this.created = await this.api.post('/app-users', this.account);
      await this.api.post('/' + this.s.res, { userId: this.created.userId, [this.s.link.name]: this.link });
      this.toast.show(`${this.created.userName} created as ${this.s.name}`, 'ok', `POST /app-users + /${this.s.res}`);
      this.ref.invalidate('user-roles'); this.ref.invalidate('app-users');
      await this.ref.ensure(['user-roles']);
      this.step = 0;
      this.table?.reload(false);
    } catch (e: any) {
      const extra = e?.fieldErrors ? Object.entries(e.fieldErrors).map(([k, m]) => `${k}: ${m}`) : [];
      this.error = [e.message, ...extra].join(' · ') + (this.created ? '' : ' Go back to fix the account.');
    } finally { this.busy = false; }
  }
}
