/* Admin › Distributors: the network, with the 360° drawer per distributor. */
import { Component } from '@angular/core';
import { DistributorsListComponent } from '../../common/distributors-list/distributors-list.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-distributors', standalone: true, imports: [PageHeadComponent, DistributorsListComponent],
  templateUrl: './distributors.component.html'
})
export class DistributorsComponent {}
