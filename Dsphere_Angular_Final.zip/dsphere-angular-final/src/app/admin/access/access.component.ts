/* Admin › Roles and access: the role_permission table as a matrix, a request checker, all rules and the roles. */
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ROLE_NAME } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { Column, Filter } from '../../shared/data-table/data-table.types';
import { FieldSpec } from '../../shared/form-modal/form-fields';
import { PageHeadComponent } from '../../shared/page-head.component';
import { TabsComponent } from '../../shared/tabs.component';

@Component({
  selector: 'app-admin-access', standalone: true, imports: [FormsModule, PageHeadComponent, TabsComponent, CrudTableComponent],
  templateUrl: './access.component.html'
})
export class AccessComponent implements OnInit {
  readonly tabs = [{ key: 'matrix', label: 'Permission matrix' }, { key: 'check', label: 'Check a request' }, { key: 'rules', label: 'All rules' }, { key: 'roles', label: 'Roles' }];
  tab = 'matrix';

  // matrix
  rules: any[] = [];
  cols: any[] = [];
  resources: string[] = [];
  filter = '';
  saving = '';

  // checker
  readonly roleCodes = Object.entries(ROLE_NAME);
  readonly methods = ['GET', 'POST', 'PUT', 'DELETE'];
  check = { role: 'DISTRIBUTOR', method: 'POST', path: '/api/v1/tickets/12/assign' };
  result: any = null;
  checking = false;

  readonly ruleColumns: Column[] = [
    { key: 'roleId', label: 'Role', type: 'ref', ref: 'roles' },
    { key: 'resource', label: 'Resource', type: 'mono' },
    { key: 'canRead', label: 'Read', type: 'bool' },
    { key: 'canWrite', label: 'Write', type: 'bool' },
    { key: 'description', label: 'Description' },
    { key: 'updatedAt', label: 'Updated', type: 'ago' }
  ];
  readonly ruleFilters: Filter[] = [{ key: 'roleId', label: 'Role', ref: 'roles' }];
  readonly ruleFields: (string | FieldSpec)[] = ['roleId', { name: 'resource', full: true, mono: true, hint: 'Path after /api/v1/, for example tickets or tickets/*/assign. The most specific matching rule decides.' }, 'canRead', 'canWrite', { name: 'description', full: true }];
  readonly ruleEditFields: (string | FieldSpec)[] = ['canRead', 'canWrite', { name: 'description', full: true }];
  roleColumns: Column[] = [];
  readonly roleFields: (string | FieldSpec)[] = ['roleName', 'roleCode', { name: 'description', full: true }, 'status'];
  readonly roleEditFields: (string | FieldSpec)[] = ['roleName', { name: 'description', full: true }, 'status'];

  constructor(private api: ApiService, private ref: RefService, private toast: ToastService) {}

  async ngOnInit(): Promise<void> {
    await this.ref.ensure(['user-roles', 'roles']);
    this.roleColumns = [
      { key: 'roleName', label: 'Role', type: 'strong', sub: r => r.roleCode || 'no code' },
      { key: 'description', label: 'Description' },
      { key: 'status', label: 'Status', type: 'pill' },
      { key: 'users', label: 'Users', type: 'num', value: r => this.ref.rows('user-roles').filter((x: any) => x.roleId === r.roleId).length }
    ];
    await this.loadMatrix();
    this.runCheck();
  }

  async loadMatrix(): Promise<void> {
    const [rules, roles] = await Promise.all([this.api.all('/role-permissions'), this.api.all('/roles')]);
    this.rules = rules;
    this.cols = roles.filter(r => r.roleCode && r.roleCode !== 'SYSTEM_ADMIN');
    this.resources = [...new Set(rules.map(r => String(r.resource)))].sort();
  }
  get shown(): string[] { const q = this.filter.toLowerCase(); return this.resources.filter(r => r.includes(q)); }
  rule(roleId: number, res: string): any { return this.rules.find(r => r.roleId === roleId && r.resource === res); }
  on(roleId: number, res: string, k: 'canRead' | 'canWrite'): boolean { return !!this.rule(roleId, res)?.[k]; }
  key(roleId: number, res: string, k: string): string { return `${roleId}|${res}|${k}`; }

  async toggle(role: any, res: string, k: 'canRead' | 'canWrite'): Promise<void> {
    const id = this.key(role.roleId, res, k);
    if (this.saving) return;
    this.saving = id;
    const cur = this.rule(role.roleId, res);
    try {
      let saved: any;
      if (cur) {
        const body: any = { [k]: !cur[k], version: cur.version };
        if (k === 'canWrite' && !cur.canWrite) body.canRead = true;    // write needs read
        if (k === 'canRead' && cur.canRead) body.canWrite = false;     // no read, no write
        saved = await this.api.put(`/role-permissions/${cur.rolePermissionId}`, body);
        Object.assign(cur, saved);
      } else {
        saved = await this.api.post('/role-permissions', { roleId: role.roleId, resource: res, canRead: true, canWrite: k === 'canWrite', description: 'Added from the matrix' });
        this.rules = [...this.rules, saved];
      }
      await this.api.post('/role-permissions/reload');
      this.toast.show(`${role.roleName}: ${res} is now ${saved.canWrite ? 'read and write' : saved.canRead ? 'read only' : 'no access'}`, 'ok', cur ? `PUT /role-permissions/${cur.rolePermissionId}` : 'POST /role-permissions');
    } catch (e) { this.toast.error(e); } finally { this.saving = ''; }
  }

  async runCheck(): Promise<void> {
    this.checking = true;
    try { this.result = await this.api.get('/role-permissions/check', { ...this.check }); }
    catch (e) { this.toast.error(e); } finally { this.checking = false; }
  }
  tabChanged(t: string): void { if (t === 'matrix') this.loadMatrix(); }
}
