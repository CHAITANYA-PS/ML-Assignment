/* Pages of the admin stakeholder. Each page is lazy-loaded and guarded by the backend call it needs
 * (canGuard checks the role_permission rules, the same as the sidebar). */
import { Routes } from '@angular/router';
import { canGuard } from '../core/guards';

export const ADMIN_ROUTES: Routes = [
  { path: 'dashboard', title: 'Dashboard · Dsphere', canActivate: [canGuard('GET', '/dashboard/summary')], loadComponent: () => import('./dashboard/dashboard.component').then(m => m.AdminDashboardComponent) },
  { path: 'users', title: 'Users · Dsphere', canActivate: [canGuard('GET', '/app-users')], loadComponent: () => import('./users/users.component').then(m => m.UsersComponent) },
  { path: 'stakeholders', title: 'Stakeholders · Dsphere', canActivate: [canGuard('GET', '/distributor-users')], loadComponent: () => import('./stakeholders/stakeholders.component').then(m => m.StakeholdersComponent) },
  { path: 'access', title: 'Roles and access · Dsphere', canActivate: [canGuard('GET', '/role-permissions')], loadComponent: () => import('./access/access.component').then(m => m.AccessComponent) },
  { path: 'distributors', title: 'Distributors · Dsphere', canActivate: [canGuard('GET', '/distributors')], loadComponent: () => import('./distributors/distributors.component').then(m => m.DistributorsComponent) },
  { path: 'master-data', title: 'Master data · Dsphere', canActivate: [canGuard('GET', '/regions')], loadComponent: () => import('./master-data/master-data.component').then(m => m.MasterDataComponent) },
  { path: 'configuration', title: 'Configuration · Dsphere', canActivate: [canGuard('GET', '/system-configs')], loadComponent: () => import('./configuration/configuration.component').then(m => m.ConfigurationComponent) },
  { path: 'audit', title: 'Audit trail · Dsphere', canActivate: [canGuard('GET', '/audit-logs')], loadComponent: () => import('./audit/audit.component').then(m => m.AuditComponent) },
  { path: 'jobs', title: 'Jobs · Dsphere', canActivate: [canGuard('GET', '/jobs')], loadComponent: () => import('./jobs/jobs.component').then(m => m.JobsComponent) },
  { path: 'exports', title: 'Exports · Dsphere', canActivate: [canGuard('GET', '/exports')], loadComponent: () => import('./exports/exports.component').then(m => m.ExportsComponent) },
  { path: 'notifications', title: 'Notifications · Dsphere', loadComponent: () => import('../common/notifications/notifications.component').then(m => m.NotificationsComponent) },
  { path: 'profile', title: 'My profile · Dsphere', loadComponent: () => import('../common/profile/profile.component').then(m => m.ProfileComponent) },
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
];
