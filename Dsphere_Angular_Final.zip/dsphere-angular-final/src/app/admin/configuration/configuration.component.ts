/* Admin › Configuration: settings the business rules read at run time. */
import { Component } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { Column } from '../../shared/data-table/data-table.types';
import { fmt } from '../../shared/format';
import { FieldSpec } from '../../shared/form-modal/form-fields';
import { PageHeadComponent } from '../../shared/page-head.component';
import { TabsComponent } from '../../shared/tabs.component';

@Component({
  selector: 'app-admin-configuration', standalone: true, imports: [PageHeadComponent, TabsComponent, CrudTableComponent],
  templateUrl: './configuration.component.html'
})
export class ConfigurationComponent {
  readonly tabs = [{ key: 'settings', label: 'System settings' }, { key: 'sla', label: 'Ticket SLA' }, { key: 'weights', label: 'Health score weights' }, { key: 'emission', label: 'Emission factors' }];
  tab = 'settings';
  weightCheck: any = null;

  readonly settingColumns: Column[] = [{ key: 'configKey', label: 'Key', type: 'mono' }, { key: 'configValue', label: 'Value', type: 'strong' }, { key: 'description', label: 'Description' }];
  readonly settingFields: (string | FieldSpec)[] = [{ name: 'configKey', mono: true }, 'configValue', { name: 'description', full: true }];
  readonly settingEdit: (string | FieldSpec)[] = ['configValue', { name: 'description', full: true }];
  readonly slaColumns: Column[] = [{ key: 'ticketPriorityId', label: 'Priority', type: 'ref', ref: 'ticket-priorities' }, { key: 'responseHours', label: 'First response (hours)', type: 'num' }, { key: 'resolutionHours', label: 'Resolution (hours)', type: 'num' }];
  readonly weightColumns: Column[] = [
    { key: 'parameterId', label: 'Parameter', type: 'ref', ref: 'health-parameters' },
    { key: 'weight', label: 'Weight', type: 'strong', value: r => fmt.pct(Number(r.weight) * 100) },
    { key: 'validFrom', label: 'From', type: 'date' }, { key: 'validTo', label: 'To', type: 'date' }
  ];
  readonly weightFields: (string | FieldSpec)[] = ['parameterId', { name: 'weight', hint: '0.25 means 25%. Active weights must total 100%.' }, 'validFrom', 'validTo'];
  readonly emissionColumns: Column[] = [
    { key: 'vehicleTypeId', label: 'Vehicle', type: 'ref', ref: 'vehicle-types' }, { key: 'factorValue', label: 'Factor', type: 'num' },
    { key: 'unit', label: 'Unit' }, { key: 'validFrom', label: 'From', type: 'date' }, { key: 'validTo', label: 'To', type: 'date' }
  ];

  constructor(private api: ApiService) {}

  get weightMessage(): string {
    const c = this.weightCheck;
    if (!c) return '';
    return (c.valid ? `Active weights total ${c.totalPercent}%` : `Active weights total ${c.totalPercent}%; they must total 100%`) + ` · ${(c.weights ?? []).length} active weights`;
  }

  async tabChanged(t: string): Promise<void> { if (t === 'weights') await this.checkWeights(); }
  async checkWeights(): Promise<void> { this.weightCheck = await this.api.get('/health-scores/weights/check').catch(() => null); }
}
