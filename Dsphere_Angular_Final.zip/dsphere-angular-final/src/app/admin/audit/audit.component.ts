/* Admin › Audit trail: every create, update, delete and status change with before and after values; and the user activity log. */
import { Component } from '@angular/core';
import { RefService } from '../../core/ref.service';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter } from '../../shared/data-table/data-table.types';
import { ModalComponent } from '../../shared/modal.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { TabsComponent } from '../../shared/tabs.component';
import { FORMAT_PIPES } from '../../shared/pipes';

const ACTION_TONE: Record<string, string> = { CREATE: 'ok', UPDATE: 'info', DELETE: 'danger' };
interface Diff { field: string; before: string; after: string; }

@Component({
  selector: 'app-admin-audit', standalone: true, imports: [PageHeadComponent, TabsComponent, DataTableComponent, ModalComponent, ...FORMAT_PIPES],
  templateUrl: './audit.component.html'
})
export class AuditComponent {
  readonly tabs = [{ key: 'changes', label: 'Data changes' }, { key: 'activity', label: 'User activity' }];
  tab = 'changes';
  open: any = null;
  diff: Diff[] = [];

  readonly changeColumns: Column[] = [
    { key: 'createdAt', label: 'When', type: 'dateTime' },
    { key: 'userId', label: 'Who', type: 'ref', ref: 'app-users' },
    { key: 'action', label: 'Action', type: 'pill', tone: r => ACTION_TONE[r.action] ?? 'warn' },
    { key: 'entityName', label: 'Record', type: 'mono', value: r => `${r.entityName} #${r.entityId}` }
  ];
  readonly changeFilters: Filter[] = [{ key: 'action', label: 'Action', options: ['CREATE', 'UPDATE', 'DELETE', 'STATUS_CHANGE'] }];
  readonly activityColumns: Column[] = [
    { key: 'createdAt', label: 'When', type: 'dateTime' }, { key: 'userId', label: 'User', type: 'ref', ref: 'app-users' },
    { key: 'action', label: 'Action', type: 'pill' }, { key: 'details', label: 'Details' }, { key: 'ipAddress', label: 'IP address', type: 'mono' }
  ];

  constructor(public ref: RefService) {}

  show(a: any): void {
    const parse = (s: any): Record<string, any> => { try { return s ? JSON.parse(s) : {}; } catch { return { value: s }; } };
    const o = parse(a.oldValue), n = parse(a.newValue);
    const show = (v: any) => (v == null ? '–' : JSON.stringify(v));
    this.diff = [...new Set([...Object.keys(o), ...Object.keys(n)])]
      .filter(k => JSON.stringify(o[k]) !== JSON.stringify(n[k]))
      .map(k => ({ field: k, before: show(o[k]), after: show(n[k]) }));
    this.open = a;
  }
}
