/* Admin › Master data: the lookup tables the rest of the platform refers to. A row still in use cannot be deleted (409 RECORD_IN_USE). */
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SCHEMA } from '../../core/schema';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { Column } from '../../shared/data-table/data-table.types';
import { fmt } from '../../shared/format';
import { PageHeadComponent } from '../../shared/page-head.component';

export const MASTER: [string, string[]][] = [
  ['Geography and organisation', ['regions', 'departments', 'manufacturers', 'warehouses', 'categories']],
  ['Order and delivery', ['order-statuses', 'shipment-statuses', 'exchange-statuses', 'return-categories', 'movement-types', 'inventory-document-types', 'vehicle-types']],
  ['Tickets', ['ticket-statuses', 'ticket-priorities', 'ticket-categories', 'sla-policies']],
  ['Finance', ['invoice-statuses', 'payment-statuses', 'payment-methods']],
  ['Performance and risk', ['commitment-statuses', 'recovery-plan-statuses', 'measurement-units', 'risk-levels', 'risk-bands', 'continuity-status-types', 'activity-types', 'reporting-periods', 'notification-types']]
];

@Component({
  selector: 'app-admin-master-data', standalone: true, imports: [PageHeadComponent, CrudTableComponent],
  templateUrl: './master-data.component.html'
})
export class MasterDataComponent implements OnInit {
  readonly groups = MASTER.map(([g, items]) => ({ label: g, items: items.filter(r => SCHEMA.resources[r]) }));
  res = 'regions';
  columns: Record<string, Column[]> = {};

  constructor(private route: ActivatedRoute, private router: Router) {
    for (const [, items] of MASTER) for (const r of items) if (SCHEMA.resources[r]) this.columns[r] = this.autoColumns(r);
  }
  ngOnInit(): void {
    const t = this.route.snapshot.queryParamMap.get('table');
    if (t && this.columns[t]) this.res = t;
  }
  title(r: string): string { return fmt.label(SCHEMA.resources[r].entity.replace(/([a-z])([A-Z])/g, '$1 $2')); }
  sort(r: string): string { return `${SCHEMA.resources[r].idField},asc`; }
  show(r: string): void { this.res = r; this.router.navigate([], { queryParams: { table: r }, replaceUrl: true }); }

  private autoColumns(res: string): Column[] {
    const R = SCHEMA.resources[res];
    return R.fields.filter(f => !f.writeOnly && f.name !== R.idField && !['createdAt', 'updatedAt'].includes(f.name)).slice(0, 6).map(f => {
      const label = f.label.replace(/ id$/i, '');
      if (f.refPath) return { key: f.name, label, type: 'ref', ref: f.refPath } as Column;
      if (f.type === 'Boolean') return { key: f.name, label, type: 'bool' } as Column;
      if (f.type === 'LocalDate') return { key: f.name, label, type: 'date' } as Column;
      if (['BigDecimal', 'Integer'].includes(f.type)) return { key: f.name, label, type: 'num' } as Column;
      if (f.options || /status$/i.test(f.name)) return { key: f.name, label, type: 'pill' } as Column;
      if (/Name$/.test(f.name)) return { key: f.name, label, type: 'strong' } as Column;
      return { key: f.name, label } as Column;
    });
  }
}
