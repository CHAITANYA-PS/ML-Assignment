/* Admin › Dashboard: users, access, data health and background jobs. */
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { metric } from '../../core/dashboard-summary';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { COLORS, barChart, donut } from '../../shared/charts';
import { ChartComponent } from '../../shared/chart.component';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';
import { STAKEHOLDERS } from '../stakeholders';

const ACTION_TONE: Record<string, string> = { CREATE: 'ok', UPDATE: 'info', DELETE: 'danger' };

@Component({
  selector: 'app-admin-dashboard', standalone: true,
  imports: [RouterLink, PageHeadComponent, KpiCardComponent, ChartComponent, StatusPillComponent, ...FORMAT_PIPES],
  templateUrl: './dashboard.component.html'
})
export class AdminDashboardComponent implements OnInit {
  readonly ICONS = ICONS;
  loaded = false;
  distributors = 0;
  activeDistributors = 0;
  openTickets = 0;
  slaBreached = 0;
  orders = 0;
  orderValue = 0;
  users: any[] = [];
  pending: any[] = [];
  lastRuns: any[] = [];
  failed = 0;
  audit: any[] = [];
  noRole = 0;
  rolesChart = '';
  ordersChart = '';

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService, private toast: ToastService) {}

  get firstName(): string { return (this.auth.me()?.userName ?? '').split(' ')[0]; }
  get activeUsers(): number { return this.users.filter(u => u.status === 'Active').length; }
  actionTone(a: string): string { return ACTION_TONE[a] ?? 'warn'; }
  fmtNum(v: any): string { return fmt.num(v); }

  async ngOnInit(): Promise<void> {
    this.ref.invalidate('user-roles');
    // One failing call must not leave the whole dashboard blank: each part falls back to empty and the first problem is shown.
    let problem: any = null;
    const safe = <T>(p: Promise<T>, empty: T): Promise<T> => p.catch(e => { problem ??= e; return empty; });
    const [sum, users, runs, audit, orders, items] = await Promise.all([
      safe<any>(this.api.get('/dashboard/summary'), null), safe<any[]>(this.api.all('/app-users'), []),
      safe<any[]>(this.api.all('/job-runs', { sort: 'startedAt,desc' }), []),
      safe<any>(this.api.page('/audit-logs', { sort: 'createdAt,desc', page: 0, size: 7 }), { rows: [] }),
      safe<any[]>(this.api.all('/distributor-orders'), []), safe<any[]>(this.api.all('/order-items'), [])
    ]);
    await safe(this.ref.ensure(['user-roles', 'roles', 'app-users', 'order-statuses']), undefined);
    if (problem) this.toast.error(problem);
    this.distributors = Number(metric(sum, 'Distributors') ?? 0);
    this.activeDistributors = Number(metric(sum, 'Active distributors') ?? 0);
    this.openTickets = Number(metric(sum, 'Open tickets') ?? 0);
    this.slaBreached = Number(metric(sum, 'Tickets past SLA') ?? 0);
    this.orders = orders.length;
    this.orderValue = items.reduce((a: number, i: any) => a + Number(i.quantity) * Number(i.unitPrice), 0);
    const byStatus: Record<string, number> = {};
    for (const o of orders) { const n = this.ref.name('order-statuses', o.orderStatusId); byStatus[n] = (byStatus[n] || 0) + 1; }
    this.users = users; this.audit = audit.rows;
    this.pending = users.filter(u => u.status === 'Pending');
    const seen = new Map<string, any>();
    for (const r of runs) if (!seen.has(r.jobName)) seen.set(r.jobName, r);
    this.lastRuns = [...seen.values()];
    this.failed = this.lastRuns.filter(r => r.status !== 'SUCCESS').length;
    const ur = this.ref.rows('user-roles');
    this.noRole = users.filter(u => !ur.some((x: any) => x.userId === u.userId)).length;
    this.rolesChart = donut({ sub: 'users', items: STAKEHOLDERS.map((s, i) => ({ label: s.name, color: COLORS[i], value: ur.filter((x: any) => this.ref.get('roles', x.roleId)?.roleCode === s.code).length })) });
    const statuses = ['Placed', 'Approved', 'Processing', 'Dispatched', 'Delivered', 'Cancelled'];
    this.ordersChart = barChart({ labels: statuses, series: [{ name: 'Orders', values: statuses.map(s => byStatus[s] || 0) }], height: 200 });
    this.loaded = true;
  }
  roleOf(userId: number): string {
    const ur = this.ref.rows('user-roles').find((x: any) => x.userId === userId);
    return ur ? this.ref.name('roles', ur.roleId) : 'No role yet';
  }
  async activate(u: any): Promise<void> {
    try {
      await this.api.put(`/app-users/${u.userId}`, { status: 'Active', version: u.version });
      this.toast.show(`${u.userName} activated`, 'ok', `PUT /app-users/${u.userId}`);
      this.pending = this.pending.filter(x => x !== u);
    } catch (e) { this.toast.error(e); }
  }
}
