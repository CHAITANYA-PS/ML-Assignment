/* The six stakeholder tables. One user has exactly one of them; creating the stakeholder row gives the user_role. */
import { FieldSpec } from '../shared/form-modal/form-fields';

export interface Stakeholder { code: string; res: string; name: string; link: FieldSpec; }

export const STAKEHOLDERS: Stakeholder[] = [
  { code: 'SYSTEM_ADMIN', res: 'system-admins', name: 'System Admin', link: { name: 'adminLevel', label: 'Admin level', type: 'select', options: ['Standard', 'Senior', 'Super Admin'], required: true, full: true } },
  { code: 'MANUFACTURER', res: 'manufacturer-users', name: 'Manufacturer', link: { name: 'manufacturerId', label: 'Manufacturer', required: true, full: true } },
  { code: 'DISTRIBUTOR', res: 'distributor-users', name: 'Distributor', link: { name: 'distributorId', label: 'Distributor', required: true, full: true } },
  { code: 'SALES_MANAGER', res: 'sales-managers', name: 'Sales Manager', link: { name: 'regionId', label: 'Region', required: true, full: true } },
  { code: 'FINANCE_MANAGER', res: 'finance-managers', name: 'Finance Manager', link: { name: 'departmentId', label: 'Department', required: true, full: true } },
  { code: 'RECOVERY_MANAGER', res: 'recovery-managers', name: 'Recovery Manager', link: { name: 'regionId', label: 'Region', required: true, full: true } }
];
