/* Admin › Stakeholders: the six stakeholder tables. Adding a user here gives that role; a user with another role is refused. */
import { Component, OnInit } from '@angular/core';
import { RefService } from '../../core/ref.service';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { Column } from '../../shared/data-table/data-table.types';
import { FieldSpec } from '../../shared/form-modal/form-fields';
import { PageHeadComponent } from '../../shared/page-head.component';
import { TabsComponent } from '../../shared/tabs.component';
import { STAKEHOLDERS, Stakeholder } from '../stakeholders';

const LINK_COL: Record<string, Column> = {
  manufacturerId: { key: 'manufacturerId', label: 'Manufacturer', type: 'ref', ref: 'manufacturers' },
  distributorId: { key: 'distributorId', label: 'Distributor', type: 'ref', ref: 'distributors' },
  regionId: { key: 'regionId', label: 'Region', type: 'ref', ref: 'regions' },
  departmentId: { key: 'departmentId', label: 'Department', type: 'ref', ref: 'departments' },
  adminLevel: { key: 'adminLevel', label: 'Admin level', type: 'pill' }
};

@Component({
  selector: 'app-admin-stakeholders', standalone: true, imports: [PageHeadComponent, TabsComponent, CrudTableComponent],
  templateUrl: './stakeholders.component.html'
})
export class StakeholdersComponent implements OnInit {
  readonly STAKEHOLDERS = STAKEHOLDERS;
  readonly tabs = STAKEHOLDERS.map(s => ({ key: s.res, label: s.name }));
  tab = STAKEHOLDERS[0].res;
  ready = false;
  columns: Record<string, Column[]> = {};
  fields: Record<string, FieldSpec[]> = {};
  editFields: Record<string, FieldSpec[]> = {};

  constructor(private ref: RefService) {}

  async ngOnInit(): Promise<void> {
    await this.refresh();
    for (const s of STAKEHOLDERS) {
      this.columns[s.res] = [
        { key: 'userId', label: 'User', type: 'strong', value: r => this.ref.get('app-users', r.userId)?.userName ?? `User #${r.userId}`, sub: r => this.ref.get('app-users', r.userId)?.email ?? '' },
        LINK_COL[s.link.name],
        { key: 'status', label: 'Status', type: 'pill', value: r => this.ref.get('app-users', r.userId)?.status }
      ];
      this.editFields[s.res] = [s.link];
    }
    this.ready = true;
  }
  /** Users without a role are the only ones that can be added. Called again after each change. */
  async refresh(): Promise<void> {
    this.ref.invalidate('user-roles'); this.ref.invalidate('app-users');
    await this.ref.ensure(['app-users', 'user-roles', 'roles']);
    const withRole = new Set(this.ref.rows('user-roles').map((x: any) => x.userId));
    const free = this.ref.rows('app-users').filter((u: any) => !withRole.has(u.userId)).map((u: any) => [u.userId, `${u.userName} · ${u.email}`] as [any, string]);
    for (const s of STAKEHOLDERS) {
      this.fields[s.res] = [{ name: 'userId', label: 'User', type: 'select', required: true, full: true, options: free, hint: free.length ? 'Only users without a role are listed.' : 'Every user already has a role. Create a user first.' }, s.link];
    }
  }
  /** One function per table, made once (a new function on every check would rebuild the table). */
  readonly describe: Record<string, (r: any) => string> = Object.fromEntries(
    STAKEHOLDERS.map((s: Stakeholder) => [s.res, (r: any) => `${this.ref.get('app-users', r.userId)?.userName ?? 'User'} as ${s.name}`]));
}
