/* Admin › Exports. */
import { Component } from '@angular/core';
import { ReportsComponent } from '../../common/reports/reports.component';

@Component({
  selector: 'app-admin-exports', standalone: true, imports: [ReportsComponent],
  template: `<app-reports [defaults]="defaults" />`
})
export class ExportsComponent {
  readonly defaults = ['distributors', 'app-users', 'audit-logs', 'distributor-orders', 'invoices', 'tickets'];
}
