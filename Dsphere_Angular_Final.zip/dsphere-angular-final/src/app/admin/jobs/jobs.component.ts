/* Admin › Jobs: the scheduled jobs, "run now" and the run history. */
import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { ToastService } from '../../core/toast.service';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter } from '../../shared/data-table/data-table.types';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';

@Component({
  selector: 'app-admin-jobs', standalone: true, imports: [PageHeadComponent, DataTableComponent, StatusPillComponent, ...FORMAT_PIPES],
  templateUrl: './jobs.component.html'
})
export class JobsComponent implements OnInit {
  @ViewChild(DataTableComponent) runs?: DataTableComponent;
  jobs: any[] = [];
  last: Record<string, any> = {};
  running = '';
  readonly columns: Column[] = [
    { key: 'jobName', label: 'Job', type: 'mono' }, { key: 'status', label: 'Result', type: 'pill' },
    { key: 'startedAt', label: 'Started', type: 'dateTime' }, { key: 'finishedAt', label: 'Finished', type: 'dateTime' },
    { key: 'summary', label: 'Summary' }, { key: 'triggeredBy', label: 'Triggered by', type: 'ref', ref: 'app-users' }
  ];
  readonly filters: Filter[] = [{ key: 'status', label: 'Result', options: ['SUCCESS', 'FAILED'] }];

  constructor(private api: ApiService, public auth: AuthService, private toast: ToastService) {}

  async ngOnInit(): Promise<void> { await this.load(); }
  async load(): Promise<void> {
    const [jobs, runs] = await Promise.all([this.api.get<any[]>('/jobs'), this.api.all('/job-runs', { sort: 'startedAt,desc' })]);
    this.jobs = jobs;
    this.last = {};
    for (const r of runs) if (!this.last[r.jobName]) this.last[r.jobName] = r;
  }
  async run(name: string): Promise<void> {
    this.running = name;
    try {
      const r = await this.api.post<any>(`/jobs/${name}/run`);
      this.toast.show(`${name} finished`, 'ok', r?.message || `POST /jobs/${name}/run`);
      await this.load();
      this.runs?.reload();
    } catch (e) { this.toast.error(e); } finally { this.running = ''; }
  }
}
