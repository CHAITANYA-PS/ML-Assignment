/* Recovery › Reports. */
import { Component } from '@angular/core';
import { ReportsComponent } from '../../common/reports/reports.component';

@Component({
  selector: 'app-recovery-reports', standalone: true, imports: [ReportsComponent],
  template: `<app-reports [defaults]="defaults" />`
})
export class RecoveryReportsComponent { readonly defaults = ['tickets', 'recovery-plans', 'distributors']; }
