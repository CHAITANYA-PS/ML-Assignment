/* Recovery › SLA and escalations. */
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { RefService } from '../../core/ref.service';
import { TicketDrawerComponent } from '../../common/ticket-drawer/ticket-drawer.component';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column } from '../../shared/data-table/data-table.types';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { FORMAT_PIPES } from '../../shared/pipes';
import { breached } from '../tickets';

@Component({
  selector: 'app-recovery-sla', standalone: true, imports: [PageHeadComponent, KpiCardComponent, DataTableComponent, TicketDrawerComponent, ...FORMAT_PIPES],
  templateUrl: './sla.component.html'
})
export class SlaComponent implements OnInit {
  readonly ICONS = ICONS;
  f = fmt;
  loaded = false;
  policies: any[] = [];
  late: any[] = [];
  met = 0;
  resolved = 0;
  escalated = 0;
  maxLevel = 0;
  ticketId: any = null;
  readonly columns: Column[] = [
    { key: 'createdAt', label: 'When', type: 'dateTime' },
    { key: 'ticketId', label: 'Ticket', type: 'ref', ref: 'tickets' },
    { key: 'escalationLevel', label: 'Level', type: 'pill', value: r => `Level ${r.escalationLevel}`, tone: r => (r.escalationLevel >= 2 ? 'danger' : 'warn') },
    { key: 'escalatedTo', label: 'To', type: 'ref', ref: 'app-users' },
    { key: 'reason', label: 'Reason' }
  ];

  constructor(private api: ApiService, public ref: RefService) {}

  async ngOnInit(): Promise<void> { await this.load(); }
  async load(): Promise<void> {
    // A failing call leaves that part empty instead of hiding the whole page.
    await this.ref.ensure(['ticket-statuses', 'ticket-priorities', 'distributors', 'app-users', 'tickets']).catch(() => undefined);
    const [tickets, pol] = await Promise.all([this.api.all('/tickets').catch(() => [] as any[]), this.api.all('/sla-policies').catch(() => [] as any[])]);
    this.policies = pol;
    this.late = tickets.filter(t => breached(this.ref, t));
    const closed = tickets.filter(t => t.resolvedAt);
    this.resolved = closed.length;
    this.met = closed.filter(t => !t.slaDueAt || t.resolvedAt <= t.slaDueAt).length;
    this.escalated = tickets.filter(t => t.escalationLevel > 0).length;
    this.maxLevel = Math.max(0, ...tickets.map(t => t.escalationLevel || 0));
    this.loaded = true;
  }
  get metPct(): string { return fmt.pct(this.resolved ? (this.met / this.resolved) * 100 : 100); }
}
