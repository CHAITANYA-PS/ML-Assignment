/* Recovery › Underperforming distributors: below the recovery threshold this month; run the recovery-mode check. */
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { ToastService } from '../../core/toast.service';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { MeterComponent } from '../../shared/meter.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';

@Component({
  selector: 'app-recovery-underperformers', standalone: true, imports: [PageHeadComponent, KpiCardComponent, MeterComponent, StatusPillComponent, ...FORMAT_PIPES],
  templateUrl: './underperformers.component.html'
})
export class UnderperformersComponent implements OnInit {
  readonly ICONS = ICONS;
  f = fmt;
  loaded = false;
  perf: any[] = [];
  inPlan = new Set<any>();
  running = false;

  constructor(private api: ApiService, public auth: AuthService, private toast: ToastService) {}

  async ngOnInit(): Promise<void> { await this.load(); }
  async load(): Promise<void> {
    const [perf, plans] = await Promise.all([this.api.get<any[]>('/performance'), this.api.all('/recovery-plans')]);
    this.perf = perf;
    this.inPlan = new Set(plans.filter(p => !p.closedAt).map(p => p.distributorId));
    this.loaded = true;
  }
  get below(): any[] { return this.perf.filter(p => p.status === 'RECOVERY'); }
  get covered(): number { return this.below.filter(p => this.inPlan.has(p.distributorId)).length; }
  get threshold(): number { return this.perf[0]?.thresholdPercent ?? 60; }
  get canRun(): boolean { return this.auth.can('POST', '/jobs/recovery-mode/run'); }
  async run(): Promise<void> {
    this.running = true;
    try {
      const r = await this.api.post<any>('/jobs/recovery-mode/run');
      this.toast.show('Recovery-mode check finished', 'ok', r?.message);
      await this.load();
    } catch (e) { this.toast.error(e); } finally { this.running = false; }
  }
}
