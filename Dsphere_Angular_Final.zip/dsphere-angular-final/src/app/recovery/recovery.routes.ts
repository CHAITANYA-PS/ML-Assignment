/* Pages of the recovery stakeholder. Each page is lazy-loaded and guarded by the backend call it needs
 * (canGuard checks the role_permission rules, the same as the sidebar). */
import { Routes } from '@angular/router';
import { canGuard } from '../core/guards';

export const RECOVERY_ROUTES: Routes = [
  { path: 'dashboard', title: 'Dashboard · Dsphere', canActivate: [canGuard('GET', '/dashboard/summary')], loadComponent: () => import('./dashboard/dashboard.component').then(m => m.RecoveryDashboardComponent) },
  { path: 'tickets', title: 'Ticket queue · Dsphere', canActivate: [canGuard('GET', '/tickets')], loadComponent: () => import('./tickets/tickets.component').then(m => m.RecoveryTicketsComponent) },
  { path: 'sla', title: 'SLA and escalations · Dsphere', canActivate: [canGuard('GET', '/escalations')], loadComponent: () => import('./sla/sla.component').then(m => m.SlaComponent) },
  { path: 'disputes', title: 'Delivery disputes · Dsphere', canActivate: [canGuard('GET', '/delivery-discrepancies')], loadComponent: () => import('./disputes/disputes.component').then(m => m.DisputesComponent) },
  { path: 'plans', title: 'Recovery plans · Dsphere', canActivate: [canGuard('GET', '/recovery-plans')], loadComponent: () => import('./plans/plans.component').then(m => m.PlansComponent) },
  { path: 'underperformers', title: 'Underperformers · Dsphere', canActivate: [canGuard('GET', '/performance')], loadComponent: () => import('./underperformers/underperformers.component').then(m => m.UnderperformersComponent) },
  { path: 'reports', title: 'Reports · Dsphere', canActivate: [canGuard('GET', '/exports')], loadComponent: () => import('./reports/reports.component').then(m => m.RecoveryReportsComponent) },
  { path: 'notifications', title: 'Notifications · Dsphere', loadComponent: () => import('../common/notifications/notifications.component').then(m => m.NotificationsComponent) },
  { path: 'profile', title: 'My profile · Dsphere', loadComponent: () => import('../common/profile/profile.component').then(m => m.ProfileComponent) },
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
];
