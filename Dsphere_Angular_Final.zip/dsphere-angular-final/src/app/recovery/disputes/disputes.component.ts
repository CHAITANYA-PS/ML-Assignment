/* Recovery › Delivery disputes: shortages and damage reported at delivery. Each opened a ticket. */
import { Component, OnInit, ViewChild } from '@angular/core';
import { RefService } from '../../core/ref.service';
import { TicketDrawerComponent } from '../../common/ticket-drawer/ticket-drawer.component';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter } from '../../shared/data-table/data-table.types';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-recovery-disputes', standalone: true, imports: [PageHeadComponent, DataTableComponent, TicketDrawerComponent],
  template: `
  <app-page-head eyebrow="Tickets" title="Delivery disputes" text="Shortages and damage reported when distributors confirmed deliveries. Each one opened a ticket: click a row to open it." />
  <section class="card"><div class="card-body flush">
    <app-data-table path="/delivery-discrepancies" [columns]="columns" [filters]="filters" sort="discrepancyId,desc"
                    emptyTitle="No disputes" emptyText="Disputes appear when a distributor confirms a delivery with missing or damaged items." (rowClick)="open($event)" />
  </div></section>
  @if (ticketId) { <app-ticket-drawer [ticketId]="ticketId" (closed)="ticketId = null; table?.reload()" /> }`
})
export class DisputesComponent implements OnInit {
  @ViewChild(DataTableComponent) table?: DataTableComponent;
  ticketId: any = null;
  readonly filters: Filter[] = [{ key: 'discrepancyType', label: 'Type', options: ['SHORTAGE', 'DAMAGED', 'EXCESS', 'WRONG_ITEM'] }];
  readonly columns: Column[] = [
    { key: 'createdAt', label: 'Reported', type: 'dateTime' },
    { key: 'distributor', label: 'Distributor', sortable: false, value: r => this.distributor(r) },
    { key: 'shipment', label: 'Shipment', type: 'mono', sortable: false, value: r => this.shipment(r) },
    { key: 'product', label: 'Product · batch', sortable: false, value: r => this.product(r) },
    { key: 'discrepancyType', label: 'Problem', type: 'pill', value: r => TYPE[r.discrepancyType] ?? r.discrepancyType },
    { key: 'quantity', label: 'Units', type: 'num' },
    { key: 'ticketId', label: 'Ticket', type: 'ref', ref: 'tickets', sub: r => this.ticketStatus(r) }
  ];

  constructor(private ref: RefService) {}

  async ngOnInit(): Promise<void> {
    await this.ref.ensure(['delivery-receipts', 'shipment-items', 'shipments', 'product-batches', 'products', 'distributors', 'tickets', 'ticket-statuses']).catch(() => undefined);
    this.table?.reload(true);
  }
  private item(r: any): any { return this.ref.get('shipment-items', r.shipmentItemId); }
  distributor(r: any): string {
    const rec = this.ref.get('delivery-receipts', r.deliveryReceiptId);
    return rec ? this.ref.name('distributors', rec.distributorId) : '–';
  }
  shipment(r: any): string {
    const i = this.item(r);
    return i ? this.ref.name('shipments', i.shipmentId) : '–';
  }
  product(r: any): string {
    const b = this.ref.get('product-batches', this.item(r)?.productBatchId);
    return b ? `${this.ref.name('products', b.productId)} · ${b.batchNumber}` : '–';
  }
  ticketStatus(r: any): string {
    const t = this.ref.get('tickets', r.ticketId);
    return t ? this.ref.name('ticket-statuses', t.ticketStatusId) : '';
  }
  open(r: any): void { if (r.ticketId) this.ticketId = r.ticketId; }
}

const TYPE: Record<string, string> = { SHORTAGE: 'Missing', DAMAGED: 'Damaged', EXCESS: 'Extra', WRONG_ITEM: 'Wrong item' };
