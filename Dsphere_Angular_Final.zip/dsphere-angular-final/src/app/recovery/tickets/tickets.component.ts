/* Recovery › Ticket queue: all tickets, and the ones assigned to me. */
import { Component } from '@angular/core';
import { TicketsListComponent } from '../../common/tickets-list/tickets-list.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { TabsComponent } from '../../shared/tabs.component';

@Component({
  selector: 'app-recovery-tickets', standalone: true, imports: [PageHeadComponent, TabsComponent, TicketsListComponent],
  template: `
  <app-page-head eyebrow="Tickets" title="Ticket queue" text="Assign, work on, resolve and close tickets. Resolving needs the findings and the corrective action. Tickets past their SLA are escalated by the SLA job." />
  <section class="card"><div class="card-body">
    <app-tabs [tabs]="tabs" [(active)]="tab" />
    @if (tab === 'all') { <app-tickets-list [allowCreate]="true" /> } @else { <app-tickets-list [mine]="true" /> }
  </div></section>`
})
export class RecoveryTicketsComponent {
  readonly tabs = [{ key: 'all', label: 'All tickets' }, { key: 'mine', label: 'Assigned to me' }];
  tab = 'all';
}
