/* Ticket helpers shared by the recovery pages. */
import { RefService } from '../core/ref.service';

export const isOpen = (ref: RefService, t: any) => !['Resolved', 'Closed'].includes(ref.name('ticket-statuses', t.ticketStatusId));
export const breached = (ref: RefService, t: any) => isOpen(ref, t) && !!t.slaDueAt && new Date(t.slaDueAt) < new Date();
