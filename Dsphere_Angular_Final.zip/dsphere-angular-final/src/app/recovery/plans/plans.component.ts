/* Recovery › Recovery plans: an amount to recover, milestones with due dates, and an outcome when closed. */
import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { meter } from '../../shared/charts';
import { Column, Filter } from '../../shared/data-table/data-table.types';
import { fmt, nice, todayIso } from '../../shared/format';
import { FormModalComponent } from '../../shared/form-modal/form-modal.component';
import { FieldSpec, FormState, fieldsFor } from '../../shared/form-modal/form-fields';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { MeterComponent } from '../../shared/meter.component';
import { ModalComponent } from '../../shared/modal.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';

const MS_TONE: Record<string, string> = { COMPLETED: 'ok', MISSED: 'danger', PENDING: 'warn' };

@Component({
  selector: 'app-recovery-plans', standalone: true,
  imports: [PageHeadComponent, CrudTableComponent, ModalComponent, FormModalComponent, KpiCardComponent, MeterComponent, StatusPillComponent, ...FORMAT_PIPES],
  templateUrl: './plans.component.html'
})
export class PlansComponent implements OnInit {
  @ViewChild(CrudTableComponent) table?: CrudTableComponent;
  readonly ICONS = ICONS;
  readonly MS_TONE = MS_TONE;
  f = fmt;
  plan: any = null;
  prog: any = null;
  milestones: any[] = [];
  form: FormState | null = null;
  readonly defaults = { startDate: todayIso() };
  readonly filters: Filter[] = [{ key: 'recoveryStatusId', label: 'Status', ref: 'recovery-plan-statuses' }];
  readonly fields: (string | FieldSpec)[] = ['distributorId', 'targetAmount', 'startDate', 'endDate', 'recoveryStatusId'];
  readonly columns: Column[] = [
    { key: 'distributorId', label: 'Distributor', type: 'ref', ref: 'distributors' },
    { key: 'recoveryStatusId', label: 'Status', type: 'status', ref: 'recovery-plan-statuses' },
    { key: 'recovered', label: 'Recovered', html: r => { const pct = r.targetAmount ? (Number(r.recoveredAmount) / Number(r.targetAmount)) * 100 : 0; return `<div style="min-width:170px">${meter(pct)}<div class="cell-sub">${fmt.money(r.recoveredAmount)} of ${fmt.money(r.targetAmount)}</div></div>`; } },
    { key: 'recoveryMode', label: 'Mode', type: 'pill', value: r => (r.recoveryMode ? 'Automatic' : 'Manual'), tone: r => (r.recoveryMode ? 'info' : 'neutral') },
    { key: 'endDate', label: 'Ends', type: 'date' },
    { key: 'outcome', label: 'Outcome', type: 'pill', value: r => r.outcome || 'Open', tone: r => (r.outcome ? undefined : 'neutral') }
  ];

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService, private toast: ToastService) {}

  beforeCreate = (v: any) => ({ ...v, createdBy: this.auth.me()?.userId, recoveredAmount: 0, recoveryMode: false });
  openRow = (r: any) => { this.show(r); };

  ngOnInit(): void { this.ref.ensure(['distributors', 'recovery-plan-statuses']); }

  async show(plan: any): Promise<void> {
    const id = plan.recoveryPlanId;
    const [prog, ms] = await Promise.all([this.api.get(`/recovery-plans/${id}/progress`), this.api.all('/recovery-milestones', { recoveryPlanId: id, sort: 'dueDate,asc' })]);
    this.prog = prog; this.milestones = ms; this.plan = plan;
  }
  private async refresh(): Promise<void> {
    const id = this.plan.recoveryPlanId;
    this.table?.reload();
    this.show(await this.api.get(`/recovery-plans/${id}`));
  }
  canComplete(m: any): boolean { return m.status !== 'COMPLETED' && !this.plan.closedAt && this.auth.can('POST', `/recovery-milestones/${m.milestoneId}/complete`); }
  get msTotal(): number { return (this.prog?.milestones ?? []).length; }
  get msDone(): number { return (this.prog?.milestones ?? []).filter((m: any) => m.status === 'COMPLETED').length; }
  get msMissed(): number { return (this.prog?.milestones ?? []).filter((m: any) => m.status === 'MISSED').length; }
  get isClosed(): boolean { return !!this.prog?.outcome || !!this.plan?.closedAt; }
  get canAddMilestone(): boolean { return !this.plan?.closedAt && this.auth.can('POST', '/recovery-milestones'); }
  get canClose(): boolean { return !this.plan?.closedAt && this.auth.can('POST', `/recovery-plans/${this.plan?.recoveryPlanId}/close`); }
  nice(v: any): string { return nice(v); }

  complete(m: any): void {
    const path = `/recovery-milestones/${m.milestoneId}/complete`;
    this.form = {
      title: 'Complete milestone', sub: m.title, size: 'narrow', submitLabel: 'Complete',
      value: { achievedAmount: Number(m.targetAmount) },
      fields: [{ name: 'achievedAmount', label: 'Amount achieved', type: 'decimal', zeroOrMore: true, required: true, full: true }],
      submit: v => this.api.post(path, v).then(async x => { this.toast.show('Milestone completed', 'ok', 'POST ' + path); await this.refresh(); return x; })
    };
  }
  addMilestone(): void {
    const id = this.plan.recoveryPlanId;
    this.form = {
      title: 'Add milestone',
      fields: fieldsFor('recovery-milestones', [{ name: 'title', full: true, required: true }, { name: 'targetAmount', required: true }, { name: 'dueDate', required: true }]),
      submit: v => this.api.post('/recovery-milestones', { ...v, recoveryPlanId: id, status: 'PENDING', achievedAmount: 0 }).then(async x => { this.toast.show('Milestone added', 'ok', 'POST /recovery-milestones'); await this.refresh(); return x; })
    };
  }
  closePlan(): void {
    const id = this.plan.recoveryPlanId;
    const pct = this.prog?.progressPercent ?? 0;
    this.form = {
      title: 'Close recovery plan', size: 'narrow', submitLabel: 'Close plan',
      value: { outcome: pct >= 100 ? 'RECOVERED' : pct > 0 ? 'PARTIALLY_RECOVERED' : 'NOT_RECOVERED' },
      fields: [
        { name: 'outcome', label: 'Outcome', type: 'select', options: ['RECOVERED', 'PARTIALLY_RECOVERED', 'NOT_RECOVERED', 'CANCELLED'], required: true, full: true },
        { name: 'remarks', label: 'Remarks', type: 'textarea', max: 1000, full: true }
      ],
      submit: v => this.api.post(`/recovery-plans/${id}/close`, v).then(x => { this.toast.show('Recovery plan closed', 'ok', `POST /recovery-plans/${id}/close`); this.plan = null; this.table?.reload(); return x; })
    };
  }
}
