/* Recovery › Dashboard: tickets against their SLA, escalations, and recovery plans. */
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { PRIORITY_TONE, TicketDrawerComponent } from '../../common/ticket-drawer/ticket-drawer.component';
import { donut } from '../../shared/charts';
import { ChartComponent } from '../../shared/chart.component';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { MeterComponent } from '../../shared/meter.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';
import { breached, isOpen } from '../tickets';

@Component({
  selector: 'app-recovery-dashboard', standalone: true,
  imports: [RouterLink, PageHeadComponent, KpiCardComponent, ChartComponent, MeterComponent, StatusPillComponent, TicketDrawerComponent, ...FORMAT_PIPES],
  templateUrl: './dashboard.component.html'
})
export class RecoveryDashboardComponent implements OnInit {
  readonly ICONS = ICONS;
  readonly PRIORITY_TONE = PRIORITY_TONE;
  f = fmt;
  loaded = false;
  open: any[] = [];
  urgent: any[] = [];
  unassigned = 0;
  mine = 0;
  late = 0;
  escalations = 0;
  plans: any[] = [];
  target = 0;
  got = 0;
  chart = '';
  ticketId: any = null;

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService) {}
  get firstName(): string { return (this.auth.me()?.userName ?? '').split(' ')[0]; }
  isLate(t: any): boolean { return breached(this.ref, t); }
  prio(t: any): string { return this.ref.name('ticket-priorities', t.ticketPriorityId); }
  pct(p: any): number { return p.targetAmount ? (Number(p.recoveredAmount) / Number(p.targetAmount)) * 100 : 0; }

  async ngOnInit(): Promise<void> { await this.load(); }
  async load(): Promise<void> {
    await this.ref.ensure(['ticket-statuses', 'ticket-priorities', 'distributors', 'app-users']);
    const [tickets, plans, escs] = await Promise.all([this.api.all('/tickets'), this.api.all('/recovery-plans'), this.api.all('/escalations')]);
    const me = this.auth.me()!.userId;
    this.open = tickets.filter(t => isOpen(this.ref, t));
    this.unassigned = this.open.filter(t => !t.assignedTo).length;
    this.mine = this.open.filter(t => t.assignedTo === me).length;
    this.late = this.open.filter(t => breached(this.ref, t)).length;
    this.escalations = escs.length;
    this.urgent = [...this.open].sort((a, b) => String(a.slaDueAt).localeCompare(String(b.slaDueAt))).slice(0, 6);
    this.plans = plans.filter(p => !p.closedAt);
    this.target = this.plans.reduce((a, p) => a + Number(p.targetAmount), 0);
    this.got = this.plans.reduce((a, p) => a + Number(p.recoveredAmount), 0);
    const prios = ['Critical', 'High', 'Medium', 'Low'];
    const colors = ['var(--danger)', 'var(--warn)', 'var(--info)', 'var(--neutral)'];
    this.chart = donut({ items: prios.map((p, i) => ({ label: p, color: colors[i], value: this.open.filter(t => this.prio(t) === p).length })), sub: 'open' });
    this.loaded = true;
  }
}
