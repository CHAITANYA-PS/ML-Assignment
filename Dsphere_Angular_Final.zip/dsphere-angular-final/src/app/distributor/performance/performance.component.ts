/* Distributor › Performance: sales against targets per period, and the health score. */
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { barChart, lineChart } from '../../shared/charts';
import { ChartComponent } from '../../shared/chart.component';
import { fmt } from '../../shared/format';
import { MeterComponent } from '../../shared/meter.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';

@Component({
  selector: 'app-distributor-performance', standalone: true, imports: [PageHeadComponent, ChartComponent, MeterComponent, StatusPillComponent, ...FORMAT_PIPES],
  templateUrl: './performance.component.html'
})
export class PerformanceComponent implements OnInit {
  perf: any[] = [];
  barHtml = '';
  lineHtml = '';
  loaded = false;

  constructor(private api: ApiService, private auth: AuthService, private ref: RefService) {}

  async ngOnInit(): Promise<void> {
    const did = this.auth.me()!.distributorId;
    await this.ref.ensure(['reporting-periods']);
    const targets = await this.api.all('/sales-targets', { distributorId: did });
    const periods = [...new Set(targets.map(t => t.reportingPeriodId))];
    this.perf = (await Promise.all(periods.map(p => this.api.get(`/performance/${did}`, { reportingPeriodId: p }).catch(() => null)))).filter(Boolean);
    const trend = await this.api.get<any[]>(`/health-scores/${did}/trend`).catch(() => []);
    if (this.perf.length) this.barHtml = barChart({ labels: this.perf.map(p => p.periodName), series: [{ name: 'Target', values: this.perf.map(p => p.target), color: 'var(--brand-200)' }, { name: 'Achieved', values: this.perf.map(p => p.achieved) }], format: fmt.money, wide: true, height: 240 });
    if (trend.length) this.lineHtml = lineChart({ labels: trend.map(h => this.ref.name('reporting-periods', h.reportingPeriodId)), series: [{ name: 'Score', values: trend.map(h => h.totalScore) }], maxValue: 100, height: 200, bands: [{ from: 0, to: 50, color: 'var(--danger-bg)' }] });
    this.loaded = true;
  }
}
