/* Pages of the distributor stakeholder. Each page is lazy-loaded and guarded by the backend call it needs
 * (canGuard checks the role_permission rules, the same as the sidebar). */
import { Routes } from '@angular/router';
import { canGuard } from '../core/guards';

export const DISTRIBUTOR_ROUTES: Routes = [
  { path: 'dashboard', title: 'Dashboard · Dsphere', canActivate: [canGuard('GET', '/dashboard/summary')], loadComponent: () => import('./dashboard/dashboard.component').then(m => m.DistributorDashboardComponent) },
  { path: 'orders', title: 'Orders · Dsphere', canActivate: [canGuard('GET', '/distributor-orders')], loadComponent: () => import('./orders/orders.component').then(m => m.DistributorOrdersComponent) },
  { path: 'deliveries', title: 'Deliveries · Dsphere', canActivate: [canGuard('GET', '/shipments')], loadComponent: () => import('./deliveries/deliveries.component').then(m => m.DeliveriesComponent) },
  { path: 'inventory', title: 'My stock · Dsphere', canActivate: [canGuard('GET', '/stocks/current')], loadComponent: () => import('./inventory/inventory.component').then(m => m.InventoryComponent) },
  { path: 'returns', title: 'Returns and exchange · Dsphere', canActivate: [canGuard('GET', '/product-returns')], loadComponent: () => import('./returns/returns.component').then(m => m.DistributorReturnsComponent) },
  { path: 'tickets', title: 'Support tickets · Dsphere', canActivate: [canGuard('GET', '/tickets')], loadComponent: () => import('./tickets/tickets.component').then(m => m.DistributorTicketsComponent) },
  { path: 'commitments', title: 'Commitments · Dsphere', canActivate: [canGuard('GET', '/commitments')], loadComponent: () => import('./commitments/commitments.component').then(m => m.DistributorCommitmentsComponent) },
  { path: 'performance', title: 'Performance · Dsphere', canActivate: [canGuard('GET', '/performance')], loadComponent: () => import('./performance/performance.component').then(m => m.PerformanceComponent) },
  { path: 'reports', title: 'Reports · Dsphere', canActivate: [canGuard('GET', '/exports')], loadComponent: () => import('./reports/reports.component').then(m => m.DistributorReportsComponent) },
  { path: 'notifications', title: 'Notifications · Dsphere', loadComponent: () => import('../common/notifications/notifications.component').then(m => m.NotificationsComponent) },
  { path: 'profile', title: 'My profile · Dsphere', loadComponent: () => import('../common/profile/profile.component').then(m => m.ProfileComponent) },
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
];
