/* Distributor › Orders: place orders and follow them from Placed to Delivered. */
import { Component } from '@angular/core';
import { OrdersListComponent } from '../../common/orders-list/orders-list.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-distributor-orders', standalone: true, imports: [PageHeadComponent, OrdersListComponent],
  template: `
  <app-page-head eyebrow="Buying" title="Orders" text="Place orders and follow them from Placed to Delivered. You can cancel an order until it is shipped." />
  <section class="card"><div class="card-body flush"><app-orders-list [allowCreate]="true" /></div></section>`
})
export class DistributorOrdersComponent {}
