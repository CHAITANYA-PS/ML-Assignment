/* Distributor › My stock: everything you hold, batch by batch. Sell the batches closest to expiry first. */
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { StockTableComponent } from '../../common/stock-table/stock-table.component';
import { Column } from '../../shared/data-table/data-table.types';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-distributor-inventory', standalone: true, imports: [RouterLink, PageHeadComponent, KpiCardComponent, StockTableComponent],
  template: `
  <app-page-head eyebrow="Buying" title="My stock" text="Everything you hold, batch by batch. Sell the batches closest to expiry first, or ask for a return.">
    @if (auth.can('POST', '/product-returns')) { <a class="btn" routerLink="../returns">Request a return</a> }
  </app-page-head>
  <div class="grid cols-3">
    <app-kpi label="Stock value" [value]="value" [foot]="units + ' units'" [iconPath]="ICONS['coins']" />
    <app-kpi label="Near expiry" [value]="count('NEAR_EXPIRY')" foot="batches to sell first" tone="warn" [iconPath]="ICONS['clock']" />
    <app-kpi label="Expired" [value]="count('EXPIRED')" foot="batches to return" tone="danger" [iconPath]="ICONS['alert']" />
  </div>
  <section class="card mt"><div class="card-body flush"><app-stock-table [columns]="columns" /></div></section>`
})
export class InventoryComponent implements OnInit {
  readonly ICONS = ICONS;
  rows: any[] = [];
  readonly columns: Column[] = [
    { key: 'productName', label: 'Product', type: 'strong', sub: r => r.sku },
    { key: 'batchNumber', label: 'Batch', type: 'mono' },
    { key: 'quantity', label: 'Quantity', type: 'num' },
    { key: 'daysToExpiry', label: 'Expiry', value: r => fmt.date(r.expiryDate), sub: r => (r.daysToExpiry < 0 ? `${-r.daysToExpiry} days ago` : `${r.daysToExpiry} days left`) },
    { key: 'expiryState', label: 'State', type: 'pill' },
    { key: 'stockType', label: 'Type', type: 'pill' },
    { key: 'stockValue', label: 'Value', type: 'money' }
  ];
  constructor(private api: ApiService, public auth: AuthService) {}
  async ngOnInit(): Promise<void> { this.rows = await this.api.get<any[]>('/stocks/current'); }
  get value(): string { return fmt.moneyShort(this.rows.reduce((a, r) => a + Number(r.stockValue || 0), 0)); }
  get units(): string { return fmt.num(this.rows.reduce((a, r) => a + Number(r.quantity || 0), 0)); }
  count(s: string): string { return fmt.num(this.rows.filter(r => r.expiryState === s).length); }
}
