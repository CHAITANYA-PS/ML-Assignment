/* Distributor › Deliveries: confirm with the handover code; receipts; and the differences found (each raises a ticket). */
import { Component } from '@angular/core';
import { RefService } from '../../core/ref.service';
import { ShipmentsListComponent } from '../../common/shipments-list/shipments-list.component';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, esc } from '../../shared/data-table/data-table.types';
import { PageHeadComponent } from '../../shared/page-head.component';
import { TabsComponent } from '../../shared/tabs.component';

@Component({
  selector: 'app-distributor-deliveries', standalone: true, imports: [PageHeadComponent, TabsComponent, ShipmentsListComponent, DataTableComponent],
  templateUrl: './deliveries.component.html'
})
export class DeliveriesComponent {
  readonly tabs = [{ key: 'shipments', label: 'Shipments' }, { key: 'receipts', label: 'Delivery receipts' }, { key: 'differences', label: 'Differences' }];
  tab = 'shipments';
  readonly receiptColumns: Column[] = [
    { key: 'shipmentId', label: 'Shipment', type: 'ref', ref: 'shipments' },
    { key: 'receivedAt', label: 'Received', type: 'dateTime' },
    { key: 'status', label: 'Differences', html: r => (r.status === 'CONFIRMED_WITH_DISCREPANCY' ? '<span class="pill danger">Shortage or damage</span>' : '<span class="pill ok">All received</span>') },
    { key: 'remarks', label: 'Remarks' }
  ];
  readonly diffColumns: Column[] = [
    { key: 'discrepancyType', label: 'Type', type: 'pill' },
    { key: 'quantity', label: 'Quantity', type: 'num' },
    { key: 'shipmentItemId', label: 'Shipment item', value: r => `#${r.shipmentItemId}` },
    { key: 'ticketId', label: 'Ticket', html: r => (r.ticketId ? `<a href="/distributor/tickets?open=${esc(r.ticketId)}">Ticket #${esc(r.ticketId)}</a>` : '–') }
  ];
  constructor(public ref: RefService) {}
}
