/* Distributor › Dashboard: orders, deliveries on the way, stock, tickets, this month's target and the health score. */
import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { inTransit } from '../../common/shipment-state';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { metric } from '../../core/dashboard-summary';
import { RefService } from '../../core/ref.service';
import { ConfirmDeliveryComponent } from '../../common/confirm-delivery/confirm-delivery.component';
import { NewOrderComponent } from '../../common/new-order/new-order.component';
import { OrderDrawerComponent } from '../../common/order-drawer/order-drawer.component';
import { lineChart } from '../../shared/charts';
import { ChartComponent } from '../../shared/chart.component';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { MeterComponent } from '../../shared/meter.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';

export const BAND_TONE: Record<string, string> = { 'Low risk': 'ok', 'Medium risk': 'warn', 'High risk': 'danger' };

@Component({
  selector: 'app-distributor-dashboard', standalone: true,
  imports: [RouterLink, PageHeadComponent, KpiCardComponent, ChartComponent, MeterComponent, StatusPillComponent, ConfirmDeliveryComponent, NewOrderComponent, OrderDrawerComponent, ...FORMAT_PIPES],
  templateUrl: './dashboard.component.html'
})
export class DistributorDashboardComponent implements OnInit {
  readonly ICONS = ICONS;
  readonly BAND_TONE = BAND_TONE;
  f = fmt;
  loaded = false;
  dist: any = {};
  stockValue = 0;
  orders: any[] = [];
  openOrders = 0;
  coming: any[] = [];
  stockCount = 0;
  near = 0;
  openTickets = 0;
  perf: any = null;
  last: any = null;
  chart = '';
  confirming: { s: any; items: any[] } | null = null;
  orderId: any = null;
  ordering = false;

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService, private router: Router) {}

  get band(): string { return this.last ? this.ref.name('risk-bands', this.last.riskBandId) : ''; }
  get firstName(): string { return (this.auth.me()?.userName ?? '').split(' ')[0]; }

  async ngOnInit(): Promise<void> { await this.load(); }
  async load(): Promise<void> {
    const did = this.auth.me()!.distributorId;
    await this.ref.ensure(['distributors', 'order-statuses', 'shipment-statuses', 'ticket-statuses', 'reporting-periods', 'risk-bands']);
    this.dist = this.ref.get('distributors', did) ?? {};
    const [sum, orders, ships, stock, tickets, perf, trend] = await Promise.all([
      this.api.get('/dashboard/summary'), this.api.all('/distributor-orders', { sort: 'orderDate,desc' }), this.api.all('/shipments'),
      this.api.get<any[]>('/stocks/current'), this.api.all('/tickets'),
      this.api.get(`/performance/${did}`).catch(() => null), this.api.get<any[]>(`/health-scores/${did}/trend`).catch(() => [])
    ]);
    this.stockValue = Number(metric(sum, 'Stock value') ?? 0);
    this.orders = orders.slice(0, 6);
    this.openOrders = orders.filter(o => !['Delivered', 'Cancelled'].includes(this.ref.name('order-statuses', o.orderStatusId))).length;
    this.coming = ships.filter(s => inTransit(s, this.ref.name('shipment-statuses', s.shipmentStatusId)));
    this.stockCount = stock.length;
    this.near = stock.filter(s => s.expiryState !== 'OK' && s.quantity > 0).length;
    this.openTickets = tickets.filter(t => !['Resolved', 'Closed'].includes(this.ref.name('ticket-statuses', t.ticketStatusId))).length;
    this.perf = perf;
    this.last = trend.length ? trend[trend.length - 1] : null;
    this.chart = trend.length ? lineChart({ labels: trend.map(h => this.ref.name('reporting-periods', h.reportingPeriodId)), series: [{ name: 'Score', values: trend.map(h => h.totalScore) }], maxValue: 100, height: 190, bands: [{ from: 0, to: 50, color: 'var(--danger-bg)' }] }) : '';
    this.loaded = true;
  }
  async confirm(s: any): Promise<void> { this.confirming = { s, items: await this.api.all('/shipment-items', { shipmentId: s.shipmentId }) }; }
  confirmed(): void { this.confirming = null; this.load(); }
  placed(): void { this.ordering = false; this.router.navigate(['/distributor/orders']); }
}
