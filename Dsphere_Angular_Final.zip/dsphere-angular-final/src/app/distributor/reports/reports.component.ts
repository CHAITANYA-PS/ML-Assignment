/* Distributor › Reports (shown only when the admin gives the Distributor role read access to "exports"). */
import { Component } from '@angular/core';
import { ReportsComponent } from '../../common/reports/reports.component';

@Component({
  selector: 'app-distributor-reports', standalone: true, imports: [ReportsComponent],
  template: `<app-reports [defaults]="defaults" />`
})
export class DistributorReportsComponent { readonly defaults = ['distributor-orders', 'tickets', 'commitments']; }
