/* Distributor › Commitments. */
import { Component } from '@angular/core';
import { CommitmentsComponent } from '../../common/commitments/commitments.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-distributor-commitments', standalone: true, imports: [PageHeadComponent, CommitmentsComponent],
  template: `
  <app-page-head eyebrow="Growth" title="Commitments" text="Targets you commit to, approved by your sales manager. Record progress as you go." />
  <section class="card"><div class="card-body flush"><app-commitments /></div></section>`
})
export class DistributorCommitmentsComponent {}
