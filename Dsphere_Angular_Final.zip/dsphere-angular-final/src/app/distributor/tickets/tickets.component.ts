/* Distributor › Support tickets. */
import { Component } from '@angular/core';
import { TicketsListComponent } from '../../common/tickets-list/tickets-list.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-distributor-tickets', standalone: true, imports: [PageHeadComponent, TicketsListComponent],
  template: `
  <app-page-head eyebrow="After sales" title="Support tickets" text="Raise a problem, add photos or documents as evidence and follow it until it is resolved. Each priority has its own SLA." />
  <section class="card"><div class="card-body flush"><app-tickets-list [allowCreate]="true" /></div></section>`
})
export class DistributorTicketsComponent {}
