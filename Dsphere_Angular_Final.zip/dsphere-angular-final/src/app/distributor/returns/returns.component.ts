/* Distributor › Returns and exchange. */
import { Component } from '@angular/core';
import { ReturnsComponent } from '../../common/returns/returns.component';

@Component({
  selector: 'app-distributor-returns', standalone: true, imports: [ReturnsComponent],
  template: `<app-returns text="Send back expired, damaged or near-expiry stock, or ask the manufacturer to exchange a product. Ship an approved return to take it out of your stock." />`
})
export class DistributorReturnsComponent {}
