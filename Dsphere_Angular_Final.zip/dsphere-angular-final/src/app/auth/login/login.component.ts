/* Sign-in page (replaces login/index.html + pages/login.js). */
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { environment } from '../../../environments/environment';
import { ApiService } from '../../core/api.service';
import { AuthService, ROLE_FOLDER } from '../../core/auth.service';
import { IconComponent } from '../../shared/icon.component';

@Component({
  selector: 'app-login', standalone: true, imports: [FormsModule, RouterLink, IconComponent],
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
  readonly env = environment;
  email = '';
  password = '';
  showPassword = false;
  error = '';
  notice = '';
  busy = false;

  constructor(private auth: AuthService, private api: ApiService, private router: Router, private route: ActivatedRoute) {}

  async ngOnInit(): Promise<void> {
    const q = this.route.snapshot.queryParamMap;
    if (q.get('signedOut')) this.notice = 'You are signed out.';
    if (q.get('reset')) this.notice = 'Password changed. Sign in with the new password.';
    if (q.get('noRole')) this.error = 'Your account has no stakeholder role yet. Ask the System Admin to give you one.';
    if (this.api.hasSession() && !q.get('signedOut')) {
      try { await this.auth.load(); if (this.auth.folder()) this.router.navigate(['/', this.auth.folder(), 'dashboard']); } catch { this.api.logout(); }
    }
  }

  async submit(): Promise<void> {
    this.error = ''; this.notice = '';
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(this.email.trim())) { this.error = 'Enter a valid email address.'; return; }
    if (!this.password) { this.error = 'Enter your password.'; return; }
    this.busy = true;
    try {
      await this.auth.login(this.email.trim(), this.password);
      const folder = ROLE_FOLDER[this.auth.role()];
      if (!folder) { this.error = 'Your account has no stakeholder role yet. Ask the System Admin to give you one.'; await this.auth.logout(); return; }
      this.router.navigate(['/', folder, 'dashboard']);
    } catch (e: any) {
      this.error = e?.message || 'Could not sign in';
    } finally {
      this.busy = false;
    }
  }
}
