/* Forgot password (replaces password-reset/index.html + pages/reset.js): request a token, then set a new password. */
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { environment } from '../../../environments/environment';
import { ApiService } from '../../core/api.service';

@Component({
  selector: 'app-password-reset', standalone: true, imports: [FormsModule, RouterLink],
  templateUrl: './password-reset.component.html'
})
export class PasswordResetComponent {
  readonly env = environment;
  email = '';
  token = '';
  pw = '';
  pw2 = '';
  step = 1;
  msg1 = ''; ok1 = false;
  msg2 = '';
  busy = false;

  constructor(private api: ApiService, private router: Router) {}

  async request(): Promise<void> {
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(this.email.trim())) { this.msg1 = 'Enter a valid email address.'; this.ok1 = false; return; }
    this.busy = true;
    try {
      const r = await this.api.post<any>('/auth/password-reset/request', { email: this.email.trim() });
      this.msg1 = r.message + (r.resetToken ? ` Demo only, your token: ${r.resetToken}` : '');
      this.ok1 = true;
      if (r.resetToken) this.token = r.resetToken;
      this.step = 2;
    } catch (e: any) { this.msg1 = e.message; this.ok1 = false; }
    finally { this.busy = false; }
  }

  async confirm(): Promise<void> {
    this.msg2 = '';
    if (!this.token.trim()) { this.msg2 = 'Enter the reset token.'; return; }
    if (this.pw.length < 8 || !/[A-Za-z]/.test(this.pw) || !/\d/.test(this.pw)) { this.msg2 = 'Use at least 8 characters with a letter and a digit.'; return; }
    if (this.pw !== this.pw2) { this.msg2 = 'The two passwords are different.'; return; }
    this.busy = true;
    try {
      await this.api.post('/auth/password-reset/confirm', { token: this.token.trim(), newPassword: this.pw });
      this.router.navigate(['/login'], { queryParams: { reset: 1 } });
    } catch (e: any) { this.msg2 = e.message; }
    finally { this.busy = false; }
  }
}
