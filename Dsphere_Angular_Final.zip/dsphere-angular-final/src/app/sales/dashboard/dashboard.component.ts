/* Sales › Dashboard: orders to approve, achievement against this month's targets, and who needs attention. */
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { metric } from '../../core/dashboard-summary';
import { RefService } from '../../core/ref.service';
import { OrderDrawerComponent } from '../../common/order-drawer/order-drawer.component';
import { hbars } from '../../shared/charts';
import { ChartComponent } from '../../shared/chart.component';
import { esc } from '../../shared/data-table/data-table.types';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';

export const LEVEL_TONE: Record<string, string> = { Critical: 'danger', High: 'danger', Medium: 'warn', Low: 'ok' };

/** Latest health score per distributor. */
export async function latestScores(api: ApiService): Promise<Record<string, any>> {
  const hist = await api.all('/health-score-histories', { sort: 'calculatedAt,asc' });
  const m: Record<string, any> = {};
  for (const h of hist) { const prev = m[h.distributorId]; m[h.distributorId] = { ...h, previousScore: prev ? prev.totalScore : null }; }
  return m;
}

@Component({
  selector: 'app-sales-dashboard', standalone: true, imports: [RouterLink, PageHeadComponent, KpiCardComponent, ChartComponent, StatusPillComponent, OrderDrawerComponent],
  templateUrl: './dashboard.component.html'
})
export class SalesDashboardComponent implements OnInit {
  readonly ICONS = ICONS;
  readonly LEVEL_TONE = LEVEL_TONE;
  f = fmt;
  loaded = false;
  averageHealth: number | null = null;
  orderCount = 0;
  orderValue = 0;
  ach = 0;
  tgt = 0;
  period = '';
  highRisk = 0;
  atRisk: any[] = [];
  toApprove: any[] = [];
  pending = 0;
  chart = '';
  orderId: any = null;

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService) {}

  get firstName(): string { return (this.auth.me()?.userName ?? '').split(' ')[0]; }
  get pctValue(): number { return this.tgt ? (this.ach / this.tgt) * 100 : 0; }

  async ngOnInit(): Promise<void> { await this.load(); }
  async load(): Promise<void> {
    await this.ref.ensure(['order-statuses', 'distributors', 'commitment-statuses', 'risk-bands']);
    const [sum, perf, scores, atRisk, orders, coms, items] = await Promise.all([
      this.api.get('/dashboard/summary'), this.api.get<any[]>('/performance'), latestScores(this.api),
      this.api.get<any[]>('/continuity/at-risk').catch(() => []), this.api.all('/distributor-orders'), this.api.all('/commitments'), this.api.all('/order-items')
    ]);
    this.averageHealth = metric(sum, 'Average health score');
    this.orderCount = orders.length;
    this.orderValue = items.reduce((a: number, i: any) => a + Number(i.quantity) * Number(i.unitPrice), 0);
    this.atRisk = atRisk.slice(0, 6);
    this.toApprove = orders.filter(o => this.ref.name('order-statuses', o.orderStatusId) === 'Placed');
    this.ach = perf.reduce((a, p) => a + Number(p.achieved), 0);
    this.tgt = perf.reduce((a, p) => a + Number(p.target), 0);
    this.period = perf[0]?.periodName ?? '';
    this.highRisk = Object.values(scores).filter((s: any) => this.ref.name('risk-bands', s.riskBandId) === 'High risk').length;
    this.pending = coms.filter(c => this.ref.name('commitment-statuses', c.commitmentStatusId) === 'Pending' || this.ref.name('commitment-statuses', c.commitmentStatusId) === 'Submitted').length;
    const sorted = [...perf].sort((a, b) => b.performancePercent - a.performancePercent);
    this.chart = hbars(sorted.map(p => ({
      label: p.distributorName, labelHtml: `${esc(p.distributorName)} ${p.status === 'RECOVERY' ? '<span class="pill danger">Below threshold</span>' : ''}`,
      value: p.performancePercent, tone: p.performancePercent >= 100 ? 'ok' : p.status === 'RECOVERY' ? 'danger' : 'warn'
    })), { format: (v: any) => fmt.pct(v), max: Math.max(100, ...sorted.map(p => p.performancePercent)) });
    this.loaded = true;
  }
}
