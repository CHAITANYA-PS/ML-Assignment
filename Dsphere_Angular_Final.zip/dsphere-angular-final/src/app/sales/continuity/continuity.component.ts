/* Sales › Business continuity: active distributors that may stop trading, with what to do next. */
import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { DistributorDrawerComponent } from '../../common/distributor-drawer/distributor-drawer.component';
import { Column } from '../../shared/data-table/data-table.types';
import { FormModalComponent } from '../../shared/form-modal/form-modal.component';
import { FieldSpec, FormState, fieldsFor } from '../../shared/form-modal/form-fields';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';
import { fmt } from '../../shared/format';
import { LEVEL_TONE } from '../dashboard/dashboard.component';

const nowLocal = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };

@Component({
  selector: 'app-sales-continuity', standalone: true,
  imports: [PageHeadComponent, KpiCardComponent, StatusPillComponent, CrudTableComponent, DistributorDrawerComponent, FormModalComponent, ...FORMAT_PIPES],
  templateUrl: './continuity.component.html'
})
export class ContinuityComponent implements OnInit {
  @ViewChild(CrudTableComponent) table?: CrudTableComponent;
  readonly ICONS = ICONS;
  readonly LEVEL_TONE = LEVEL_TONE;
  list: any[] = [];
  loaded = false;
  openId: any = null;
  form: FormState | null = null;
  readonly columns: Column[] = [
    { key: 'distributorId', label: 'Distributor', type: 'ref', ref: 'distributors' },
    { key: 'continuityStatusId', label: 'Status', type: 'ref', ref: 'continuity-status-types' },
    { key: 'riskLevelId', label: 'Risk', type: 'ref', ref: 'risk-levels' },
    { key: 'assessmentDate', label: 'Date', type: 'date' },
    { key: 'remarks', label: 'Remarks' }
  ];
  readonly fields: (string | FieldSpec)[] = ['distributorId', 'continuityStatusId', 'riskLevelId', 'assessmentDate', { name: 'remarks', full: true }];

  constructor(private api: ApiService, public auth: AuthService, private ref: RefService, private toast: ToastService) {}

  get defaults(): Record<string, any> { return this._defaults; }
  private _defaults = { assessmentDate: nowLocal() };
  beforeCreate = (v: any) => ({ ...v, assessedBy: this.auth.me()?.userId });

  async ngOnInit(): Promise<void> {
    this.list = await this.api.get<any[]>('/continuity/at-risk');
    this.loaded = true;
  }
  highAssessed(): string { return String(this.list.filter(c => ['High', 'Critical'].includes(c.latestRiskLevel)).length); }
  notAssessed(): string { return String(this.list.filter(c => !c.latestRiskLevel).length); }
  daysAgo(c: any): number { return c.lastOrder ? -(fmt.daysTo(c.lastOrder) ?? 0) : 0; }
  get canAssess(): boolean { return this.auth.can('POST', '/continuity-assessments'); }

  async assess(c: any): Promise<void> {
    await this.ref.ensure(['risk-levels', 'continuity-status-types']);
    const rl = this.ref.rows('risk-levels').find((x: any) => x.riskLevelName === c.latestRiskLevel);
    const cs = this.ref.rows('continuity-status-types').find((x: any) => x.statusName === 'At Risk');
    this.form = {
      title: 'Record continuity assessment', sub: c.distributorName,
      fields: fieldsFor('continuity-assessments', this.fields),
      value: { distributorId: c.distributorId, riskLevelId: rl?.riskLevelId, continuityStatusId: cs?.continuityStatusId, assessmentDate: nowLocal() },
      submit: v => this.api.post('/continuity-assessments', this.beforeCreate(v)).then(x => { this.toast.show('Assessment recorded', 'ok', 'POST /continuity-assessments'); this.table?.reload(false); return x; })
    };
  }
}
