/* Sales › Commitments: approve or reject submitted commitments and follow progress. */
import { Component } from '@angular/core';
import { CommitmentsComponent } from '../../common/commitments/commitments.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-sales-commitments', standalone: true, imports: [PageHeadComponent, CommitmentsComponent],
  template: `
  <app-page-head eyebrow="Performance" title="Commitments" text="Targets distributors commit to. Approve or reject submitted ones and follow progress until they are due." />
  <section class="card"><div class="card-body flush"><app-commitments /></div></section>`
})
export class SalesCommitmentsComponent {}
