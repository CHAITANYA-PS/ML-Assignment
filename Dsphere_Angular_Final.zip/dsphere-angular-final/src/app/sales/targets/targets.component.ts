/* Sales › Targets and sales: a target per distributor and period; achievement = recognised sales ÷ target. */
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { RefService } from '../../core/ref.service';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { barChart } from '../../shared/charts';
import { ChartComponent } from '../../shared/chart.component';
import { Column, Filter } from '../../shared/data-table/data-table.types';
import { fmt, todayIso } from '../../shared/format';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-sales-targets', standalone: true, imports: [FormsModule, PageHeadComponent, ChartComponent, CrudTableComponent],
  templateUrl: './targets.component.html'
})
export class TargetsComponent implements OnInit {
  periods: any[] = [];
  period: any = null;
  chart = '';
  empty = false;
  readonly columns: Column[] = [
    { key: 'distributorId', label: 'Distributor', type: 'ref', ref: 'distributors' },
    { key: 'reportingPeriodId', label: 'Period', type: 'ref', ref: 'reporting-periods' },
    { key: 'targetValue', label: 'Target', type: 'money' }
  ];
  readonly filters: Filter[] = [{ key: 'reportingPeriodId', label: 'Period', ref: 'reporting-periods' }, { key: 'distributorId', label: 'Distributor', ref: 'distributors' }];
  readonly fields = ['distributorId', 'reportingPeriodId', 'targetValue'];

  constructor(private api: ApiService, private ref: RefService) {}

  async ngOnInit(): Promise<void> {
    await this.ref.ensure(['reporting-periods', 'distributors']);
    this.periods = this.ref.rows('reporting-periods').filter((p: any) => p.periodType === 'Month');
    const today = todayIso();
    const cur = this.periods.find(p => p.startDate <= today && p.endDate >= today) ?? this.periods[this.periods.length - 1];
    this.period = cur?.reportingPeriodId ?? null;
    await this.draw();
  }
  async draw(): Promise<void> {
    if (this.period == null) { this.empty = true; return; }
    const perf = await this.api.get<any[]>('/performance', { reportingPeriodId: this.period });
    this.empty = !perf.length;
    this.chart = perf.length ? barChart({ labels: perf.map(p => String(p.distributorName).split(' ')[0]), series: [{ name: 'Target', values: perf.map(p => p.target), color: 'var(--brand-200)' }, { name: 'Achieved', values: perf.map(p => p.achieved) }], format: fmt.money, wide: true, height: 250 }) : '';
  }
}
