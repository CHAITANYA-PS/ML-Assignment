/* Sales › Reports. */
import { Component } from '@angular/core';
import { ReportsComponent } from '../../common/reports/reports.component';

@Component({
  selector: 'app-sales-reports', standalone: true, imports: [ReportsComponent],
  template: `<app-reports [defaults]="defaults" />`
})
export class SalesReportsComponent { readonly defaults = ['distributors', 'distributor-orders', 'sales-targets', 'health-score-histories', 'commitments']; }
