/* Pages of the sales stakeholder. Each page is lazy-loaded and guarded by the backend call it needs
 * (canGuard checks the role_permission rules, the same as the sidebar). */
import { Routes } from '@angular/router';
import { canGuard } from '../core/guards';

export const SALES_ROUTES: Routes = [
  { path: 'dashboard', title: 'Dashboard · Dsphere', canActivate: [canGuard('GET', '/dashboard/summary')], loadComponent: () => import('./dashboard/dashboard.component').then(m => m.SalesDashboardComponent) },
  { path: 'distributors', title: 'Distributors · Dsphere', canActivate: [canGuard('GET', '/distributors')], loadComponent: () => import('./distributors/distributors.component').then(m => m.SalesDistributorsComponent) },
  { path: 'orders', title: 'Orders · Dsphere', canActivate: [canGuard('GET', '/distributor-orders')], loadComponent: () => import('./orders/orders.component').then(m => m.SalesOrdersComponent) },
  { path: 'tickets', title: 'Support tickets · Dsphere', canActivate: [canGuard('GET', '/tickets')], loadComponent: () => import('./tickets/tickets.component').then(m => m.SalesTicketsComponent) },
  { path: 'targets', title: 'Targets and sales · Dsphere', canActivate: [canGuard('GET', '/sales-targets')], loadComponent: () => import('./targets/targets.component').then(m => m.TargetsComponent) },
  { path: 'health', title: 'Health scores · Dsphere', canActivate: [canGuard('GET', '/health-score-histories')], loadComponent: () => import('./health/health.component').then(m => m.HealthComponent) },
  { path: 'continuity', title: 'Continuity · Dsphere', canActivate: [canGuard('GET', '/continuity/at-risk')], loadComponent: () => import('./continuity/continuity.component').then(m => m.ContinuityComponent) },
  { path: 'commitments', title: 'Commitments · Dsphere', canActivate: [canGuard('GET', '/commitments')], loadComponent: () => import('./commitments/commitments.component').then(m => m.SalesCommitmentsComponent) },
  { path: 'reports', title: 'Reports · Dsphere', canActivate: [canGuard('GET', '/exports')], loadComponent: () => import('./reports/reports.component').then(m => m.SalesReportsComponent) },
  { path: 'notifications', title: 'Notifications · Dsphere', loadComponent: () => import('../common/notifications/notifications.component').then(m => m.NotificationsComponent) },
  { path: 'profile', title: 'My profile · Dsphere', loadComponent: () => import('../common/profile/profile.component').then(m => m.ProfileComponent) },
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
];
