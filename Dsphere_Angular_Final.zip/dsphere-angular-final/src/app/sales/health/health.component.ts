/* Sales › Health scores: weighted parameters per distributor; recalculate after new assessments. */
import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { DistributorDrawerComponent } from '../../common/distributor-drawer/distributor-drawer.component';
import { meter } from '../../shared/charts';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter, RowAction } from '../../shared/data-table/data-table.types';
import { fmt } from '../../shared/format';
import { FieldSpec } from '../../shared/form-modal/form-fields';
import { PageHeadComponent } from '../../shared/page-head.component';
import { TabsComponent } from '../../shared/tabs.component';
import { latestScores } from '../dashboard/dashboard.component';

const BAND: Record<string, string> = { 'Low risk': 'ok', 'Medium risk': 'warn', 'High risk': 'danger' };
const TREND: Record<string, string> = { UP: 'ok', DOWN: 'danger', STABLE: 'neutral', NEW: 'info' };

@Component({
  selector: 'app-sales-health', standalone: true, imports: [PageHeadComponent, TabsComponent, DataTableComponent, CrudTableComponent, DistributorDrawerComponent],
  templateUrl: './health.component.html'
})
export class HealthComponent implements OnInit {
  @ViewChild('scoresTable') scoresTable?: DataTableComponent;
  readonly tabs = [{ key: 'scores', label: 'Scores' }, { key: 'assess', label: 'Assessments' }, { key: 'alerts', label: 'Alerts' }, { key: 'weights', label: 'Weights' }];
  tab = 'scores';
  check: any = null;
  scores: Record<string, any> = {};
  openId: any = null;
  ready = false;

  readonly scoreColumns: Column[] = [
    { key: 'distributorName', label: 'Distributor', type: 'strong' },
    { key: 'score', label: 'Score', html: r => (r.score != null ? `<div style="min-width:120px">${meter(Number(r.score))}<div class="cell-sub">${fmt.dec(r.score)}</div></div>` : '<span class="muted">Not scored yet: press Recalculate</span>') },
    { key: 'band', label: 'Risk', type: 'pill', tone: r => BAND[r.band] },
    { key: 'trend', label: 'Trend', type: 'pill', tone: r => TREND[r.trend] },
    { key: 'calculatedAt', label: 'Calculated', type: 'ago' }
  ];
  scoreActions: RowAction[] = [];
  readonly assessColumns: Column[] = [
    { key: 'distributorId', label: 'Distributor', type: 'ref', ref: 'distributors' },
    { key: 'parameterWeightId', label: 'Parameter', value: r => { const w = this.ref.get('health-parameter-weights', r.parameterWeightId); return w ? this.ref.name('health-parameters', w.parameterId) : '–'; } },
    { key: 'reportingPeriodId', label: 'Period', type: 'ref', ref: 'reporting-periods' },
    { key: 'score', label: 'Score', type: 'num' },
    { key: 'remarks', label: 'Remarks' }
  ];
  readonly assessFilters: Filter[] = [{ key: 'distributorId', label: 'Distributor', ref: 'distributors' }, { key: 'reportingPeriodId', label: 'Period', ref: 'reporting-periods' }];
  assessFields: (string | FieldSpec)[] = [];
  readonly alertColumns: Column[] = [
    { key: 'message', label: 'Message' }, { key: 'thresholdValue', label: 'Alert level', type: 'num' },
    { key: 'readStatus', label: 'Read', type: 'bool' }, { key: 'createdAt', label: 'Raised', type: 'ago' }
  ];
  readonly weightColumns: Column[] = [
    { key: 'parameterId', label: 'Parameter', type: 'ref', ref: 'health-parameters' },
    { key: 'weight', label: 'Weight', type: 'strong', value: r => fmt.pct(Number(r.weight) * 100) },
    { key: 'validFrom', label: 'From', type: 'date' }, { key: 'validTo', label: 'To', type: 'date' }
  ];

  constructor(private api: ApiService, private auth: AuthService, private ref: RefService, private toast: ToastService) {}

  source = async () => this.ref.rows('distributors').map((d: any) => {
    const s = this.scores[d.distributorId];
    return { distributorId: d.distributorId, distributorName: d.distributorName, status: d.status, ...(s ? { score: s.totalScore, band: this.ref.name('risk-bands', s.riskBandId), trend: this.trendOf(s), calculatedAt: s.calculatedAt } : {}) };
  });
  trendOf(s: any): string {
    if (s.previousScore == null) return 'NEW';
    const diff = Number(s.totalScore) - Number(s.previousScore);
    return diff > 1 ? 'UP' : diff < -1 ? 'DOWN' : 'STABLE';
  }
  get checkMessage(): string {
    const c = this.check;
    if (!c) return '';
    return c.valid ? `Active weights total ${c.totalPercent}%` : `Active weights total ${c.totalPercent}%; they must total 100%`;
  }
  beforeCreate = (v: any) => ({ ...v, assessedBy: this.auth.me()?.userId });

  async ngOnInit(): Promise<void> {
    this.check = await this.api.get('/health-scores/weights/check').catch(() => null);
    await this.ref.ensure(['distributors', 'reporting-periods', 'health-parameters', 'health-parameter-weights', 'risk-bands']);
    this.scores = await latestScores(this.api);
    const weightOptions = this.ref.rows('health-parameter-weights').map((w: any) => [w.parameterWeightId, `${this.ref.name('health-parameters', w.parameterId)} (${fmt.pct(Number(w.weight) * 100)})`] as [any, string]);
    this.assessFields = ['distributorId', { name: 'parameterWeightId', label: 'Parameter', type: 'select', options: weightOptions, required: true }, 'reportingPeriodId', { name: 'score', hint: '0 to 100' }, { name: 'remarks', full: true }];
    this.scoreActions = [{ label: 'Recalculate', show: r => this.auth.can('POST', `/health-scores/calculate/${r.distributorId}`), run: r => this.recalc(r) }];
    this.ready = true;
  }
  async recalc(r: any): Promise<void> {
    try {
      const res = await this.api.post<any>(`/health-scores/calculate/${r.distributorId}`);
      this.toast.show(`${r.distributorName}: score recalculated`, 'ok', `New score ${fmt.dec(res.totalScore)} · ${res.riskCategory}`);
      this.scores = await latestScores(this.api);
      this.scoresTable?.reload(true);
    } catch (e) { this.toast.error(e); }
  }
}
