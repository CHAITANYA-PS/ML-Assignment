/* Sales › Support tickets: raise a ticket for a distributor and follow it (same list as the distributor's). */
import { Component } from '@angular/core';
import { TicketsListComponent } from '../../common/tickets-list/tickets-list.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-sales-tickets', standalone: true, imports: [PageHeadComponent, TicketsListComponent],
  template: `
  <app-page-head eyebrow="Network" title="Support tickets" text="Raise a problem for a distributor, add evidence and follow it until the recovery team resolves it." />
  <section class="card"><div class="card-body flush"><app-tickets-list [allowCreate]="true" /></div></section>`
})
export class SalesTicketsComponent {}
