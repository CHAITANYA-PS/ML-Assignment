/* Sales › Distributors: onboard distributors and open the 360° view. */
import { Component } from '@angular/core';
import { DistributorsListComponent } from '../../common/distributors-list/distributors-list.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-sales-distributors', standalone: true, imports: [PageHeadComponent, DistributorsListComponent],
  template: `
  <app-page-head eyebrow="Network" title="Distributors" text="Onboard distributors and open any of them for a 360° view: health, target achievement, credit risk and continuity." />
  <section class="card"><div class="card-body flush"><app-distributors-list /></div></section>`
})
export class SalesDistributorsComponent {}
