/* Sales › Orders: approve placed orders (credit limit checked) and move them to Processing, which creates the shipment. */
import { Component } from '@angular/core';
import { OrdersListComponent } from '../../common/orders-list/orders-list.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-sales-orders', standalone: true, imports: [PageHeadComponent, OrdersListComponent],
  template: `
  <app-page-head eyebrow="Network" title="Orders" text="Approve placed orders (the credit limit is checked) and move them to Processing, which creates the shipment for the warehouse. Orders only move forward." />
  <section class="card"><div class="card-body flush"><app-orders-list [allowCreate]="true" /></div></section>`
})
export class SalesOrdersComponent {}
