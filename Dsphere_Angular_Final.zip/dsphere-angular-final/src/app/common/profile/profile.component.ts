/* My profile, every stakeholder (replaces DS.page("profile") in common.js). */
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';

@Component({
  selector: 'app-profile', standalone: true, imports: [PageHeadComponent, StatusPillComponent, ...FORMAT_PIPES],
  templateUrl: './profile.component.html'
})
export class ProfileComponent implements OnInit {
  me: any = null;

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService) {}

  async ngOnInit(): Promise<void> {
    this.me = await this.api.get('/auth/me');
    await this.ref.ensure(this.me.distributorId ? ['distributors'] : this.me.manufacturerId ? ['manufacturers'] : []);
  }
}
