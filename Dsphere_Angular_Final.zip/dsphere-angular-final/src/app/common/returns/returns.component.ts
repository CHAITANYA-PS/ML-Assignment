/*
 * Returns and exchange (replaces returnsTable(), exchangeTable(), newReturn() and returnsPage()).
 * Used by the manufacturer, distributor and sales pages. The distributor requests; the manufacturer decides.
 */
import { environment } from '../../../environments/environment';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { ConfirmService } from '../../core/confirm.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter, RowAction, esc } from '../../shared/data-table/data-table.types';
import { fmt, nice } from '../../shared/format';
import { FormModalComponent } from '../../shared/form-modal/form-modal.component';
import { FormState, fieldsFor } from '../../shared/form-modal/form-fields';
import { ModalComponent } from '../../shared/modal.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { TabsComponent } from '../../shared/tabs.component';
import { FORMAT_PIPES } from '../../shared/pipes';
import { TimelineComponent, TimelineItem } from '../timeline/timeline.component';

@Component({
  selector: 'app-returns', standalone: true,
  imports: [PageHeadComponent, TabsComponent, DataTableComponent, FormModalComponent, ModalComponent, StatusPillComponent, TimelineComponent, ...FORMAT_PIPES],
  templateUrl: './returns.component.html'
})
export class ReturnsComponent implements OnInit {
  @Input() text = 'Distributors send stock back or ask for replacement stock. The manufacturer approves and chooses the warehouse.';
  @ViewChild('ret') retTable?: DataTableComponent;
  @ViewChild('exc') excTable?: DataTableComponent;

  readonly RET_FLOW = ['REQUESTED', 'APPROVED', 'IN_TRANSIT', 'RECEIVED'];
  /** The backend calls a shipped-back return IN_TRANSIT (the demo data says SHIPPED). */
  readonly live = environment.apiMode === 'live';
  shipped(r: any): boolean { return r.status === 'IN_TRANSIT' || r.status === 'SHIPPED'; }
  tab = 'returns';
  isDist = false;
  retColumns: Column[] = [];
  retFilters: Filter[] = [];
  retActions: RowAction[] = [];
  excColumns: Column[] = [];
  excFilters: Filter[] = [];
  excActions: RowAction[] = [];
  form: FormState | null = null;
  ret: any = null;
  exc: any = null;
  excHistory: TimelineItem[] = [];

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService, private toast: ToastService, private confirm: ConfirmService) {}

  async ngOnInit(): Promise<void> {
    this.isDist = !!this.auth.me()?.distributorId;
    await this.ref.ensure(['distributors', 'product-batches', 'products', 'return-categories', 'warehouses', 'exchange-statuses', 'app-users']);
    const dist: Column[] = this.isDist ? [] : [{ key: 'distributorId', label: 'Distributor', type: 'ref', ref: 'distributors' }];
    this.retColumns = [
      { key: 'returnNumber', label: 'Return', type: 'strong', sub: r => fmt.ago(r.createdAt) }, ...dist,
      { key: 'productBatchId', label: 'Product', html: r => { const b = this.batch(r); return `${esc(this.ref.name('products', b.productId))}<div class="cell-sub mono">${esc(b.batchNumber || '')}</div>`; } },
      { key: 'returnCategoryId', label: 'Reason', type: 'ref', ref: 'return-categories' },
      { key: 'quantity', label: 'Qty', type: 'num' },
      { key: 'status', label: 'Status', type: 'pill' },
      { key: 'targetWarehouseId', label: 'Back to', value: r => (r.targetWarehouseId ? this.ref.name('warehouses', r.targetWarehouseId) : '–') }
    ];
    this.retFilters = [{ key: 'status', label: 'Status', options: [['REQUESTED', 'Requested'], ['APPROVED', 'Approved'], [this.live ? 'IN_TRANSIT' : 'SHIPPED', 'On the way back'], ['RECEIVED', 'Received'], ['REJECTED', 'Rejected']] }, { key: 'returnCategoryId', label: 'Reason', ref: 'return-categories' }];
    const P = (id: any, s: string) => `/product-returns/${id}/${s}`;
    this.retActions = [
      { label: 'Approve', tone: 'primary', show: r => r.status === 'REQUESTED' && this.auth.can('POST', P(r.productReturnId, 'approve')), run: r => this.approveReturn(r) },
      { label: 'Reject', show: r => r.status === 'REQUESTED' && this.auth.can('POST', P(r.productReturnId, 'reject')), run: r => this.reject(P(r.productReturnId, 'reject'), 'Reject return?', 'Return rejected', () => this.retTable?.reload(true)) },
      { label: 'Ship back', tone: 'primary', show: r => r.status === 'APPROVED' && this.auth.can('POST', P(r.productReturnId, 'ship')), run: r => this.act(P(r.productReturnId, 'ship'), {}, 'Return shipped. The stock left your inventory', () => this.retTable?.reload(true)) },
      { label: 'Receive', tone: 'primary', show: r => this.shipped(r) && !this.isDist && this.auth.can('POST', P(r.productReturnId, 'receive')), run: r => this.act(P(r.productReturnId, 'receive'), {}, 'Return received (kept as not sellable)', () => this.retTable?.reload(true)) }
    ];

    this.excColumns = [
      { key: 'requestNumber', label: 'Request', type: 'strong', sub: r => fmt.ago(r.requestedAt) }, ...dist,
      { key: 'productId', label: 'Product', type: 'ref', ref: 'products' },
      { key: 'requestedQuantity', label: 'Qty', type: 'num' },
      { key: 'exchangeStatusId', label: 'Status', type: 'status', ref: 'exchange-statuses' },
      { key: 'decisionRemarks', label: 'Decision' }
    ];
    this.excFilters = [{ key: 'exchangeStatusId', label: 'Status', ref: 'exchange-statuses' }];
    const E = (id: any, s: string) => `/exchange-requests/${id}/${s}`;
    const st = (r: any) => this.ref.name('exchange-statuses', r.exchangeStatusId);
    this.excActions = [
      { label: 'Approve', tone: 'primary', show: r => st(r) === 'Requested' && this.auth.can('POST', E(r.exchangeId, 'approve')), run: r => this.approveExchange(r) },
      { label: 'Reject', show: r => st(r) === 'Requested' && this.auth.can('POST', E(r.exchangeId, 'reject')), run: r => this.reject(E(r.exchangeId, 'reject'), 'Reject exchange?', 'Exchange rejected', () => this.excTable?.reload(true)) },
      { label: 'Complete', tone: 'primary', show: r => st(r) === 'Approved' && this.auth.can('POST', E(r.exchangeId, 'complete')), run: r => this.act(E(r.exchangeId, 'complete'), {}, 'Exchange completed. The stock was transferred', () => this.excTable?.reload(true)) }
    ];
  }

  batch(r: any): any { return this.ref.get('product-batches', r.productBatchId) ?? {}; }
  get canRequestReturn(): boolean { return this.isDist && this.auth.can('POST', '/product-returns'); }
  get canRequestExchange(): boolean { return this.isDist && this.auth.can('POST', '/exchange-requests'); }
  retStep(r: any): number { return r.status === 'REJECTED' ? 0 : r.status === 'RECEIVED' ? 4 : this.shipped(r) ? 2 : this.RET_FLOW.indexOf(r.status); }
  done(r: any, i: number): boolean { return i < this.retStep(r); }
  mark(r: any, i: number): string { return i < this.retStep(r) ? '✓' : String(i + 1); }
  nice(v: any): string { return nice(v); }

  private async act(path: string, body: any, ok: string, after: () => void): Promise<void> {
    try { await this.api.post(path, body); this.toast.show(ok, 'ok', 'POST ' + path); after(); } catch (e) { this.toast.error(e); }
  }
  private async reject(path: string, title: string, ok: string, after: () => void): Promise<void> {
    const reason = await this.confirm.ask({ title, okLabel: 'Reject', tone: 'danger', input: { label: 'Reason', required: true, max: 500 } });
    if (reason) await this.act(path, { reason }, ok, after);
  }

  approveReturn(r: any): void {
    const path = `/product-returns/${r.productReturnId}/approve`;
    this.form = {
      title: 'Approve return', sub: 'Choose the warehouse the goods go back to.', size: 'narrow', submitLabel: 'Approve',
      fields: [{ name: 'targetWarehouseId', label: 'Return to warehouse', type: 'select', ref: 'warehouses', required: true, full: true }, { name: 'remarks', label: 'Remarks', type: 'textarea', max: 500, full: true }],
      submit: v => this.api.post(path, v).then(x => { this.toast.show('Return approved', 'ok', 'POST ' + path); this.retTable?.reload(true); return x; })
    };
  }
  async newReturn(): Promise<void> {
    const stock = await this.api.get<any[]>('/stocks/current');
    const me = this.auth.me()!;
    this.form = {
      title: 'Request a return', sub: 'Pick the stock to send back. The manufacturer approves it and chooses the warehouse.', submitLabel: 'Request return',
      fields: fieldsFor('product-returns', [
        { name: 'warehouseStockId', label: 'Stock (product · batch · available)', type: 'select', required: true, full: true,
          options: stock.filter(s => s.quantity > 0).map(s => [s.warehouseStockId, `${s.productName} · ${s.batchNumber} · ${s.quantity} available${s.expiryState !== 'OK' ? ' · ' + nice(s.expiryState) : ''}`] as [any, string]) },
        { name: 'returnCategoryId', label: 'Reason', required: true }, { name: 'quantity', required: true },
        { name: 'reason', label: 'Details', required: true, full: true, type: 'textarea' }
      ]),
      submit: v => this.api.post<any>('/product-returns', { ...v, distributorId: me.distributorId, requestedBy: me.userId }).then(x => { this.toast.show(`Return ${x.returnNumber} requested`, 'ok', 'POST /product-returns'); this.retTable?.reload(); return x; })
    };
  }

  async approveExchange(r: any): Promise<void> {
    const stock = (await this.api.get<any[]>('/stocks/current')).filter(s => s.productId === r.productId && s.quantity >= r.requestedQuantity && s.expiryState !== 'EXPIRED');
    const path = `/exchange-requests/${r.exchangeId}/approve`;
    this.form = {
      title: 'Approve exchange', sub: `${this.ref.name('products', r.productId)} · ${fmt.num(r.requestedQuantity)} needed`, submitLabel: 'Approve',
      fields: [
        { name: 'sourceWarehouseStockId', label: 'Take the stock from', type: 'select', required: true, full: true, hint: stock.length ? '' : 'No stock row has enough of this product.',
          options: stock.map(s => [s.warehouseStockId, `${s.warehouseName} · ${s.batchNumber} · ${s.quantity} available · expires ${fmt.date(s.expiryDate)}`] as [any, string]) },
        { name: 'destinationWarehouseId', label: 'Deliver to warehouse', type: 'select', ref: 'warehouses', required: true, full: true },
        { name: 'remarks', label: 'Remarks', type: 'textarea', max: 500, full: true }
      ],
      submit: v => this.api.post(path, v).then(x => { this.toast.show('Exchange approved', 'ok', 'POST ' + path); this.excTable?.reload(true); return x; })
    };
  }
  newExchange(): void {
    const me = this.auth.me()!;
    this.form = {
      title: 'Request an exchange', sub: 'Ask the manufacturer for replacement stock of a product.', submitLabel: 'Send request',
      fields: fieldsFor('exchange-requests', [{ name: 'productId', label: 'Product', required: true, full: true }, { name: 'requestedQuantity', label: 'Quantity', required: true }, { name: 'sourceLocation', label: 'Where you hold it' }]),
      submit: v => this.api.post<any>('/exchange-requests', { ...v, distributorId: me.distributorId, requestedBy: me.userId }).then(x => { this.toast.show(`Exchange ${x.requestNumber} requested`, 'ok', 'POST /exchange-requests'); this.excTable?.reload(); return x; })
    };
  }
  async openExchange(r: any): Promise<void> {
    const h = await this.api.get<any[]>(`/exchange-requests/${r.exchangeId}/history`).catch(() => []);
    this.excHistory = [...h].reverse().map(x => ({ title: this.ref.name('exchange-statuses', x.exchangeStatusId), text: x.remarks || '', when: x.changedAt, who: this.ref.name('app-users', x.changedBy) }));
    this.exc = r;
  }
}
