/* One ticket: details, SLA, actions, conversation, evidence files and history (replaces ticketDrawer() in common.js). */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { ConfirmService } from '../../core/confirm.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { fmt, saveFile } from '../../shared/format';
import { FormModalComponent } from '../../shared/form-modal/form-modal.component';
import { FieldSpec } from '../../shared/form-modal/form-fields';
import { ModalComponent } from '../../shared/modal.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';
import { TimelineComponent, TimelineItem } from '../timeline/timeline.component';

export const PRIORITY_TONE: Record<string, string> = { Critical: 'danger', High: 'warn', Medium: 'info', Low: 'neutral' };

@Component({
  selector: 'app-ticket-drawer', standalone: true,
  imports: [FormsModule, ModalComponent, FormModalComponent, StatusPillComponent, TimelineComponent, ...FORMAT_PIPES],
  templateUrl: './ticket-drawer.component.html'
})
export class TicketDrawerComponent implements OnInit {
  @Input() ticketId!: number | string;
  @Output() closed = new EventEmitter<void>();
  @Output() changed = new EventEmitter<void>();

  t: any = null;
  comments: any[] = [];
  files: any[] = [];
  history: TimelineItem[] = [];
  comment = '';
  busy = false;
  form: 'assign' | 'resolve' | null = null;
  assignFields: FieldSpec[] = [];
  readonly resolveFields: FieldSpec[] = [
    { name: 'findings', label: 'Findings', type: 'textarea', max: 2000, required: true, full: true, placeholder: 'What caused the problem?' },
    { name: 'correctiveAction', label: 'Corrective action', type: 'textarea', max: 2000, required: true, full: true, placeholder: 'What was done to fix it?' }
  ];
  readonly priorityTone = PRIORITY_TONE;

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService, private toast: ToastService, private confirm: ConfirmService) {}

  async ngOnInit(): Promise<void> { await this.load(); }

  private p(action: string): string { return `/tickets/${this.ticketId}/${action}`; }
  async load(): Promise<void> {
    await this.ref.ensure(['ticket-statuses', 'ticket-priorities', 'ticket-categories', 'distributors', 'app-users']);
    const [t, hist, comments, files] = await Promise.all([
      this.api.get(`/tickets/${this.ticketId}`),
      this.api.get<any>(this.p('history')).catch(() => null),
      this.api.all('/ticket-comments', { ticketId: this.ticketId }).catch(() => []),
      this.api.get<any[]>(this.p('attachments')).catch(() => [])
    ]);
    this.t = t; this.comments = comments; this.files = files || [];
    const user = (id: any) => (id == null ? null : this.ref.name('app-users', id));
    const ev: TimelineItem[] = [];
    (hist?.statusChanges ?? []).forEach((h: any) => ev.push({ title: `${this.ref.name('ticket-statuses', h.fromStatusId) || 'New'} → ${this.ref.name('ticket-statuses', h.toStatusId)}`, text: h.remarks, when: h.changedAt, who: user(h.changedBy) }));
    (hist?.assignments ?? []).forEach((h: any) => ev.push({ title: `Assigned to ${user(h.assignedTo)}`, text: h.remarks, when: h.assignedAt, who: user(h.assignedBy) }));
    (hist?.escalations ?? []).forEach((h: any) => ev.push({ title: `Escalated to level ${h.escalationLevel}`, text: h.reason, when: h.createdAt, who: user(h.escalatedTo) }));
    this.history = ev.sort((a, b) => String(b.when).localeCompare(String(a.when)));
  }

  get status(): string { return this.t ? this.ref.name('ticket-statuses', this.t.ticketStatusId) : ''; }
  get priority(): string { return this.t ? this.ref.name('ticket-priorities', this.t.ticketPriorityId) : ''; }
  get done(): boolean { return ['Resolved', 'Closed'].includes(this.status); }
  get breached(): boolean { return !!this.t?.slaDueAt && new Date(this.t.slaDueAt) < new Date() && !this.done; }
  slaText(): string { return this.t?.slaDueAt ? fmt.ago(this.t.slaDueAt) : ''; }
  user(id: any): string { return this.ref.name('app-users', id); }
  can(action: string): boolean { return this.auth.can('POST', this.p(action)); }

  async openAssign(): Promise<void> {
    const [urs, roles] = await Promise.all([this.api.all('/user-roles').catch(() => []), this.api.all('/roles').catch(() => [])]);
    const rid = roles.find((r: any) => r.roleCode === 'RECOVERY_MANAGER')?.roleId;
    let opts: [any, string][] = urs.filter((u: any) => u.roleId === rid).map((u: any) => [u.userId, this.user(u.userId)] as [any, string]);
    if (!opts.length) opts = [[this.auth.me()!.userId, this.auth.me()!.userName]];
    const mine = opts.some(o => o[0] === this.auth.me()?.userId) ? this.auth.me()!.userId : '';
    this.assignFields = [
      { name: 'assignedTo', label: 'Recovery Manager', type: 'select', options: opts, required: true, full: true, default: this.t.assignedTo ?? mine },
      { name: 'remarks', label: 'Remarks', type: 'textarea', max: 500, full: true }
    ];
    this.form = 'assign';
  }
  assign = (v: any) => this.api.post(this.p('assign'), { assignedTo: Number(v.assignedTo), remarks: v.remarks }).then(r => this.after('Ticket assigned', r));
  resolve = (v: any) => this.api.post(this.p('resolve'), v).then(r => this.after('Ticket resolved', r));

  async run(action: 'status' | 'close' | 'reopen' | 'escalate'): Promise<void> {
    let body: any;
    if (action === 'status') body = { status: 'In Progress', remarks: 'Work started' };
    if (action === 'close') body = { remarks: 'Closed after confirmation' };
    if (action === 'reopen' || action === 'escalate') {
      const reason = await this.confirm.ask({
        title: action === 'reopen' ? 'Reopen ticket?' : 'Escalate ticket?',
        text: action === 'escalate' ? `It goes to level ${(this.t.escalationLevel || 0) + 1}.` : undefined,
        okLabel: action === 'reopen' ? 'Reopen' : 'Escalate', tone: action === 'escalate' ? 'danger' : 'primary', input: { label: 'Reason', required: true }
      });
      if (!reason) return;
      body = { reason };
    }
    this.busy = true;
    try {
      await this.api.post(this.p(action), body);
      await this.after({ status: 'Work started', close: 'Ticket closed', reopen: 'Ticket reopened', escalate: 'Ticket escalated' }[action]);
    } catch (e) { this.toast.error(e); } finally { this.busy = false; }
  }
  async send(): Promise<void> {
    const text = this.comment.trim();
    if (!text) return;
    try {
      await this.api.post('/ticket-comments', { ticketId: Number(this.ticketId), userId: this.auth.me()?.userId, commentText: text });
      this.comment = '';
      await this.after('Comment added');
    } catch (e) { this.toast.error(e); }
  }
  async attach(ev: Event): Promise<void> {
    const input = ev.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    // Same rules as the backend (TicketWorkflowService): PDF, PNG, JPEG, GIF, WEBP or TXT, at most 5 MB.
    const okType = ['application/pdf', 'image/png', 'image/jpeg', 'image/gif', 'image/webp', 'text/plain'].includes((file.type || '').toLowerCase());
    if (!okType) { this.toast.show(`${file.name} cannot be attached. Use a PDF, PNG, JPEG, GIF, WEBP or TXT file.`, 'error'); input.value = ''; return; }
    if (file.size > 5 * 1024 * 1024) { this.toast.show(`${file.name} is ${(file.size / 1048576).toFixed(1)} MB. Files can be at most 5 MB; make the photo smaller and try again.`, 'error'); input.value = ''; return; }
    try { await this.api.upload(this.p('attachments'), file); await this.after('File attached'); }
    catch (e) { this.toast.error(e); } finally { input.value = ''; }
  }
  async download(a: any): Promise<void> {
    try { const f = await this.api.download(`${this.p('attachments')}/${a.attachmentId}/download`); saveFile(f.name || a.fileName, f.blob); }
    catch (e) { this.toast.error(e); }
  }
  private async after(msg: string, r?: any): Promise<any> {
    this.toast.show(msg);
    await this.load();
    this.changed.emit();
    return r;
  }
}
