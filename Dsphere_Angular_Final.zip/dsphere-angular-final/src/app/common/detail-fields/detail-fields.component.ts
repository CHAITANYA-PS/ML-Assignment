/* Every field of a record, with names for ids (the generic detail drawer of common.js). */
import { Component, Input, OnChanges } from '@angular/core';
import { RefService } from '../../core/ref.service';
import { SCHEMA } from '../../core/schema';
import { fmt, nice, toneOf } from '../../shared/format';

interface Pair { label: string; text: string; kind: 'text' | 'pill' | 'bool' | 'ref'; id?: any; }

@Component({
  selector: 'app-detail-fields', standalone: true,
  template: `
  <dl class="kv">
    @for (p of pairs; track p.label) {
      <dt>{{ p.label }}</dt>
      <dd>
        @switch (p.kind) {
          @case ('pill') { <span class="pill {{ tone(p.text) }}">{{ p.text }}</span> }
          @case ('bool') { <span class="pill {{ p.text === 'Yes' ? 'ok' : 'neutral' }}">{{ p.text }}</span> }
          @case ('ref') { {{ p.text }} <span class="muted small">#{{ p.id }}</span> }
          @default { @if (p.text === '–') { <span class="muted">–</span> } @else { {{ p.text }} } }
        }
      </dd>
    }
  </dl>`
})
export class DetailFieldsComponent implements OnChanges {
  @Input() resource = '';
  @Input() row: any = {};
  pairs: Pair[] = [];
  tone = toneOf;

  constructor(private ref: RefService) {}

  async ngOnChanges(): Promise<void> {
    const r = SCHEMA.resources[this.resource];
    if (!r || !this.row) { this.pairs = []; return; }
    await this.ref.ensure([...new Set(r.fields.filter(f => f.refPath).map(f => f.refPath!))]);
    this.pairs = r.fields.filter(f => !f.writeOnly).map(f => {
      const v = this.row[f.name];
      const label = f.label.replace(/ id$/i, '');
      if (v == null || v === '') return { label, text: '–', kind: 'text' as const };
      if (f.refPath) return { label, text: this.ref.name(f.refPath, v), kind: 'ref' as const, id: v };
      if (f.type === 'Boolean') return { label, text: v ? 'Yes' : 'No', kind: 'bool' as const };
      if (f.type === 'LocalDate') return { label, text: fmt.date(v), kind: 'text' as const };
      if (f.type === 'OffsetDateTime' || f.type === 'LocalDateTime') return { label, text: fmt.dateTime(v), kind: 'text' as const };
      if (f.options || /status$/i.test(f.name)) return { label, text: nice(v), kind: 'pill' as const };
      return { label, text: String(v), kind: 'text' as const };
    });
  }
}
