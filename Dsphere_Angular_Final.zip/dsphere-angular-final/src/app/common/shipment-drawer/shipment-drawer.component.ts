/*
 * One shipment (replaces shipmentDrawer() in common.js).
 * Manufacturer: verify each packed item by typing code, batch and quantity (no scanner), then dispatch -> handover code.
 * Distributor: confirm the delivery with the handover code.
 */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ShipStage, shipStage } from '../shipment-state';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { FormModalComponent } from '../../shared/form-modal/form-modal.component';
import { FieldSpec } from '../../shared/form-modal/form-fields';
import { ModalComponent } from '../../shared/modal.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';
import { ConfirmDeliveryComponent } from '../confirm-delivery/confirm-delivery.component';
import { TimelineComponent, TimelineItem } from '../timeline/timeline.component';

@Component({
  selector: 'app-shipment-drawer', standalone: true,
  imports: [ModalComponent, FormModalComponent, StatusPillComponent, TimelineComponent, ConfirmDeliveryComponent, ...FORMAT_PIPES],
  templateUrl: './shipment-drawer.component.html'
})
export class ShipmentDrawerComponent implements OnInit {
  @Input() shipmentId!: number | string;
  @Output() closed = new EventEmitter<void>();
  @Output() changed = new EventEmitter<void>();

  readonly flow = ['Created', 'Verified', 'In Transit', 'Delivered'];
  s: any = null;
  items: any[] = [];
  order: any = null;
  verifications: any[] = [];
  history: TimelineItem[] = [];
  verifying: any = null;
  handover: { code: string; note: string } | null = null;
  confirming = false;
  busy = false;
  readonly verifyFields: FieldSpec[] = [
    { name: 'productCode', label: 'Product code (13 digits)', required: true, full: true, mono: true, pattern: '\\d{13}', patternMessage: 'Product code must be 13 digits', placeholder: '8901234…' },
    { name: 'batchNumber', label: 'Batch number', required: true, full: true, max: 100, mono: true },
    { name: 'quantity', label: 'Quantity', type: 'decimal', positive: true, required: true, full: true }
  ];

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService, private toast: ToastService) {}

  async ngOnInit(): Promise<void> { await this.load(); }

  async load(): Promise<void> {
    await this.ref.ensure(['shipment-statuses', 'warehouses', 'products', 'product-batches', 'app-users', 'distributor-orders', 'distributors']);
    const id = this.shipmentId;
    const [s, items, hist, ver] = await Promise.all([
      this.api.get(`/shipments/${id}`),
      this.api.all('/shipment-items', { shipmentId: id }),
      this.api.get<any[]>(`/shipments/${id}/status-history`).catch(() => []),
      this.api.get<any[]>(`/shipments/${id}/verifications`).catch(() => [])
    ]);
    this.s = s; this.items = items; this.verifications = [...(ver || [])].reverse();
    this.history = [...(hist || [])].reverse().map(h => ({ title: this.ref.name('shipment-statuses', h.shipmentStatusId), text: h.remarks, when: h.changedAt, who: this.ref.name('app-users', h.changedBy) }));
    this.order = null;
    if (items.length) {
      const oi = await this.api.get(`/order-items/${items[0].orderItemId}`).catch(() => null);
      if (oi) this.order = this.ref.get('distributor-orders', oi.orderId);
    }
  }

  get status(): string { return this.s ? this.ref.name('shipment-statuses', this.s.shipmentStatusId) : ''; }
  get stage(): ShipStage { return shipStage(this.s, this.status); }
  get allVerified(): boolean { return this.items.length > 0 && this.items.every(i => i.verificationStatus === 'VERIFIED' || i.verificationStatus === 'MATCH'); }
  get step(): number { return this.stage === 'delivered' ? 4 : this.stage === 'in-transit' ? 2 : this.allVerified ? 1 : 0; }
  done(i: number): boolean { return i < this.step; }
  mark(i: number): string { return i < this.step ? '✓' : String(i + 1); }
  batch(it: any): any { return this.ref.get('product-batches', it.productBatchId) ?? {}; }
  product(it: any): string { return this.ref.name('products', this.batch(it).productId); }
  get isDistributor(): boolean { return !!this.auth.me()?.distributorId; }
  get canVerify(): boolean { return this.stage === 'created' && this.auth.can('POST', `/shipments/${this.shipmentId}/items/1/verify`); }
  get canDispatch(): boolean { return this.stage === 'created' && this.auth.can('POST', `/shipments/${this.shipmentId}/dispatch`); }
  get canHold(): boolean { return this.stage === 'in-transit' && this.status !== 'On Hold' && !this.isDistributor && this.auth.can('POST', `/shipments/${this.shipmentId}/status`); }
  get canConfirm(): boolean { return this.stage === 'in-transit' && this.isDistributor && this.auth.can('POST', `/delivery-receipts/${this.shipmentId}/confirm`); }

  verify = (v: any) => this.api.post<any>(`/shipments/${this.shipmentId}/items/${this.verifying.shipmentItemId}/verify`, v).then(async r => {
    if (r.result === 'MATCH') this.toast.show('Item verified', 'ok', 'MATCH'); else this.toast.show((r.messages ?? []).join('; ') || 'Item does not match', 'error', 'MISMATCH');
    await this.load();
    this.changed.emit();
    return r;
  });

  async dispatch(): Promise<void> {
    this.busy = true;
    try {
      const r = await this.api.post<any>(`/shipments/${this.shipmentId}/dispatch`, { remarks: 'Dispatched from warehouse' });
      this.handover = { code: r.handoverCode, note: r.note };
      await this.load();
      this.changed.emit();
    } catch (e) { this.toast.error(e); } finally { this.busy = false; }
  }
  async hold(): Promise<void> {
    this.busy = true;
    try {
      await this.api.post(`/shipments/${this.shipmentId}/status`, { status: 'On Hold', remarks: 'Held' });
      this.toast.show('Shipment on hold');
      await this.load();
      this.changed.emit();
    } catch (e) { this.toast.error(e); } finally { this.busy = false; }
  }
  async delivered(): Promise<void> { this.confirming = false; await this.load(); this.changed.emit(); }
}
