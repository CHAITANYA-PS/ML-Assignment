/*
 * List + create + edit + delete + detail drawer for one backend resource (replaces crudTable() in common.js).
 * Buttons appear only when the role may call POST / PUT / DELETE on the resource.
 *
 *   <app-crud-table resource="regions" [columns]="columns" searchField="regionName" />
 */
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild } from '@angular/core';
import { ApiService, Query } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { ConfirmService } from '../../core/confirm.service';
import { RefService } from '../../core/ref.service';
import { SCHEMA } from '../../core/schema';
import { ToastService } from '../../core/toast.service';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter, RowAction } from '../../shared/data-table/data-table.types';
import { FormModalComponent } from '../../shared/form-modal/form-modal.component';
import { FieldSpec, fieldsFor } from '../../shared/form-modal/form-fields';
import { ModalComponent } from '../../shared/modal.component';
import { DetailFieldsComponent } from '../detail-fields/detail-fields.component';

@Component({
  selector: 'app-crud-table', standalone: true,
  imports: [DataTableComponent, FormModalComponent, ModalComponent, DetailFieldsComponent],
  templateUrl: './crud-table.component.html'
})
export class CrudTableComponent implements OnInit, OnChanges {
  @Input() resource = '';
  @Input() path?: string;
  @Input() entity?: string;
  @Input() columns: Column[] = [];
  @Input() filters: Filter[] = [];
  @Input() fields?: (string | FieldSpec)[];
  @Input() editFields?: (string | FieldSpec)[];
  @Input() query: Query = {};
  @Input() searchField?: string;
  @Input() searchPlaceholder?: string;
  @Input() sort?: string;
  @Input() pageSize?: number;
  @Input() createLabel?: string;
  @Input() defaults: Record<string, any> = {};
  @Input() createIntro?: string;
  @Input() editIntro?: string;
  @Input() allowCreate = true;
  @Input() allowEdit = true;
  @Input() allowDelete = true;
  @Input() actions: RowAction[] = [];
  @Input() beforeCreate?: (v: any) => any;
  @Input() describe?: (row: any) => string;
  /** Replaces the default detail drawer on row click. */
  @Input() open?: (row: any) => void;
  @Output() changed = new EventEmitter<any>();
  @ViewChild(DataTableComponent) table?: DataTableComponent;

  editing: any = null;
  detail: any = null;
  createSpecs: FieldSpec[] = [];
  editSpecs: FieldSpec[] = [];
  rowActions: RowAction[] = [];

  constructor(private api: ApiService, public auth: AuthService, private confirm: ConfirmService, private toast: ToastService, private ref: RefService) {}

  get base(): string { return this.path || '/' + this.resource; }
  get idField(): string { return SCHEMA.resources[this.resource]?.idField ?? 'id'; }
  get name(): string { return this.entity || (SCHEMA.resources[this.resource]?.entity ?? this.resource).replace(/([a-z])([A-Z])/g, '$1 $2'); }
  get readOnly(): boolean { return !!SCHEMA.resources[this.resource]?.readOnlyResource; }
  get canCreate(): boolean { return this.allowCreate && !this.readOnly && this.auth.can('POST', this.base); }
  get canEdit(): boolean { return this.allowEdit && !this.readOnly && this.auth.can('PUT', this.base + '/1'); }
  get canDelete(): boolean { return this.allowDelete && !this.readOnly && this.auth.can('DELETE', this.base + '/1'); }

  ngOnInit(): void { this.build(); }
  /** Inputs can change (e.g. the stakeholder page refreshes the list of users without a role). */
  ngOnChanges(): void { this.build(); }

  private build(): void {
    const r = SCHEMA.resources[this.resource];
    const defaults = (r?.fields ?? []).filter(f => !f.readOnly && !['createdAt', 'updatedAt', 'version'].includes(f.name)).map(f => f.name);
    this.createSpecs = fieldsFor(this.resource, this.fields ?? defaults);
    this.editSpecs = fieldsFor(this.resource, this.editFields ?? this.fields ?? defaults);
    this.rowActions = [
      ...this.actions,
      ...(this.canEdit ? [{ label: 'Edit', run: (row: any) => this.startEdit(row) }] : []),
      ...(this.canDelete ? [{ label: 'Delete', tone: 'ghost' as const, run: (row: any) => this.remove(row) }] : [])
    ];
  }

  reload(keepPage = true): void { this.ref.invalidate(this.resource); this.table?.reload(keepPage); }
  startCreate(): void { this.editing = { ...this.defaults }; }
  startEdit(row: any): void { this.detail = null; this.editing = row; }
  rowClick(row: any): void { if (this.open) this.open(row); else this.detail = row; }
  get isEdit(): boolean { return !!this.editing && this.editing[this.idField] != null; }

  save = (v: any): Promise<any> => {
    const id = this.editing?.[this.idField];
    const call = id != null ? this.api.put(`${this.base}/${id}`, v) : this.api.post(this.base, this.beforeCreate ? this.beforeCreate(v) : v);
    return call.then(r => {
      this.toast.show(id != null ? `${this.name} saved` : `${this.name} created`, 'ok', `${id != null ? 'PUT' : 'POST'} ${this.base}${id != null ? '/' + id : ''}`);
      this.reload(id != null);
      this.changed.emit(r);
      return r;
    });
  };

  async remove(row: any): Promise<void> {
    const id = row[this.idField];
    const ok = await this.confirm.ask({ title: `Delete ${this.name.toLowerCase()}?`, text: `${this.describe ? this.describe(row) : `${this.name} #${id}`} will be deleted. The backend refuses if other records still use it.`, okLabel: 'Delete', tone: 'danger' });
    if (!ok) return;
    try {
      await this.api.del(`${this.base}/${id}`);
      this.toast.show(`${this.name} deleted`);
      this.reload(true);
      this.changed.emit(null);
    } catch (e) { this.toast.error(e); }
  }
}
