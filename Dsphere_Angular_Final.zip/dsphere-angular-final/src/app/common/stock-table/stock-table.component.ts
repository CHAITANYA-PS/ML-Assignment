/* Stock list used by the manufacturer, distributor and finance pages (replaces stockTable()). Data: GET /stocks/current. */
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { ApiService, Query } from '../../core/api.service';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter, RowAction, esc } from '../../shared/data-table/data-table.types';
import { fmt } from '../../shared/format';

@Component({
  selector: 'app-stock-table', standalone: true, imports: [DataTableComponent],
  template: `
  <app-data-table [source]="source" [columns]="cols" [filters]="filters" [actions]="actions" sort="productName,asc"
                  [initialFilters]="initial" searchPlaceholder="Search product, SKU or batch" emptyTitle="No stock">
    <span tools style="display:contents"><ng-content select="[tools]" /></span>
  </app-data-table>`
})
export class StockTableComponent implements OnInit {
  @Input() expiryState?: string;
  @Input() columns?: Column[];
  @Input() actions: RowAction[] = [];
  @ViewChild(DataTableComponent) table?: DataTableComponent;

  cols: Column[] = [];
  initial: Record<string, any> = {};
  readonly filters: Filter[] = [
    { key: 'warehouseId', label: 'Warehouse', ref: 'warehouses' },
    { key: 'expiryState', label: 'Expiry', options: [['OK', 'OK'], ['NEAR_EXPIRY', 'Near expiry'], ['EXPIRED', 'Expired']] },
    { key: 'belowReorderLevel', label: 'Reorder', options: [['true', 'Below reorder level'], ['false', 'Above reorder level']] }
  ];

  constructor(private api: ApiService) {}

  source = (q: Query) => this.api.get<any[]>('/stocks/current', q);

  ngOnInit(): void {
    if (this.expiryState) this.initial = { expiryState: this.expiryState };
    this.cols = this.columns ?? [
      { key: 'productName', label: 'Product', type: 'strong', sub: r => r.sku },
      { key: 'batchNumber', label: 'Batch', type: 'mono' },
      { key: 'warehouseName', label: 'Warehouse' },
      { key: 'quantity', label: 'Quantity', html: r => `${fmt.num(r.quantity)}${r.belowReorderLevel ? ` <span class="pill warn" title="Reorder level ${esc(r.reorderLevel)}">Low</span>` : ''}` },
      { key: 'daysToExpiry', label: 'Expiry', value: r => fmt.date(r.expiryDate), sub: r => (r.daysToExpiry < 0 ? `${-r.daysToExpiry} days ago` : `${r.daysToExpiry} days left`) },
      { key: 'expiryState', label: 'State', type: 'pill' },
      { key: 'stockValue', label: 'Value', type: 'money' }
    ];
  }
  reload(): void { this.table?.reload(true); }
}
