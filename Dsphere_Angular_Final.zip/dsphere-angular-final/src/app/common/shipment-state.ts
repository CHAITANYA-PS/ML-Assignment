/*
 * Where a shipment is in its flow, worked out from its dates as the backend does
 * (the backend names the dispatched status "Dispatched"; the demo data calls it "In Transit").
 */
export type ShipStage = 'created' | 'in-transit' | 'delivered';

export function shipStage(s: any, statusName: string): ShipStage {
  if (!s) return 'created';
  if (s.deliveryDate || statusName === 'Delivered') return 'delivered';
  if (s.dispatchDate || statusName === 'In Transit' || statusName === 'Dispatched') return 'in-transit';
  return 'created';
}
export function inTransit(s: any, statusName: string): boolean { return shipStage(s, statusName) === 'in-transit'; }
