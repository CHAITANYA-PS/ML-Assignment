/* A vertical history list: <app-timeline [items]="[{ title, text, when, who }]" />. */
import { Component, Input } from '@angular/core';
import { FORMAT_PIPES } from '../../shared/pipes';

export interface TimelineItem { title: string; text?: string | null; when?: string | null; who?: string | null; }

@Component({
  selector: 'app-timeline', standalone: true, imports: [...FORMAT_PIPES],
  template: `
  @if (items.length) {
    <div class="timeline">
      @for (i of items; track $index) {
        <div class="tl-item"><b>{{ i.title }}</b>@if (i.text) { <div>{{ i.text }}</div> }
          <small>{{ i.when ? (i.when | dateTimeIn) : '' }}{{ i.who ? ' · ' + i.who : '' }}</small></div>
      }
    </div>
  } @else { <div class="empty"><b>No history yet</b></div> }`
})
export class TimelineComponent { @Input() items: TimelineItem[] = []; }
