/*
 * Reports and exports (replaces reportsPage()). Lists every exportable table the role may read.
 * Route data { reports: ['invoices', 'payments'] } puts those first.
 */
import { Component, Input, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { ToastService } from '../../core/toast.service';
import { fmt, saveFile } from '../../shared/format';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-reports', standalone: true, imports: [FormsModule, PageHeadComponent],
  templateUrl: './reports.component.html'
})
export class ReportsComponent implements OnInit {
  @Input() defaults: string[] = [];
  names: string[] = [];
  format: Record<string, string> = {};
  busy: Record<string, boolean> = {};
  loaded = false;

  constructor(private api: ApiService, private auth: AuthService, private toast: ToastService, private route: ActivatedRoute) {}

  async ngOnInit(): Promise<void> {
    const defaults: string[] = this.defaults.length ? this.defaults : (this.route.snapshot.data['reports'] ?? []);
    try {
      const all = await this.api.get<string[]>('/exports');
      const allowed = all.filter(n => this.auth.can('GET', '/' + n));
      this.names = [...defaults.filter(n => allowed.includes(n)), ...allowed.filter(n => !defaults.includes(n))];
      for (const n of this.names) this.format[n] = 'xlsx';
    } catch (e) { this.toast.error(e); }
    this.loaded = true;
  }
  label(n: string): string { return fmt.label(n.replace(/-/g, ' ')); }

  async download(n: string): Promise<void> {
    this.busy[n] = true;
    try {
      const f = await this.api.download(`/exports/${n}`, { format: this.format[n] });
      saveFile(f.name, f.blob);
      this.toast.show(`${n} downloaded`, 'ok', `GET /exports/${n}?format=${this.format[n]}`);
    } catch (e) { this.toast.error(e); } finally { this.busy[n] = false; }
  }
}
