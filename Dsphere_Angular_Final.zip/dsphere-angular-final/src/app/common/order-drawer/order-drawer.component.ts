/* One order: steps, items, history, invoice and the actions the role may take (replaces orderDrawer() in common.js). */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { ConfirmService } from '../../core/confirm.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { ModalComponent } from '../../shared/modal.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';
import { TimelineComponent, TimelineItem } from '../timeline/timeline.component';

export const ORDER_FLOW = ['Placed', 'Approved', 'Processing', 'Dispatched', 'Delivered'];

@Component({
  selector: 'app-order-drawer', standalone: true, imports: [ModalComponent, StatusPillComponent, TimelineComponent, ...FORMAT_PIPES],
  templateUrl: './order-drawer.component.html'
})
export class OrderDrawerComponent implements OnInit {
  @Input() orderId!: number | string;
  @Output() closed = new EventEmitter<void>();
  @Output() changed = new EventEmitter<void>();

  readonly flow = ORDER_FLOW;
  order: any = null;
  items: any[] = [];
  invoice: any = null;
  history: TimelineItem[] = [];
  busy = false;

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService, private toast: ToastService, private confirm: ConfirmService) {}

  async ngOnInit(): Promise<void> { await this.load(); }

  async load(): Promise<void> {
    await this.ref.ensure(['order-statuses', 'products', 'distributors', 'app-users']);
    const id = this.orderId;
    const [o, items, hist, inv] = await Promise.all([
      this.api.get(`/distributor-orders/${id}`),
      this.api.all('/order-items', { orderId: id }),
      this.api.get<any[]>(`/distributor-orders/${id}/history`).catch(() => []),
      this.api.all('/invoices', { orderId: id }).catch(() => [])
    ]);
    this.order = o;
    this.items = items;
    this.invoice = inv[0] ?? null;
    this.history = [...hist].reverse().map(h => ({ title: this.ref.name('order-statuses', h.orderStatusId), text: h.remarks, when: h.changedAt, who: this.ref.name('app-users', h.changedBy) }));
  }

  get status(): string { return this.order ? this.ref.name('order-statuses', this.order.orderStatusId) : ''; }
  get step(): number { const i = this.flow.indexOf(this.status); return i === this.flow.length - 1 ? this.flow.length : i; }
  done(i: number): boolean { return i < this.step; }
  mark(i: number): string { return i < this.step ? '✓' : String(i + 1); }
  get total(): number { return this.items.reduce((a, i) => a + Number(i.quantity) * Number(i.unitPrice), 0); }
  get next(): string | null { return ({ Placed: 'Approved', Approved: 'Processing' } as Record<string, string>)[this.status] ?? null; }
  get canMove(): boolean { return !!this.next && this.auth.can('POST', `/distributor-orders/${this.orderId}/status`); }
  get canCancel(): boolean { return !['Dispatched', 'Delivered', 'Cancelled'].includes(this.status) && this.auth.can('POST', `/distributor-orders/${this.orderId}/cancel`); }

  async move(): Promise<void> {
    const next = this.next;
    if (!next) return;
    this.busy = true;
    try {
      await this.api.post(`/distributor-orders/${this.orderId}/status`, { status: next, remarks: `Moved to ${next}` });
      this.toast.show(`Order moved to ${next}`, 'ok', `POST /distributor-orders/${this.orderId}/status`);
      await this.load();
      this.changed.emit();
    } catch (e) { this.toast.error(e); } finally { this.busy = false; }
  }
  async cancel(): Promise<void> {
    const reason = await this.confirm.ask({ title: 'Cancel this order?', text: 'An order can be cancelled until it is shipped.', okLabel: 'Cancel order', tone: 'danger', input: { label: 'Reason', required: true } });
    if (!reason) return;
    this.busy = true;
    try {
      await this.api.post(`/distributor-orders/${this.orderId}/cancel`, { reason });
      this.toast.show('Order cancelled');
      await this.load();
      this.changed.emit();
    } catch (e) { this.toast.error(e); } finally { this.busy = false; }
  }
}
