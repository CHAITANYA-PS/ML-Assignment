/* Notifications page, every stakeholder (replaces DS.page("notifications") in common.js). */
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { PageHeadComponent } from '../../shared/page-head.component';
import { FORMAT_PIPES } from '../../shared/pipes';

@Component({
  selector: 'app-notifications', standalone: true, imports: [PageHeadComponent, ...FORMAT_PIPES],
  templateUrl: './notifications.component.html'
})
export class NotificationsComponent implements OnInit {
  list: any[] = [];
  loading = true;

  constructor(private api: ApiService, public ref: RefService, private toast: ToastService) {}

  async ngOnInit(): Promise<void> {
    await this.ref.ensure(['notification-types']);
    await this.load();
  }
  async load(): Promise<void> {
    try { this.list = await this.api.get<any[]>('/notifications/mine'); }
    catch (e) { this.toast.error(e); }
    finally { this.loading = false; }
  }
  async read(n: any): Promise<void> {
    try { await this.api.post(`/notifications/${n.notificationId}/read`); this.toast.show('Marked as read'); await this.load(); }
    catch (e) { this.toast.error(e); }
    window.dispatchEvent(new Event('dsphere-notifications'));
  }
  async readAll(): Promise<void> {
    const unread = this.list.filter(n => !n.readStatus);
    if (!unread.length) { this.toast.show('Nothing to mark: all notifications are already read'); return; }
    const results = await Promise.allSettled(unread.map(n => this.api.post(`/notifications/${n.notificationId}/read`)));
    const failed = results.filter(r => r.status === 'rejected') as PromiseRejectedResult[];
    await this.load();
    window.dispatchEvent(new Event('dsphere-notifications'));
    if (failed.length) this.toast.error(failed[0].reason);
    else this.toast.show('All marked as read');
  }
}
