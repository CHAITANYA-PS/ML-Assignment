/* Distributor commitments: the distributor submits, the sales manager approves, progress is recorded (replaces commitmentsTable() and commitmentDrawer()). */
import { Component, OnInit, ViewChild } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { ConfirmService } from '../../core/confirm.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { meter } from '../../shared/charts';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter } from '../../shared/data-table/data-table.types';
import { fmt, nice, todayIso } from '../../shared/format';
import { FormModalComponent } from '../../shared/form-modal/form-modal.component';
import { FormState, fieldsFor } from '../../shared/form-modal/form-fields';
import { ModalComponent } from '../../shared/modal.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';
import { TimelineComponent, TimelineItem } from '../timeline/timeline.component';

@Component({
  selector: 'app-commitments', standalone: true,
  imports: [DataTableComponent, FormModalComponent, ModalComponent, StatusPillComponent, TimelineComponent, ...FORMAT_PIPES],
  templateUrl: './commitments.component.html'
})
export class CommitmentsComponent implements OnInit {
  @ViewChild(DataTableComponent) table?: DataTableComponent;
  isDist = false;
  columns: Column[] = [];
  filters: Filter[] = [];
  form: FormState | null = null;
  c: any = null;
  completion: any = null;
  progress: any[] = [];
  history: TimelineItem[] = [];
  meterHtml: SafeHtml = '';
  busy = false;

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService, private toast: ToastService, private confirm: ConfirmService, private sanitizer: DomSanitizer) {}

  async ngOnInit(): Promise<void> {
    this.isDist = !!this.auth.me()?.distributorId;
    this.ref.invalidate('commitment-progresses');
    await this.ref.ensure(['distributors', 'measurement-units', 'commitment-statuses', 'commitment-progresses', 'app-users']);
    this.columns = [
      { key: 'targetName', label: 'Commitment', type: 'strong', sub: r => `Due ${fmt.date(r.dueDate)}` },
      ...(this.isDist ? [] : [{ key: 'distributorId', label: 'Distributor', type: 'ref' as const, ref: 'distributors' }]),
      { key: 'targetValue', label: 'Target', value: r => `${fmt.dec(r.targetValue)} ${this.ref.name('measurement-units', r.measurementUnitId)}` },
      { key: 'progress', label: 'Progress', html: r => { const p = this.pct(r); return `<div style="min-width:120px">${meter(p)}<div class="cell-sub">${fmt.pct(p)}</div></div>`; } },
      { key: 'commitmentStatusId', label: 'Status', type: 'status', ref: 'commitment-statuses' }
    ];
    this.filters = [{ key: 'commitmentStatusId', label: 'Status', ref: 'commitment-statuses' }, ...(this.isDist ? [] : [{ key: 'distributorId', label: 'Distributor', ref: 'distributors' }])];
  }
  private pct(r: any): number {
    const p = this.ref.rows('commitment-progresses').filter((x: any) => x.commitmentId === r.commitmentId);
    const best = p.length ? Math.max(...p.map((x: any) => Number(x.progressValue))) : 0;
    return r.targetValue ? Math.min(100, (best / Number(r.targetValue)) * 100) : 0;
  }
  get canCreate(): boolean { return this.isDist && this.auth.can('POST', '/commitments'); }
  get status(): string { return this.c ? this.ref.name('commitment-statuses', this.c.commitmentStatusId) : ''; }
  get unit(): string { return this.c ? this.ref.name('measurement-units', this.c.measurementUnitId) : ''; }
  get canDecide(): boolean { return ['Pending', 'Submitted'].includes(this.status) && this.auth.can('POST', `/commitments/${this.c.commitmentId}/approve`); }
  get canProgress(): boolean { return this.status === 'Approved' && this.auth.can('POST', '/commitment-progresses'); }

  async open(c: any): Promise<void> {
    const id = c.commitmentId;
    const [done, hist, prog] = await Promise.all([
      this.api.get<any>(`/commitments/${id}/completion`).catch(() => null),
      this.api.get<any[]>(`/commitments/${id}/history`).catch(() => []),
      this.api.all('/commitment-progresses', { commitmentId: id }).catch(() => [])
    ]);
    this.completion = done; this.progress = prog;
    this.meterHtml = done ? this.sanitizer.bypassSecurityTrustHtml(meter(done.completionPercent)) : '';
    this.history = [...(hist || [])].reverse().map(h => ({ title: nice(h.action), text: h.remarks || '', when: h.actionAt, who: this.ref.name('app-users', h.actionBy) }));
    this.c = c;
  }
  private after(): void { this.c = null; this.ref.invalidate('commitment-progresses'); this.ref.ensure(['commitment-progresses']).then(() => this.table?.reload(true)); }

  async approve(): Promise<void> {
    const path = `/commitments/${this.c.commitmentId}/approve`;
    this.busy = true;
    try { await this.api.post(path, { remarks: 'Approved' }); this.toast.show('Commitment approved', 'ok', 'POST ' + path); this.after(); }
    catch (e) { this.toast.error(e); } finally { this.busy = false; }
  }
  async reject(): Promise<void> {
    const path = `/commitments/${this.c.commitmentId}/reject`;
    const reason = await this.confirm.ask({ title: 'Reject commitment?', okLabel: 'Reject', tone: 'danger', input: { label: 'Reason', required: true, max: 500 } });
    if (!reason) return;
    try { await this.api.post(path, { reason }); this.toast.show('Commitment rejected', 'ok', 'POST ' + path); this.after(); } catch (e) { this.toast.error(e); }
  }
  recordProgress(): void {
    const c = this.c; const me = this.auth.me()!;
    this.form = {
      title: 'Record progress', size: 'narrow',
      fields: fieldsFor('commitment-progresses', [{ name: 'progressValue', label: `Achieved so far (${this.unit})`, required: true, full: true }, { name: 'remarks', full: true }]),
      submit: v => this.api.post('/commitment-progresses', { ...v, commitmentId: c.commitmentId, recordedBy: me.userId }).then(x => { this.toast.show('Progress recorded', 'ok', 'POST /commitment-progresses'); this.after(); return x; })
    };
  }
  /** The backend needs a status on create and then sets it to "Pending" itself. */
  private firstStatusId(): any {
    const all = this.ref.rows('commitment-statuses');
    const s = all.find((x: any) => ['pending', 'submitted'].includes(String(x.statusName).toLowerCase())) ?? all.find((x: any) => !x.isTerminal) ?? all[0];
    return s ? s.commitmentStatusId : null;
  }
  newCommitment(): void {
    const me = this.auth.me()!;
    const due = new Date(); due.setDate(due.getDate() + 30);
    this.form = {
      title: 'New commitment', sub: 'A target you commit to. The sales manager approves it.', submitLabel: 'Submit',
      value: { dueDate: due.toISOString().slice(0, 10) },
      fields: fieldsFor('commitments', [{ name: 'targetName', label: 'What you commit to', full: true, required: true }, { name: 'targetValue', required: true }, { name: 'measurementUnitId', label: 'Unit', required: true }, { name: 'dueDate', required: true, min: undefined, hint: `Today is ${fmt.date(todayIso())}` }]),
      submit: v => this.api.post('/commitments', { ...v, distributorId: me.distributorId, createdBy: me.userId, commitmentStatusId: this.firstStatusId() }).then(x => { this.toast.show('Commitment submitted', 'ok', 'POST /commitments'); this.table?.reload(); return x; })
    };
  }
}
