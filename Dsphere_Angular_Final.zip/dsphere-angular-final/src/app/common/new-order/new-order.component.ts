/* "New order": pick products and quantities; POST /distributor-orders then POST /order-items per line (replaces newOrderModal()). */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { todayIso } from '../../shared/format';
import { ModalComponent } from '../../shared/modal.component';
import { FORMAT_PIPES } from '../../shared/pipes';

/** ORD-yyyyMMdd-HHmmss-NN: unique enough for a person placing orders by hand. */
export function newOrderNumber(d = new Date()): string {
  const p = (n: number, w = 2) => String(n).padStart(w, '0');
  return `ORD-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}-${p(Math.floor(Math.random() * 100))}`;
}

interface Line { productId: number | ''; quantity: number; }

@Component({
  selector: 'app-new-order', standalone: true, imports: [FormsModule, ModalComponent, ...FORMAT_PIPES],
  templateUrl: './new-order.component.html'
})
export class NewOrderComponent implements OnInit {
  /** Fixed distributor (a distributor ordering for themselves); otherwise a picker is shown. */
  @Input() distributorId: number | null = null;
  @Output() closed = new EventEmitter<void>();
  @Output() placed = new EventEmitter<any>();

  products: any[] = [];
  distributors: [any, string][] = [];
  dist: number | '' = '';
  lines: Line[] = [{ productId: '', quantity: 10 }, { productId: '', quantity: 10 }];
  error = '';
  busy = false;

  constructor(private api: ApiService, private auth: AuthService, public ref: RefService, private toast: ToastService) {}

  async ngOnInit(): Promise<void> {
    await this.ref.ensure(['products', 'distributors', 'order-statuses']);
    this.products = this.ref.rows('products').filter(p => p.status === 'Active');
    this.distributors = this.ref.options('distributors');
    this.dist = this.distributorId ?? this.auth.me()?.distributorId ?? '';
  }
  get fixed(): boolean { return !!(this.distributorId ?? this.auth.me()?.distributorId); }
  /** List price: the backend stores unitPrice on each order item; here it is derived from the product's unit cost. */
  price(productId: number | ''): number { const p = this.products.find(x => x.productId === productId); return p ? Math.round(Number(p.unitCost) / 0.72) : 0; }
  get total(): number { return this.lines.reduce((a, l) => a + this.price(l.productId) * (Number(l.quantity) || 0), 0); }
  add(): void { this.lines.push({ productId: '', quantity: 10 }); }
  remove(i: number): void { this.lines.splice(i, 1); }

  async place(): Promise<void> {
    this.error = '';
    const picked = this.lines.filter(l => l.productId !== '');
    if (!this.dist) { this.error = 'Choose the distributor.'; return; }
    if (!picked.length) { this.error = 'Add at least one product.'; return; }
    if (picked.some(l => !(Number(l.quantity) > 0))) { this.error = 'Every quantity must be greater than 0.'; return; }
    if (new Set(picked.map(l => l.productId)).size !== picked.length) { this.error = 'Each product can be on the order only once. Change the quantity instead.'; return; }
    // The backend needs the order number and the first status ("Placed") in the request.
    const placed = this.ref.rows('order-statuses').find((s: any) => String(s.statusName).toLowerCase() === 'placed')
      ?? [...this.ref.rows('order-statuses')].filter((s: any) => !s.isTerminal).sort((a: any, b: any) => Number(a.sequenceNumber) - Number(b.sequenceNumber))[0];
    if (!placed) { this.error = 'Orders cannot be placed yet: the order status "Placed" is missing. Ask the System Admin to add it under Master data → Order statuses.'; return; }
    this.busy = true;
    try {
      const o = await this.api.post('/distributor-orders', {
        orderNumber: newOrderNumber(), distributorId: this.dist, orderStatusId: placed.orderStatusId, orderDate: todayIso(), createdBy: this.auth.me()?.userId
      });
      for (const l of picked) await this.api.post('/order-items', { orderId: o.orderId, productId: l.productId, quantity: Number(l.quantity), unitPrice: this.price(l.productId) });
      this.toast.show(`Order ${o.orderNumber} placed`, 'ok', 'POST /distributor-orders + /order-items');
      this.placed.emit(o);
      this.closed.emit();
    } catch (e: any) {
      this.error = e.message;
    } finally { this.busy = false; }
  }
}
