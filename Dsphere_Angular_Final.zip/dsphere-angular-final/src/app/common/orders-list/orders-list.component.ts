/* The order list used by the distributor and the sales manager (replaces ordersTable() in common.js). */
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { fmt } from '../../shared/format';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter, RowAction } from '../../shared/data-table/data-table.types';
import { NewOrderComponent } from '../new-order/new-order.component';
import { OrderDrawerComponent } from '../order-drawer/order-drawer.component';

@Component({
  selector: 'app-orders-list', standalone: true, imports: [DataTableComponent, OrderDrawerComponent, NewOrderComponent],
  template: `
  <app-data-table path="/distributor-orders" [query]="query" [columns]="columns" [filters]="filters" [actions]="actions" sort="orderDate,desc"
                  searchField="orderNumber" searchPlaceholder="Search order number" (rowClick)="openId = $event.orderId">
    @if (allowCreate && auth.can('POST', '/distributor-orders')) {
      <button tools class="btn sm primary" type="button" (click)="creating = true">New order</button>
    }
  </app-data-table>
  @if (openId) { <app-order-drawer [orderId]="openId" (closed)="openId = null" (changed)="refresh()" /> }
  @if (creating) { <app-new-order [distributorId]="distributorId" (closed)="creating = false" (placed)="refresh()" /> }`
})
export class OrdersListComponent implements OnInit {
  @Input() allowCreate = false;
  @Input() distributorId: number | null = null;
  @ViewChild(DataTableComponent) table?: DataTableComponent;

  openId: any = null;
  creating = false;
  query: Record<string, any> = {};
  columns: Column[] = [];
  filters: Filter[] = [];
  actions: RowAction[] = [];
  private totals = new Map<number, { count: number; value: number }>();

  constructor(private api: ApiService, public auth: AuthService, private route: ActivatedRoute, private ref: RefService, private toast: ToastService) {}

  async ngOnInit(): Promise<void> {
    await this.ref.ensure(['order-statuses']);
    const own = !!this.auth.me()?.distributorId;
    if (this.distributorId) this.query = { distributorId: this.distributorId };
    this.columns = [
      { key: 'orderNumber', label: 'Order', type: 'strong', sub: r => fmt.date(r.orderDate) },
      ...(own ? [] : [{ key: 'distributorId', label: 'Distributor', type: 'ref' as const, ref: 'distributors' }]),
      { key: 'orderStatusId', label: 'Status', type: 'status', ref: 'order-statuses' },
      { key: 'items', label: 'Items', type: 'num', value: r => this.totals.get(r.orderId)?.count ?? 0, sortable: false },
      { key: 'value', label: 'Value', type: 'money', value: r => this.totals.get(r.orderId)?.value ?? 0, sortable: false },
      { key: 'updatedAt', label: 'Updated', type: 'ago' }
    ];
    this.filters = [{ key: 'orderStatusId', label: 'Status', ref: 'order-statuses' }, ...(own || this.distributorId ? [] : [{ key: 'distributorId', label: 'Distributor', ref: 'distributors' }])];
    // Sales: approve a placed order, or move an approved one to Processing, straight from the list (the drawer does the same).
    const move = (from: string, to: string, label: string): RowAction => ({
      label, tone: 'primary',
      show: r => this.ref.name('order-statuses', r.orderStatusId) === from && this.auth.can('POST', `/distributor-orders/${r.orderId}/status`),
      run: async r => {
        try {
          await this.api.post(`/distributor-orders/${r.orderId}/status`, { status: to, remarks: `Moved to ${to}` });
          this.toast.show(`Order ${r.orderNumber} moved to ${to}`);
          await this.refresh();
        } catch (e) { this.toast.error(e); }
      }
    });
    this.actions = own ? [] : [move('Placed', 'Approved', 'Approve'), move('Approved', 'Processing', 'Start processing')];
    await this.loadTotals();
    this.table?.reload(true);
    const open = this.route.snapshot.queryParamMap.get('open');
    if (open) this.openId = open;
  }
  /** Item count and value per order, from the order items. */
  private async loadTotals(): Promise<void> {
    const items = await this.api.all('/order-items').catch(() => []);
    this.totals.clear();
    for (const i of items) {
      const t = this.totals.get(i.orderId) ?? { count: 0, value: 0 };
      t.count++; t.value += Number(i.quantity) * Number(i.unitPrice);
      this.totals.set(i.orderId, t);
    }
  }
  async refresh(): Promise<void> { await this.loadTotals(); this.table?.reload(true); }
}
