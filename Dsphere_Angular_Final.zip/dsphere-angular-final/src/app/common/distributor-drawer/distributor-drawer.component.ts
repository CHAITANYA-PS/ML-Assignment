/* Distributor 360°: health, target achievement, credit risk, details and continuity (replaces distributorDrawer()). */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { RefService } from '../../core/ref.service';
import { lineChart } from '../../shared/charts';
import { ChartComponent } from '../../shared/chart.component';
import { fmt } from '../../shared/format';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { ModalComponent } from '../../shared/modal.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';

const BAND_TONE: Record<string, 'ok' | 'warn' | 'danger'> = { 'Low risk': 'ok', 'Medium risk': 'warn', 'High risk': 'danger' };

@Component({
  selector: 'app-distributor-drawer', standalone: true, imports: [ModalComponent, KpiCardComponent, StatusPillComponent, ChartComponent, ...FORMAT_PIPES],
  templateUrl: './distributor-drawer.component.html'
})
export class DistributorDrawerComponent implements OnInit {
  @Input() distributorId!: number | string;
  @Output() closed = new EventEmitter<void>();

  d: any = null;
  last: any = null;
  perf: any = null;
  cont: any = null;
  limit: any = null;
  risk: any = null;
  chart = '';

  constructor(private api: ApiService, public ref: RefService) {}

  async ngOnInit(): Promise<void> {
    const id = this.distributorId;
    await this.ref.ensure(['regions', 'reporting-periods', 'risk-bands']);
    const [d, trend, perf, cont, limits, risk] = await Promise.all([
      this.api.get(`/distributors/${id}`),
      this.api.get<any[]>(`/health-scores/${id}/trend`).catch(() => []),
      this.api.get(`/performance/${id}`).catch(() => null),
      this.api.get(`/continuity/${id}`).catch(() => null),
      this.api.all('/distributor-credit-limits', { distributorId: id }).catch(() => []),
      this.api.all('/credit-risk-assessments', { distributorId: id }).catch(() => [])
    ]);
    this.d = d; this.perf = perf; this.cont = cont;
    this.last = trend.length ? trend[trend.length - 1] : null;
    this.limit = limits.length ? limits[limits.length - 1] : null;
    this.risk = risk.length ? risk[risk.length - 1] : null;
    if (trend.length) this.chart = lineChart({ labels: trend.map(h => this.ref.name('reporting-periods', h.reportingPeriodId)), series: [{ name: 'Score', values: trend.map(h => h.totalScore) }], height: 170, maxValue: 100, bands: [{ from: 0, to: 50, color: 'var(--danger-bg)' }] });
  }
  get band(): string { return this.last ? this.ref.name('risk-bands', this.last.riskBandId) : ''; }
  get healthTone() { return this.last ? BAND_TONE[this.band] : null; }
  get perfTone() { return this.perf ? (this.perf.status === 'RECOVERY' ? 'danger' : this.perf.status === 'ACHIEVED' ? 'ok' : 'warn') : null; }
  get riskTone() { return this.risk ? (this.risk.riskScore >= 70 ? 'danger' : this.risk.riskScore >= 40 ? 'warn' : 'ok') : null; }
  get healthValue(): string { return this.last ? fmt.dec(this.last.totalScore) : '–'; }
  get healthFoot(): string { return this.last ? this.band || 'Not calculated' : 'Not calculated'; }
  get perfValue(): string { return this.perf ? fmt.pct(this.perf.performancePercent) : '–'; }
  get riskValue(): string { return this.risk ? String(this.risk.riskScore) : '–'; }
  get riskFoot(): string { return this.limit ? `Limit ${fmt.moneyShort(this.limit.creditLimit)}` : 'No limit'; }
}
