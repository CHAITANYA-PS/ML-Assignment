/* Shipments for the manufacturer (verify and dispatch) and the distributor (confirm delivery). ?open=<id> opens one. */
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { inTransit } from '../shipment-state';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter, RowAction } from '../../shared/data-table/data-table.types';
import { ConfirmDeliveryComponent } from '../confirm-delivery/confirm-delivery.component';
import { ShipmentDrawerComponent } from '../shipment-drawer/shipment-drawer.component';

@Component({
  selector: 'app-shipments-list', standalone: true, imports: [DataTableComponent, ShipmentDrawerComponent, ConfirmDeliveryComponent],
  template: `
  <app-data-table path="/shipments" [columns]="columns" [filters]="filters" [actions]="actions" sort="shipmentId,desc"
                  searchField="trackingNumber" searchPlaceholder="Search tracking number" emptyTitle="No shipments" (rowClick)="openId = $event.shipmentId" />
  @if (openId) { <app-shipment-drawer [shipmentId]="openId" (closed)="openId = null" (changed)="table?.reload(true)" /> }
  @if (confirming) { <app-confirm-delivery [shipment]="confirming.s" [items]="confirming.items" (closed)="confirming = null" (done)="confirmed()" /> }`
})
export class ShipmentsListComponent implements OnInit {
  /** Manufacturer view: shows the warehouse and who dispatched. */
  @Input() manufacturer = false;
  @ViewChild(DataTableComponent) table?: DataTableComponent;
  openId: any = null;
  confirming: { s: any; items: any[] } | null = null;
  columns: Column[] = [];
  filters: Filter[] = [];
  actions: RowAction[] = [];

  constructor(private api: ApiService, private auth: AuthService, private ref: RefService, private route: ActivatedRoute) {}

  async ngOnInit(): Promise<void> {
    await this.ref.ensure(['shipment-statuses', 'warehouses', 'app-users']);
    this.columns = [
      { key: 'trackingNumber', label: 'Tracking', type: 'mono' },
      ...(this.manufacturer ? [{ key: 'warehouseId', label: 'From', type: 'ref' as const, ref: 'warehouses' }] : []),
      { key: 'shipmentStatusId', label: 'Status', type: 'status', ref: 'shipment-statuses' },
      { key: 'dispatchDate', label: 'Dispatched', type: 'date' },
      { key: 'deliveryDate', label: 'Delivered', type: 'date' },
      ...(this.manufacturer ? [{ key: 'dispatchedBy', label: 'Dispatched by', value: (r: any) => (r.dispatchedBy ? this.ref.name('app-users', r.dispatchedBy) : '–') }] : [])
    ];
    this.filters = [{ key: 'shipmentStatusId', label: 'Status', ref: 'shipment-statuses' }, ...(this.manufacturer ? [{ key: 'warehouseId', label: 'Warehouse', ref: 'warehouses' }] : [])];
    this.actions = this.manufacturer ? [] : [{
      label: 'Confirm delivery', tone: 'primary',
      show: r => inTransit(r, this.ref.name('shipment-statuses', r.shipmentStatusId)) && this.auth.can('POST', `/delivery-receipts/${r.shipmentId}/confirm`),
      run: async r => { this.confirming = { s: r, items: await this.api.all('/shipment-items', { shipmentId: r.shipmentId }) }; }
    }];
    this.openId = this.route.snapshot.queryParamMap.get('open');
  }
  confirmed(): void { this.confirming = null; this.table?.reload(true); }
}
