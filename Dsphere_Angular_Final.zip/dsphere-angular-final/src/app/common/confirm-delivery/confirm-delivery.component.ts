/* Distributor confirms a delivery with the 6-digit handover code and the counts per item (replaces confirmDelivery()). */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { ModalComponent } from '../../shared/modal.component';
import { FORMAT_PIPES } from '../../shared/pipes';

interface Line { item: any; received: number; damaged: number; }

@Component({
  selector: 'app-confirm-delivery', standalone: true, imports: [FormsModule, ModalComponent, ...FORMAT_PIPES],
  templateUrl: './confirm-delivery.component.html'
})
export class ConfirmDeliveryComponent implements OnInit {
  @Input() shipment: any;
  @Input() items: any[] = [];
  @Output() closed = new EventEmitter<void>();
  @Output() done = new EventEmitter<any>();

  code = '';
  codeError = '';
  remarks = '';
  error = '';
  busy = false;
  lines: Line[] = [];

  constructor(private api: ApiService, public ref: RefService, private toast: ToastService) {}

  async ngOnInit(): Promise<void> {
    await this.ref.ensure(['products', 'product-batches']);
    this.lines = this.items.map(i => ({ item: i, received: Number(i.quantity), damaged: 0 }));
  }
  batch(it: any): any { return this.ref.get('product-batches', it.productBatchId) ?? {}; }
  /** Received + damaged can never exceed what was shipped. */
  damagedChanged(l: Line): void {
    const d = Number(l.damaged) || 0;
    if (Number(l.received) + d > Number(l.item.quantity)) l.received = Math.max(0, Number(l.item.quantity) - d);
  }

  async confirm(): Promise<void> {
    this.error = ''; this.codeError = '';
    if (!/^\d{6}$/.test(this.code)) { this.codeError = 'Handover code is 6 digits'; return; }
    this.busy = true;
    try {
      const r = await this.api.post<any>(`/delivery-receipts/${this.shipment.shipmentId}/confirm`, {
        handoverCode: this.code, remarks: this.remarks || null,
        items: this.lines.map(l => ({ shipmentItemId: l.item.shipmentItemId, receivedQuantity: Number(l.received), damagedQuantity: Number(l.damaged) }))
      });
      const n = r?.discrepancies?.length ?? 0;
      this.toast.show(n ? `Delivery confirmed. ${n} difference(s) logged and a ticket was raised` : 'Delivery confirmed. The stock is now in your inventory', 'ok', `POST /delivery-receipts/${this.shipment.shipmentId}/confirm`);
      this.done.emit(r);
    } catch (e: any) {
      if (e?.fieldErrors?.handoverCode) this.codeError = e.fieldErrors.handoverCode;
      this.error = e.message;
    } finally { this.busy = false; }
  }
}
