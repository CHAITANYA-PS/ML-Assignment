/* Ticket list for the distributor and the recovery manager, with "Raise a ticket" (replaces ticketsTable() and newTicket()). */
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { fmt } from '../../shared/format';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter } from '../../shared/data-table/data-table.types';
import { FormModalComponent } from '../../shared/form-modal/form-modal.component';
import { FieldSpec, fieldsFor } from '../../shared/form-modal/form-fields';
import { PRIORITY_TONE, TicketDrawerComponent } from '../ticket-drawer/ticket-drawer.component';

@Component({
  selector: 'app-tickets-list', standalone: true, imports: [DataTableComponent, TicketDrawerComponent, FormModalComponent],
  template: `
  <app-data-table path="/tickets" [query]="query" [columns]="columns" [filters]="filters" sort="createdAt,desc"
                  searchField="subject" searchPlaceholder="Search subject" (rowClick)="openId = $event.ticketId">
    @if (allowCreate && auth.can('POST', '/tickets')) {
      <button tools class="btn sm primary" type="button" (click)="creating = true">Raise a ticket</button>
    }
  </app-data-table>
  @if (openId) { <app-ticket-drawer [ticketId]="openId" (closed)="openId = null" (changed)="table?.reload(true)" /> }
  @if (creating) {
    <app-form-modal title="Raise a support ticket" sub="The SLA clock starts from the priority you choose." submitLabel="Raise ticket"
                    [fields]="fields" [value]="{}" [submit]="raise" (closed)="creating = false" />
  }`
})
export class TicketsListComponent implements OnInit {
  @Input() allowCreate = false;
  /** Only tickets assigned to the signed-in user. */
  @Input() mine = false;
  @ViewChild(DataTableComponent) table?: DataTableComponent;

  openId: any = null;
  creating = false;
  query: Record<string, any> = {};
  columns: Column[] = [];
  filters: Filter[] = [];
  fields: FieldSpec[] = [];

  constructor(private api: ApiService, public auth: AuthService, private ref: RefService, private toast: ToastService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    const own = !!this.auth.me()?.distributorId;
    if (this.mine) this.query = { assignedTo: this.auth.me()?.userId };
    this.columns = [
      { key: 'referenceNumber', label: 'Ticket', type: 'strong', sub: r => r.subject },
      ...(own ? [] : [{ key: 'distributorId', label: 'Distributor', type: 'ref' as const, ref: 'distributors' }]),
      { key: 'ticketPriorityId', label: 'Priority', type: 'status', ref: 'ticket-priorities', tone: r => PRIORITY_TONE[this.ref.name('ticket-priorities', r.ticketPriorityId)] },
      { key: 'ticketStatusId', label: 'Status', type: 'status', ref: 'ticket-statuses' },
      { key: 'assignedTo', label: 'Assigned to', value: r => (r.assignedTo ? this.ref.name('app-users', r.assignedTo) : 'Unassigned') },
      { key: 'slaDueAt', label: 'SLA', value: r => this.sla(r) },
      { key: 'createdAt', label: 'Raised', type: 'ago' }
    ];
    this.filters = [
      { key: 'ticketStatusId', label: 'Status', ref: 'ticket-statuses' },
      { key: 'ticketPriorityId', label: 'Priority', ref: 'ticket-priorities' },
      ...(own ? [] : [{ key: 'distributorId', label: 'Distributor', ref: 'distributors' }])
    ];
    this.fields = fieldsFor('tickets', [
      ...(own ? [] : [{ name: 'distributorId', required: true }]),
      { name: 'ticketCategoryId', label: 'Category', required: true }, { name: 'ticketPriorityId', label: 'Priority', required: true },
      { name: 'subject', required: true, full: true }, { name: 'description', required: true, full: true, type: 'textarea' as const }
    ]);
    this.ref.ensure(['app-users']).then(() => this.table?.reload(true));
    const open = this.route.snapshot.queryParamMap.get('open');
    if (open) this.openId = open;
  }
  sla(r: any): string {
    const st = this.ref.name('ticket-statuses', r.ticketStatusId);
    if (['Resolved', 'Closed'].includes(st)) return 'Met';
    if (!r.slaDueAt) return '–';
    return `${new Date(r.slaDueAt) < new Date() ? 'Breached' : 'Due'} ${fmt.ago(r.slaDueAt)}`;
  }
  raise = (v: any) => {
    const me = this.auth.me()!;
    return this.api.post('/tickets', { ...v, distributorId: me.distributorId || v.distributorId, createdBy: me.userId }).then(r => {
      this.toast.show(`Ticket ${r.referenceNumber} raised`, 'ok', 'POST /tickets');
      this.table?.reload();
      return r;
    });
  };
}
