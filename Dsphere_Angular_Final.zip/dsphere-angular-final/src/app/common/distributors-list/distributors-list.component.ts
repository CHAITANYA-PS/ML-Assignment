/* The distributor network for the admin and the sales manager (replaces distributorsTable()). A row opens the 360° drawer; ?open=<id> opens one directly. */
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Column, Filter } from '../../shared/data-table/data-table.types';
import { FieldSpec } from '../../shared/form-modal/form-fields';
import { todayIso } from '../../shared/format';
import { CrudTableComponent } from '../crud-table/crud-table.component';
import { DistributorDrawerComponent } from '../distributor-drawer/distributor-drawer.component';

@Component({
  selector: 'app-distributors-list', standalone: true, imports: [CrudTableComponent, DistributorDrawerComponent],
  template: `
  <app-crud-table resource="distributors" [columns]="columns" [filters]="filters" [fields]="fields" sort="distributorName,asc"
                  searchField="distributorName" searchPlaceholder="Search distributor name" [defaults]="{ onboardingDate: today, status: 'Pending' }"
                  [describe]="describe" [open]="openRow" />
  @if (openId) { <app-distributor-drawer [distributorId]="openId" (closed)="openId = null" /> }`
})
export class DistributorsListComponent implements OnInit {
  openId: any = null;
  readonly today = todayIso();
  readonly columns: Column[] = [
    { key: 'distributorName', label: 'Distributor', type: 'strong', sub: r => r.distributorCode },
    { key: 'regionId', label: 'Region', type: 'ref', ref: 'regions' },
    { key: 'contactPerson', label: 'Contact' },
    { key: 'phone', label: 'Phone' },
    { key: 'status', label: 'Status', type: 'pill' },
    { key: 'onboardingDate', label: 'Onboarded', type: 'date' }
  ];
  readonly filters: Filter[] = [
    { key: 'status', label: 'Status', options: ['Active', 'Pending', 'Suspended', 'Inactive'] },
    { key: 'regionId', label: 'Region', ref: 'regions' }
  ];
  readonly fields: (string | FieldSpec)[] = ['distributorCode', 'distributorName', 'regionId', 'contactPerson', 'email', 'phone', { name: 'address', full: true, type: 'textarea' }, 'status', 'onboardingDate'];

  constructor(private route: ActivatedRoute) {}
  ngOnInit(): void { this.openId = this.route.snapshot.queryParamMap.get('open'); }
  describe = (r: any) => r.distributorName;
  openRow = (r: any) => { this.openId = r.distributorId; };
}
