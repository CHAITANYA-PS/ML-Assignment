/* Invoice balances worked out from the payments, as the backend does (outstanding = amount − completed payments). */
import { ApiService } from '../core/api.service';
import { RefService } from '../core/ref.service';
import { fmt } from '../shared/format';

export interface InvoiceRow { [k: string]: any; paid: number; outstanding: number; overdueDays: number; distributorId: any; distributorName: string; orderNumber: string; status: string; }

export async function loadInvoices(api: ApiService, ref: RefService): Promise<InvoiceRow[]> {
  ref.invalidate('payments');
  await ref.ensure(['payments', 'payment-statuses', 'invoice-statuses', 'distributor-orders', 'distributors']);
  const inv = await api.all('/invoices');
  const done = ref.rows('payment-statuses').find((s: any) => s.statusName === 'Completed');
  return inv.map(i => {
    const paid = ref.rows('payments').filter((p: any) => p.invoiceId === i.invoiceId && (!done || p.paymentStatusId === done.paymentStatusId)).reduce((a: number, p: any) => a + Number(p.amount), 0);
    const outstanding = Math.max(0, Number(i.invoiceAmount) - paid);
    const overdueDays = outstanding > 0 ? Math.max(0, -(fmt.daysTo(i.dueDate) ?? 0)) : 0;
    const o = ref.get('distributor-orders', i.orderId) ?? {};
    return { ...i, paid, outstanding, overdueDays, distributorId: o.distributorId, distributorName: ref.name('distributors', o.distributorId), orderNumber: o.orderNumber, status: ref.name('invoice-statuses', i.invoiceStatusId) };
  });
}

export const AGE: [string, (d: number, r: InvoiceRow) => boolean][] = [
  ['Not due', (d, r) => r.outstanding > 0 && d === 0], ['1–30 days', d => d >= 1 && d <= 30], ['31–60 days', d => d > 30 && d <= 60], ['60+ days', d => d > 60]
];
