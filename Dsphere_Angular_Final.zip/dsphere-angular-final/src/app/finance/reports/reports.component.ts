/* Finance › Reports. */
import { Component } from '@angular/core';
import { ReportsComponent } from '../../common/reports/reports.component';

@Component({
  selector: 'app-finance-reports', standalone: true, imports: [ReportsComponent],
  template: `<app-reports [defaults]="defaults" />`
})
export class FinanceReportsComponent { readonly defaults = ['invoices', 'payments', 'credit-risk-assessments', 'distributors']; }
