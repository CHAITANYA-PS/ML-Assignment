/* Finance › Payments: every payment received, with its method and bank reference. */
import { Component } from '@angular/core';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { Column, Filter } from '../../shared/data-table/data-table.types';
import { todayIso } from '../../shared/format';
import { FieldSpec } from '../../shared/form-modal/form-fields';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-finance-payments', standalone: true, imports: [PageHeadComponent, CrudTableComponent],
  template: `
  <app-page-head eyebrow="Receivables" title="Payments" text="Every payment received, with its method and bank reference." />
  <section class="card"><div class="card-body flush">
    <app-crud-table resource="payments" [columns]="columns" [filters]="filters" [fields]="fields" sort="paymentDate,desc"
                    searchField="transactionReference" searchPlaceholder="Search reference" [defaults]="defaults" />
  </div></section>`
})
export class PaymentsComponent {
  readonly defaults = { paymentDate: todayIso() };
  readonly columns: Column[] = [
    { key: 'paymentDate', label: 'Date', type: 'date' }, { key: 'invoiceId', label: 'Invoice', type: 'ref', ref: 'invoices' },
    { key: 'amount', label: 'Amount', type: 'money' }, { key: 'paymentMethodId', label: 'Method', type: 'ref', ref: 'payment-methods' },
    { key: 'transactionReference', label: 'Reference', type: 'mono' }, { key: 'paymentStatusId', label: 'Status', type: 'status', ref: 'payment-statuses' }
  ];
  readonly filters: Filter[] = [{ key: 'paymentMethodId', label: 'Method', ref: 'payment-methods' }, { key: 'paymentStatusId', label: 'Status', ref: 'payment-statuses' }];
  readonly fields: (string | FieldSpec)[] = ['invoiceId', 'amount', 'paymentDate', 'paymentMethodId', { name: 'transactionReference', mono: true }, 'paymentStatusId'];
}
