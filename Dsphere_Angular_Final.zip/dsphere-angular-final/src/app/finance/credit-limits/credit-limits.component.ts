/* Finance › Credit limits: the most a distributor may owe. Approving an order over the limit is refused. */
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { CrudTableComponent } from '../../common/crud-table/crud-table.component';
import { meter } from '../../shared/charts';
import { Column, Filter } from '../../shared/data-table/data-table.types';
import { fmt, todayIso } from '../../shared/format';
import { PageHeadComponent } from '../../shared/page-head.component';
import { loadInvoices } from '../invoices';

@Component({
  selector: 'app-finance-credit-limits', standalone: true, imports: [PageHeadComponent, CrudTableComponent],
  template: `
  <app-page-head eyebrow="Credit" title="Credit limits" text="The most a distributor may owe. Approving an order that would go over the limit is refused." />
  <section class="card"><div class="card-body flush">
    @if (ready) {
      <app-crud-table resource="distributor-credit-limits" entity="Credit limit" [columns]="columns" [filters]="filters" [fields]="fields"
                      sort="creditLimit,desc" [defaults]="defaults" [beforeCreate]="beforeCreate" />
    }
  </div></section>`
})
export class CreditLimitsComponent implements OnInit {
  ready = false;
  owed: Record<string, number> = {};
  readonly defaults = { validFrom: todayIso() };
  readonly fields = ['distributorId', 'creditLimit', 'validFrom', 'validTo'];
  readonly filters: Filter[] = [{ key: 'distributorId', label: 'Distributor', ref: 'distributors' }];
  readonly columns: Column[] = [
    { key: 'distributorId', label: 'Distributor', type: 'ref', ref: 'distributors' },
    { key: 'creditLimit', label: 'Limit', type: 'money' },
    { key: 'used', label: 'Used', html: r => { const u = this.owed[r.distributorId] || 0; const pct = r.creditLimit ? (u / Number(r.creditLimit)) * 100 : 0; return `<div style="min-width:150px">${meter(pct, pct >= 90 ? 'danger' : pct >= 70 ? 'warn' : 'ok')}<div class="cell-sub">${fmt.money(u)} · ${fmt.pct(pct)}</div></div>`; } },
    { key: 'validFrom', label: 'From', type: 'date' }, { key: 'validTo', label: 'To', type: 'date' },
    { key: 'approvedBy', label: 'Approved by', type: 'ref', ref: 'app-users' }
  ];
  constructor(private api: ApiService, private auth: AuthService, private ref: RefService) {}
  beforeCreate = (v: any) => ({ ...v, approvedBy: this.auth.me()?.userId });
  async ngOnInit(): Promise<void> {
    for (const i of await loadInvoices(this.api, this.ref)) this.owed[i.distributorId] = (this.owed[i.distributorId] || 0) + i.outstanding;
    this.ready = true;
  }
}
