/* Pages of the finance stakeholder. Each page is lazy-loaded and guarded by the backend call it needs
 * (canGuard checks the role_permission rules, the same as the sidebar). */
import { Routes } from '@angular/router';
import { canGuard } from '../core/guards';

export const FINANCE_ROUTES: Routes = [
  { path: 'dashboard', title: 'Dashboard · Dsphere', canActivate: [canGuard('GET', '/dashboard/summary')], loadComponent: () => import('./dashboard/dashboard.component').then(m => m.FinanceDashboardComponent) },
  { path: 'invoices', title: 'Invoices · Dsphere', canActivate: [canGuard('GET', '/invoices')], loadComponent: () => import('./invoices/invoices.component').then(m => m.InvoicesComponent) },
  { path: 'payments', title: 'Payments · Dsphere', canActivate: [canGuard('GET', '/payments')], loadComponent: () => import('./payments/payments.component').then(m => m.PaymentsComponent) },
  { path: 'credit-limits', title: 'Credit limits · Dsphere', canActivate: [canGuard('GET', '/distributor-credit-limits')], loadComponent: () => import('./credit-limits/credit-limits.component').then(m => m.CreditLimitsComponent) },
  { path: 'credit-risk', title: 'Credit risk · Dsphere', canActivate: [canGuard('GET', '/credit-risk-assessments')], loadComponent: () => import('./credit-risk/credit-risk.component').then(m => m.CreditRiskComponent) },
  { path: 'stock-value', title: 'Stock value · Dsphere', canActivate: [canGuard('GET', '/stocks/summary')], loadComponent: () => import('./stock-value/stock-value.component').then(m => m.StockValueComponent) },
  { path: 'reports', title: 'Reports · Dsphere', canActivate: [canGuard('GET', '/exports')], loadComponent: () => import('./reports/reports.component').then(m => m.FinanceReportsComponent) },
  { path: 'notifications', title: 'Notifications · Dsphere', loadComponent: () => import('../common/notifications/notifications.component').then(m => m.NotificationsComponent) },
  { path: 'profile', title: 'My profile · Dsphere', loadComponent: () => import('../common/profile/profile.component').then(m => m.ProfileComponent) },
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
];
