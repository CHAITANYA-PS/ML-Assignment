/* Finance › Invoices: raise an invoice for a delivered order, edit it, and record payments against it (part payments are allowed). */
import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, Filter, RowAction } from '../../shared/data-table/data-table.types';
import { fmt, saveFile, todayIso } from '../../shared/format';
import { FormModalComponent } from '../../shared/form-modal/form-modal.component';
import { FormState, fieldsFor } from '../../shared/form-modal/form-fields';
import { ModalComponent } from '../../shared/modal.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { StatusPillComponent } from '../../shared/status-pill.component';
import { FORMAT_PIPES } from '../../shared/pipes';
import { InvoiceRow, loadInvoices } from '../invoices';

@Component({
  selector: 'app-finance-invoices', standalone: true, imports: [PageHeadComponent, DataTableComponent, ModalComponent, FormModalComponent, StatusPillComponent, ...FORMAT_PIPES],
  templateUrl: './invoices.component.html'
})
export class InvoicesComponent implements OnInit {
  @ViewChild(DataTableComponent) table?: DataTableComponent;
  open: InvoiceRow | null = null;
  payments: any[] = [];
  form: FormState | null = null;
  exporting = false;
  readonly columns: Column[] = [
    { key: 'invoiceNumber', label: 'Invoice', type: 'strong', sub: r => `Order ${r.orderNumber || '–'}` },
    { key: 'distributorName', label: 'Distributor' },
    { key: 'invoiceDate', label: 'Issued', type: 'date' },
    { key: 'dueDate', label: 'Due', type: 'date', sub: r => (r.overdueDays ? `${r.overdueDays} days overdue` : '') },
    { key: 'invoiceAmount', label: 'Amount', type: 'money' },
    { key: 'outstanding', label: 'Outstanding', type: 'money' },
    { key: 'displayStatus', label: 'Status', type: 'pill' }
  ];
  readonly filters: Filter[] = [{ key: 'displayStatus', label: 'Status', options: [['Unpaid', 'Unpaid'], ['Partially Paid', 'Partially paid'], ['Paid', 'Paid'], ['Overdue', 'Overdue']] }];
  actions: RowAction[] = [];

  constructor(private api: ApiService, public auth: AuthService, public ref: RefService, private toast: ToastService) {}

  source = async () => (await loadInvoices(this.api, this.ref)).map(r => ({ ...r, displayStatus: r.overdueDays && r.outstanding ? 'Overdue' : r.status }));

  ngOnInit(): void {
    this.ref.ensure(['payment-methods']);
    this.actions = [
      { label: 'Record payment', tone: 'primary', show: r => r.outstanding > 0 && this.canPay, run: r => this.recordPayment(r) },
      { label: 'Edit', show: () => this.canEdit, run: r => this.editInvoice(r) }
    ];
  }
  get canPay(): boolean { return this.auth.can('POST', '/payments'); }
  get canCreate(): boolean { return this.auth.can('POST', '/invoices'); }
  get canEdit(): boolean { return this.auth.can('PUT', '/invoices/1'); }

  private unpaidStatusId(): any {
    const all = this.ref.rows('invoice-statuses');
    return (all.find((s: any) => /^(unpaid|issued|open|pending)$/i.test(String(s.statusName))) ?? all[0])?.invoiceStatusId ?? '';
  }
  private nextNumber(existing: any[]): string {
    const year = new Date().getFullYear();
    const used = new Set(existing.map(i => String(i.invoiceNumber)));
    let n = existing.length + 1;
    while (used.has(`INV-${year}-${String(n).padStart(4, '0')}`)) n++;
    return `INV-${year}-${String(n).padStart(4, '0')}`;
  }

  /** New invoice for an order that has none yet (delivered orders first). The amount defaults to the order total. */
  async newInvoice(): Promise<void> {
    try {
      await this.ref.ensure(['distributor-orders', 'order-statuses', 'invoice-statuses', 'distributors']);
      const [orders, invoices, items] = await Promise.all([this.api.all('/distributor-orders'), this.api.all('/invoices'), this.api.all('/order-items')]);
      const billed = new Set(invoices.map((i: any) => i.orderId));
      const total = (id: any) => items.filter((i: any) => i.orderId === id).reduce((a: number, i: any) => a + Number(i.quantity) * Number(i.unitPrice), 0);
      const st = (o: any) => this.ref.name('order-statuses', o.orderStatusId);
      const open = orders.filter((o: any) => !billed.has(o.orderId) && st(o) !== 'Cancelled')
        .sort((a: any, b: any) => Number(st(b) === 'Delivered') - Number(st(a) === 'Delivered'));
      if (!open.length) { this.toast.show('Every order already has an invoice', 'info'); return; }
      const due = new Date(); due.setDate(due.getDate() + 30);
      this.form = {
        title: 'New invoice', sub: 'Raise an invoice for an order. Delivered orders are listed first.', submitLabel: 'Create invoice',
        value: { invoiceNumber: this.nextNumber(invoices), invoiceDate: todayIso(), dueDate: due.toISOString().slice(0, 10), invoiceStatusId: this.unpaidStatusId() },
        fields: fieldsFor('invoices', [
          { name: 'orderId', label: 'Order', type: 'select', required: true, full: true,
            options: open.map((o: any) => [o.orderId, `${o.orderNumber} · ${this.ref.name('distributors', o.distributorId)} · ${st(o)} · ${fmt.money(total(o.orderId))}`] as [any, string]) },
          { name: 'invoiceNumber', label: 'Invoice number', mono: true },
          { name: 'invoiceStatusId', label: 'Status' },
          { name: 'invoiceDate', label: 'Invoice date' },
          { name: 'dueDate', label: 'Due date', validate: (v, all) => (v && all['invoiceDate'] && v < all['invoiceDate'] ? 'Due date cannot be before the invoice date' : null) },
          { name: 'invoiceAmount', label: 'Amount (₹)', required: false, hint: 'Leave empty to use the order total', validate: v => (v !== '' && v != null && Number(v) <= 0 ? 'Amount must be greater than 0' : null) }
        ]),
        submit: async v => {
          const amount = v.invoiceAmount === '' || v.invoiceAmount == null ? total(v.orderId) : Number(v.invoiceAmount);
          if (!(amount > 0)) throw Object.assign(new Error('This order has no items, so its total is 0. Enter the amount.'), { fieldErrors: { invoiceAmount: 'Enter the amount' } });
          const x = await this.api.post<any>('/invoices', { ...v, invoiceAmount: amount });
          this.toast.show(`Invoice ${x.invoiceNumber} created`, 'ok');
          this.table?.reload(true);
          return x;
        }
      };
    } catch (e) { this.toast.error(e); }
  }

  /** Change the number, dates, amount or status of an invoice. The amount cannot go below what is already paid. */
  async editInvoice(inv: InvoiceRow): Promise<void> {
    this.open = null;
    await this.ref.ensure(['invoice-statuses']);
    this.form = {
      title: `Edit invoice ${inv['invoiceNumber']}`, sub: `${inv.distributorName} · order ${inv.orderNumber || '–'} · paid ${fmt.money(inv.paid)}`, submitLabel: 'Save changes',
      value: { invoiceNumber: inv['invoiceNumber'], invoiceDate: inv['invoiceDate'], dueDate: inv['dueDate'], invoiceAmount: inv['invoiceAmount'], invoiceStatusId: inv['invoiceStatusId'], version: inv['version'] },
      fields: fieldsFor('invoices', [
        { name: 'invoiceNumber', label: 'Invoice number', mono: true },
        { name: 'invoiceStatusId', label: 'Status' },
        { name: 'invoiceDate', label: 'Invoice date' },
        { name: 'dueDate', label: 'Due date', validate: (v, all) => (v && all['invoiceDate'] && v < all['invoiceDate'] ? 'Due date cannot be before the invoice date' : null) },
        { name: 'invoiceAmount', label: 'Amount (₹)', validate: v => (Number(v) + 0.001 < inv.paid ? `Amount cannot be less than the ${fmt.money(inv.paid)} already paid` : Number(v) <= 0 ? 'Amount must be greater than 0' : null) }
      ]),
      submit: async v => {
        const x = await this.api.put<any>(`/invoices/${inv['invoiceId']}`, { ...v, version: inv['version'] });
        this.toast.show(`Invoice ${x.invoiceNumber ?? inv['invoiceNumber']} saved`, 'ok');
        this.table?.reload(true);
        return x;
      }
    };
  }

  show(r: InvoiceRow): void {
    this.payments = this.ref.rows('payments').filter((p: any) => p.invoiceId === r['invoiceId']);
    this.open = r;
  }
  recordPayment(inv: InvoiceRow): void {
    this.open = null;
    const completed = this.ref.rows('payment-statuses').find((s: any) => s.statusName === 'Completed');
    this.form = {
      title: 'Record payment', sub: `${inv['invoiceNumber']} · ${inv.distributorName} · outstanding ${fmt.money(inv.outstanding)}`, submitLabel: 'Record payment',
      value: { amount: inv.outstanding, paymentDate: todayIso(), paymentStatusId: completed?.paymentStatusId },
      fields: fieldsFor('payments', [
        { name: 'amount', validate: v => (Number(v) > inv.outstanding + 0.001 ? `Amount is more than the outstanding ${fmt.money(inv.outstanding)}` : null) },
        'paymentDate', { name: 'paymentMethodId', label: 'Method' }, { name: 'transactionReference', label: 'UTR / cheque number', mono: true }, { name: 'paymentStatusId', label: 'Status' }
      ]),
      submit: async v => {
        const p = await this.api.post('/payments', { ...v, invoiceId: inv['invoiceId'] });
        const left = inv.outstanding - Number(v.amount);
        const st = this.ref.rows('invoice-statuses').find((s: any) => s.statusName === (left <= 0.001 ? 'Paid' : 'Partially Paid'));
        if (st && st.invoiceStatusId !== inv['invoiceStatusId']) await this.api.put(`/invoices/${inv['invoiceId']}`, { invoiceStatusId: st.invoiceStatusId, version: inv['version'] });
        this.toast.show(left <= 0.001 ? `${inv['invoiceNumber']} is fully paid` : `Payment recorded, ${fmt.money(left)} still outstanding`, 'ok', `POST /payments + PUT /invoices/${inv['invoiceId']}`);
        this.table?.reload(true);
        return p;
      }
    };
  }
  async export(): Promise<void> {
    this.exporting = true;
    try { const f = await this.api.download('/exports/invoices', { format: 'xlsx' }); saveFile(f.name, f.blob); }
    catch (e) { this.toast.error(e); } finally { this.exporting = false; }
  }
}
