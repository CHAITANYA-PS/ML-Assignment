/* Finance › Credit risk: score 0–100 from limit use, overdue invoices and health score. 70 and above is high risk. */
import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { ToastService } from '../../core/toast.service';
import { DistributorDrawerComponent } from '../../common/distributor-drawer/distributor-drawer.component';
import { meter } from '../../shared/charts';
import { DataTableComponent } from '../../shared/data-table/data-table.component';
import { Column, RowAction, esc } from '../../shared/data-table/data-table.types';
import { PageHeadComponent } from '../../shared/page-head.component';

const tone = (s: number) => (s >= 70 ? 'danger' : s >= 40 ? 'warn' : 'ok');

@Component({
  selector: 'app-finance-credit-risk', standalone: true, imports: [PageHeadComponent, DataTableComponent, DistributorDrawerComponent],
  template: `
  <app-page-head eyebrow="Credit" title="Credit risk" text="Risk score 0–100 from limit use, overdue invoices and health score. 70 and above is high risk." />
  <section class="card"><div class="card-head"><div><h2>Latest score per distributor</h2></div></div>
    <div class="card-body flush">
      <app-data-table [source]="source" [columns]="columns" [actions]="actions" sort="riskScore,desc" searchPlaceholder="Search distributor"
                      emptyTitle="No distributors" (rowClick)="openId = $event.distributorId" />
    </div></section>
  @if (openId) { <app-distributor-drawer [distributorId]="openId" (closed)="openId = null" /> }`
})
export class CreditRiskComponent implements OnInit {
  @ViewChild(DataTableComponent) table?: DataTableComponent;
  openId: any = null;
  actions: RowAction[] = [];
  readonly columns: Column[] = [
    { key: 'distributorName', label: 'Distributor', type: 'strong' },
    { key: 'riskScore', label: 'Risk score', html: r => (r.riskScore != null ? `<div style="min-width:150px">${meter(Number(r.riskScore), tone(r.riskScore))}<div class="cell-sub">${esc(r.riskScore)} / 100</div></div>` : '<span class="muted">Not assessed</span>') },
    { key: 'band', label: 'Band', type: 'pill', value: r => (r.riskScore == null ? null : r.riskScore >= 70 ? 'High' : r.riskScore >= 40 ? 'Medium' : 'Low'), tone: r => (r.riskScore == null ? 'neutral' : tone(r.riskScore)) },
    { key: 'assessedAt', label: 'Assessed', type: 'ago' }
  ];
  constructor(private api: ApiService, private auth: AuthService, private ref: RefService, private toast: ToastService) {}

  source = async () => {
    await this.ref.ensure(['distributors']);
    const all = await this.api.all('/credit-risk-assessments', { sort: 'assessedAt,asc' });
    const m: Record<string, any> = {};
    for (const r of all) m[r.distributorId] = r;
    return this.ref.rows('distributors').map((d: any) => ({ distributorId: d.distributorId, distributorName: d.distributorName, ...(m[d.distributorId] ? { riskScore: m[d.distributorId].riskScore, assessedAt: m[d.distributorId].assessedAt } : {}) }));
  };
  ngOnInit(): void {
    this.actions = [{ label: 'Calculate', show: r => this.auth.can('POST', `/credit-risk/calculate/${r.distributorId}`), run: r => this.calc(r) }];
  }
  async calc(r: any): Promise<void> {
    try {
      const res = await this.api.post<any>(`/credit-risk/calculate/${r.distributorId}`);
      this.toast.show(`${r.distributorName}: risk calculated`, 'ok', `Risk score ${res.riskScore}`);
      this.table?.reload(true);
    } catch (e) { this.toast.error(e); }
  }
}
