/* Finance › Stock value: quantity × unit cost per warehouse and product, and how much of it is at risk from expiry. */
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { donut, hbars } from '../../shared/charts';
import { ChartComponent } from '../../shared/chart.component';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { PageHeadComponent } from '../../shared/page-head.component';

@Component({
  selector: 'app-finance-stock-value', standalone: true, imports: [PageHeadComponent, KpiCardComponent, ChartComponent],
  template: `
  <app-page-head eyebrow="Insight" title="Stock value" text="Value of the stock in the warehouses (quantity × unit cost), and how much of it is at risk from expiry." />
  @if (loaded) {
    <div class="grid cols-3">
      <app-kpi label="Stock value" [value]="f.moneyShort(total)" [foot]="warehouses + ' warehouses'" [iconPath]="ICONS['coins']" />
      <app-kpi label="Value at expiry risk" [value]="f.moneyShort(risk)" [foot]="f.pct(total ? (risk / total) * 100 : 0, 1) + ' of stock'" tone="warn" [iconPath]="ICONS['clock']" />
      <app-kpi label="Products" [value]="f.num(products)" foot="with stock" [iconPath]="ICONS['box']" />
    </div>
    <div class="grid cols-2 mt">
      <section class="card"><div class="card-head"><div><h2>By warehouse</h2></div></div><div class="card-body"><app-chart [html]="whChart" /></div></section>
      <section class="card"><div class="card-head"><div><h2>Top products by value</h2></div></div><div class="card-body"><app-chart [html]="prChart" /></div></section>
    </div>
  }`
})
export class StockValueComponent implements OnInit {
  readonly ICONS = ICONS;
  f = fmt;
  loaded = false;
  total = 0;
  risk = 0;
  warehouses = 0;
  products = 0;
  whChart = '';
  prChart = '';
  constructor(private api: ApiService) {}
  async ngOnInit(): Promise<void> {
    const [wh, pr] = await Promise.all([this.api.get<any[]>('/stocks/summary', { groupBy: 'warehouse' }), this.api.get<any[]>('/stocks/summary', { groupBy: 'product' })]);
    this.total = wh.reduce((a, w) => a + Number(w.stockValue), 0);
    this.risk = pr.reduce((a, p) => a + (p.totalQuantity ? (p.stockValue * (p.nearExpiryQuantity + p.expiredQuantity)) / p.totalQuantity : 0), 0);
    this.warehouses = wh.length; this.products = pr.length;
    this.whChart = donut({ items: wh.map(w => ({ label: w.warehouseName, value: w.stockValue })), format: fmt.moneyShort, center: fmt.moneyShort(this.total), sub: 'total' });
    this.prChart = hbars([...pr].sort((a, b) => b.stockValue - a.stockValue).slice(0, 8).map(p => ({ label: p.productName, value: p.stockValue })), { format: fmt.money });
    this.loaded = true;
  }
}
