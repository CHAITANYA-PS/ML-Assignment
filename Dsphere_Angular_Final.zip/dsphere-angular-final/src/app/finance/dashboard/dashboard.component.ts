/* Finance › Dashboard: receivables, overdue invoices, collections and credit exposure. */
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { RefService } from '../../core/ref.service';
import { donut, hbars } from '../../shared/charts';
import { ChartComponent } from '../../shared/chart.component';
import { fmt } from '../../shared/format';
import { ICONS } from '../../shared/icons';
import { KpiCardComponent } from '../../shared/kpi-card.component';
import { PageHeadComponent } from '../../shared/page-head.component';
import { FORMAT_PIPES } from '../../shared/pipes';
import { AGE, InvoiceRow, loadInvoices } from '../invoices';

@Component({
  selector: 'app-finance-dashboard', standalone: true, imports: [RouterLink, PageHeadComponent, KpiCardComponent, ChartComponent, ...FORMAT_PIPES],
  templateUrl: './dashboard.component.html'
})
export class FinanceDashboardComponent implements OnInit {
  readonly ICONS = ICONS;
  f = fmt;
  loaded = false;
  out = 0;
  openCount = 0;
  overdue: InvoiceRow[] = [];
  overdueValue = 0;
  collected30 = 0;
  payments = 0;
  high = 0;
  limits = 0;
  ageChart = '';
  topChart = '';

  constructor(private api: ApiService, public auth: AuthService, private ref: RefService) {}
  get firstName(): string { return (this.auth.me()?.userName ?? '').split(' ')[0]; }

  async ngOnInit(): Promise<void> {
    const [inv, limits, risks] = await Promise.all([loadInvoices(this.api, this.ref), this.api.all('/distributor-credit-limits'), this.api.all('/credit-risk-assessments', { sort: 'assessedAt,asc' })]);
    this.out = inv.reduce((a, i) => a + i.outstanding, 0);
    this.openCount = inv.filter(i => i.outstanding > 0).length;
    const overdue = inv.filter(i => i.overdueDays > 0);
    this.overdueValue = overdue.reduce((a, i) => a + i.outstanding, 0);
    this.overdue = [...overdue].sort((a, b) => b.overdueDays - a.overdueDays).slice(0, 8);
    const pays = this.ref.rows('payments');
    this.payments = pays.length;
    this.collected30 = pays.filter((p: any) => (fmt.daysTo(p.paymentDate) ?? -999) >= -30).reduce((a: number, p: any) => a + Number(p.amount), 0);
    const last: Record<string, any> = {};
    for (const r of risks) last[r.distributorId] = r;
    this.high = Object.values(last).filter((r: any) => r.riskScore >= 70).length;
    this.limits = limits.length;
    const colors = ['var(--ok)', 'var(--chart-2)', 'var(--warn)', 'var(--danger)'];
    this.ageChart = donut({ items: AGE.map(([label, test], i) => ({ label, color: colors[i], value: inv.filter(x => x.outstanding > 0 && test(x.overdueDays, x)).reduce((a, x) => a + x.outstanding, 0) })), format: fmt.moneyShort, center: fmt.moneyShort(this.out), sub: 'outstanding' });
    const byDist: Record<string, number> = {};
    for (const i of inv) if (i.outstanding > 0) byDist[i.distributorName] = (byDist[i.distributorName] || 0) + i.outstanding;
    this.topChart = hbars(Object.entries(byDist).sort((a, b) => b[1] - a[1]).slice(0, 7).map(([label, value]) => ({ label, value })), { format: fmt.money });
    this.loaded = true;
  }
}
