/** The backend's error body as an Error: {status, error, code, message, path, fieldErrors}. Used by the mock and by live calls. */
export const STATUS_TEXT: Record<number, string> = { 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found", 409: "Conflict", 422: "Unprocessable Entity", 500: "Internal Server Error" };

export class ApiError extends Error {
  status: number; code: string; fieldErrors: Record<string, string> | null; path: string | undefined; body: any;
  constructor(status: any, code: any, message: any, fieldErrors?: any, path?: any) {
    super(message);
    this.status = status;
    this.code = code;
    this.fieldErrors = fieldErrors || null;
    this.path = path;
    this.body = { timestamp: new Date().toISOString(), status, error: STATUS_TEXT[status] || "Error", code, message, path, fieldErrors: fieldErrors || null };
  }
}
