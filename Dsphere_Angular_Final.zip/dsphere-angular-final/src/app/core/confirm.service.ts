/* Yes/no questions and "give a reason" prompts (replaces DS.ui.confirm and the browser's prompt()). */
import { Injectable, signal } from '@angular/core';

export interface ConfirmRequest {
  title: string; text?: string; okLabel?: string; tone?: 'primary' | 'danger';
  input?: { label: string; required?: boolean; placeholder?: string; max?: number };
  resolve: (v: any) => void;
}

@Injectable({ providedIn: 'root' })
export class ConfirmService {
  readonly current = signal<ConfirmRequest | null>(null);

  /** Resolves true/false, or the typed text (null when cancelled) when `input` is given. */
  ask(o: Omit<ConfirmRequest, 'resolve'>): Promise<any> {
    return new Promise(resolve => this.current.set({ ...o, resolve }));
  }
  close(value: any): void {
    const c = this.current();
    this.current.set(null);
    c?.resolve(value);
  }
}
