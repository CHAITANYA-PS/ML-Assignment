/* Route guards (replace the sign-in and role checks in shell.js boot()). */
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';

/** Must be signed in; reloads the profile and rules after a page refresh. */
export const authGuard: CanActivateFn = async () => {
  const api = inject(ApiService), auth = inject(AuthService), router = inject(Router);
  if (!api.hasSession()) return router.parseUrl('/login');
  if (!auth.me() || auth.me()!.userId !== api.sessionUserId()) {
    try { await auth.load(); } catch { api.logout(); return router.parseUrl('/login'); }
  }
  if (!auth.role()) { api.logout(); return router.parseUrl('/login?noRole=1'); }
  return true;
};

/** Keeps each user inside their own stakeholder's pages. */
export const roleGuard = (folder: string): CanActivateFn => () => {
  const auth = inject(AuthService), router = inject(Router);
  return auth.folder() === folder ? true : router.parseUrl(`/${auth.folder()}/dashboard`);
};

/** Hides a page the role's access rules do not allow (same check as the sidebar). */
export const canGuard = (method: string, path: string): CanActivateFn => () => {
  const auth = inject(AuthService), router = inject(Router);
  return auth.can(method, path) ? true : router.parseUrl(`/${auth.folder()}/dashboard`);
};
