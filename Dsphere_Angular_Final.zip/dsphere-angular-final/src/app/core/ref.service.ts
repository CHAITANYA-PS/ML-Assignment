/* Names for ids: loads reference lists once and turns distributorId 3 into "Vel Murugan Distributors" (replaces DS.ui.ref). */
import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
import { SCHEMA } from './schema';

const LABEL: Record<string, string> = {
  distributors: 'distributorName', products: 'productName', warehouses: 'warehouseName', 'app-users': 'userName', users: 'userName',
  regions: 'regionName', categories: 'categoryName', 'ticket-priorities': 'priorityName', 'ticket-categories': 'categoryName',
  'payment-methods': 'methodName', 'measurement-units': 'unitName', roles: 'roleName', manufacturers: 'manufacturerName',
  'product-batches': 'batchNumber', 'reporting-periods': 'periodName', departments: 'departmentName', 'notification-types': 'typeName',
  'movement-types': 'movementTypeName', 'return-categories': 'categoryName', 'vehicle-types': 'vehicleName', 'risk-levels': 'riskLevelName',
  'distributor-orders': 'orderNumber', orders: 'orderNumber', invoices: 'invoiceNumber', tickets: 'referenceNumber', shipments: 'trackingNumber',
  'health-parameters': 'parameterName', commitments: 'targetName', 'inventory-document-types': 'documentTypeName',
  'activity-types': 'activityTypeName', 'risk-bands': 'riskCategory', 'inventory-documents': 'documentNumber',
  'product-returns': 'returnNumber', 'exchange-requests': 'requestNumber'
};

@Injectable({ providedIn: 'root' })
export class RefService {
  private cache = new Map<string, any[]>();
  private pending = new Map<string, Promise<void>>();

  constructor(private api: ApiService, private auth: AuthService) {}

  /** Loads the lists once (a list the role may not read comes back empty instead of failing the page). */
  async ensure(resources: string[]): Promise<void> {
    await Promise.all(resources.map(res => {
      if (this.cache.has(res)) return Promise.resolve();
      if (!this.pending.has(res)) {
        this.pending.set(res, this.api.all('/' + res)
          .then(rows => { this.cache.set(res, rows); })
          .catch(() => { this.cache.set(res, []); })
          .finally(() => this.pending.delete(res)));
      }
      return this.pending.get(res)!;
    }));
  }
  rows(res: string): any[] { return this.cache.get(res) ?? []; }
  idField(res: string): string { return SCHEMA.resources[res]?.idField ?? 'id'; }
  get(res: string, id: any): any | null {
    if (id == null) return null;
    const f = this.idField(res);
    return this.rows(res).find(r => String(r[f]) === String(id)) ?? null;
  }
  labelField(res: string): string | null {
    if (LABEL[res]) return LABEL[res];
    if (/statuses$/.test(res)) return 'statusName';
    const f = SCHEMA.resources[res]?.fields.find(x => /Name$/.test(x.name));
    return f ? f.name : null;
  }
  name(res: string, id: any): string {
    if (id == null || id === '') return '–';
    const row = this.get(res, id);
    if (!row && (res === 'app-users' || res === 'users')) {
      const me = this.auth.me();
      return me && String(me.userId) === String(id) ? me.userName : `User #${id}`;
    }
    if (!row) return `#${id}`;
    if (res === 'health-parameter-weights') { const p = this.get('health-parameters', row.parameterId); return p ? p.parameterName : `#${id}`; }
    if (res === 'warehouse-stocks') { const b = this.get('product-batches', row.productBatchId); return b ? `${b.batchNumber} · qty ${row.quantity}` : `Stock #${id}`; }
    const f = this.labelField(res);
    return f && row[f] != null ? String(row[f]) : `#${id}`;
  }
  options(res: string): [any, string][] { const f = this.idField(res); return this.rows(res).map(r => [r[f], this.name(res, r[f])]); }
  invalidate(res?: string): void { if (res) this.cache.delete(res); else this.cache.clear(); }
}
