/** The backend's GET /dashboard/summary is a table of { metric, value } rows. This reads one value by its metric name. */
export function metric(t: any, name: string): any {
  return t?.rows?.find((r: any) => r.metric === name)?.value ?? null;
}
