/* Who is signed in, their stakeholder role and what the role may do (replaces the session part of shell.js). */
import { Injectable, computed, signal } from '@angular/core';
import { ApiService } from './api.service';

export const ROLE_FOLDER: Record<string, string> = {
  SYSTEM_ADMIN: 'admin', MANUFACTURER: 'manufacturer', DISTRIBUTOR: 'distributor',
  SALES_MANAGER: 'sales', FINANCE_MANAGER: 'finance', RECOVERY_MANAGER: 'recovery'
};
export const ROLE_NAME: Record<string, string> = {
  SYSTEM_ADMIN: 'System Admin', MANUFACTURER: 'Manufacturer', DISTRIBUTOR: 'Distributor',
  SALES_MANAGER: 'Sales Manager', FINANCE_MANAGER: 'Finance Manager', RECOVERY_MANAGER: 'Recovery Manager'
};

export interface Me {
  userId: number; email: string; userName: string; status: string; roles: string[];
  distributorId: number | null; manufacturerId: number | null;
}
export interface PermissionRule { roleCode: string; resource: string; canRead: boolean; canWrite: boolean; }
export interface MyPermissions { roles: string[]; allowsEverything: boolean; permissions: PermissionRule[]; }

@Injectable({ providedIn: 'root' })
export class AuthService {
  readonly me = signal<Me | null>(null);
  readonly mine = signal<MyPermissions | null>(null);
  readonly role = computed(() => this.me()?.roles?.[0] ?? '');
  readonly folder = computed(() => ROLE_FOLDER[this.role()] ?? '');
  readonly roleName = computed(() => ROLE_NAME[this.role()] ?? '');

  constructor(private api: ApiService) {}

  async login(email: string, password: string): Promise<Me> {
    await this.api.login(email, password);
    await this.load();
    return this.me()!;
  }
  /** Loads GET /auth/me and GET /role-permissions/mine (called after sign-in and on page refresh). */
  async load(): Promise<void> {
    const [me, mine] = await Promise.all([
      this.api.get<Me>('/auth/me'),
      this.api.get<MyPermissions>('/role-permissions/mine').catch(() => ({ roles: [], allowsEverything: false, permissions: [] }))
    ]);
    this.me.set(me);
    this.mine.set(mine);
  }
  async logout(): Promise<void> {
    await this.api.post('/auth/logout').catch(() => null);
    this.api.logout();
    this.me.set(null);
    this.mine.set(null);
  }

  /** The backend's AccessPolicy rule: the most specific matching resource decides; System Admin is always allowed. */
  can(method: string, path: string): boolean {
    const mine = this.mine();
    if (!mine) return false;
    if (mine.allowsEverything) return true;
    const p = this.api.normalise(path);
    if (p === 'auth' || p.startsWith('auth/')) return true;
    const spec = (r: string) => [r.split('/').length, r.split('/').filter(x => x !== '*').length];
    const rules = [...mine.permissions].sort((a, b) => { const x = spec(a.resource), y = spec(b.resource); return y[0] - x[0] || y[1] - x[1]; });
    const parts = p.split('/');
    const hit = rules.find(r => { const a = r.resource.split('/'); return parts.length >= a.length && a.every((seg, i) => seg === '*' || seg === parts[i]); });
    const read = ['GET', 'HEAD'].includes(method.toUpperCase());
    return !!hit && (read ? hit.canRead : hit.canWrite);
  }
}
