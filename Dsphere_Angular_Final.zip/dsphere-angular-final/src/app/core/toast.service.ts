/* Small messages in the corner (replaces DS.ui.toast). */
import { Injectable, signal } from '@angular/core';

export interface Toast { id: number; text: string; detail?: string; kind: 'ok' | 'error' | 'info'; leaving?: boolean; }

/** Matches technical detail lines: "GET|POST|PUT|PATCH|DELETE /path…" or "400 SOME_CODE". */
const TECHNICAL = /^((GET|POST|PUT|PATCH|DELETE)\s+\/|\d{3}\s+[A-Z_]+$|[A-Z]+(_[A-Z]+)+$)/;

/** One readable sentence for an error from the backend or the demo backend, without status codes. */
export function friendlyError(e: any): string {
  const fe: Record<string, string> = e?.fieldErrors || {};
  const list = Object.entries(fe).filter(([, m]) => !!m).map(([k, m]) => (/^(is|must|has|does|already|should|cannot)\b/.test(String(m)) ? `${label(k)} ${m}` : String(m)));
  const msg = String(e?.message || '').trim();
  if (list.length && (!msg || /^validation failed$/i.test(msg))) return 'Please check: ' + list.join('; ') + '.';
  if (msg && !/^Http failure/i.test(msg)) return msg;
  return byStatus(e?.status);
}
function label(key: string): string {
  return String(key).replace(/\[\d+\]/g, '').replace(/\./g, ' ').replace(/Id$/, '').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^./, c => c.toUpperCase());
}
export function byStatus(status: number): string {
  switch (status) {
    case 0: return 'Cannot reach the server. Check that the backend is running and try again.';
    case 400: return 'Some of the information is missing or not valid. Please check the form.';
    case 401: return 'Your email or password is wrong, or your session has ended. Please sign in again.';
    case 403: return 'Your role is not allowed to do this.';
    case 404: return 'This record was not found. It may have been removed.';
    case 409: return 'This already exists, or it is still used by other records.';
    case 422: return 'This action is not allowed for the record in its current state.';
    default: return 'Something went wrong on the server. Please try again.';
  }
}

@Injectable({ providedIn: 'root' })
export class ToastService {
  readonly list = signal<Toast[]>([]);
  private seq = 0;

  show(text: string, kind: Toast['kind'] = 'ok', detail?: string): void {
    // Technical details (API paths such as "PUT /products/2", status codes such as "422 BUSINESS_RULE_VIOLATION") are not shown to users.
    if (detail && TECHNICAL.test(detail.trim())) detail = undefined;
    const id = ++this.seq;
    this.list.update(l => [...l, { id, text, kind, detail }]);
    setTimeout(() => this.list.update(l => l.filter(t => t.id !== id)), kind === 'error' ? 5200 : 3200);
  }
  info(text: string, detail?: string): void { this.show(text, 'info', detail); }
  /** Shows an error in plain words (no status codes). */
  error(e: any): void {
    this.show(friendlyError(e), 'error');
  }
}
