/*
 * The one door to the backend (replaces DS.api).
 * Every page calls get/page/all/post/put/del with the backend path, e.g. this.api.page('/tickets', { page: 0, size: 10 }).
 * environment.apiMode = 'mock' -> MockApiService answers in the browser.
 * environment.apiMode = 'live' -> HttpClient calls Spring Boot with HTTP Basic (tomorrow: change only that setting).
 */
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../environments/environment';
import { friendlyError } from './toast.service';
import { ApiError } from './api-error';
import { MockApiService, SESSION_KEY } from '../mock/mock-api.service';

export interface Page<T> { rows: T[]; total: number; }
export interface Query { [key: string]: string | number | boolean | null | undefined; }
export interface DownloadFile { name: string; blob: Blob; }

interface Session { userId: number; basic: string | null; }

@Injectable({ providedIn: 'root' })
export class ApiService {
  constructor(private http: HttpClient, private mock: MockApiService) {}

  get live(): boolean { return environment.apiMode === 'live'; }

  get<T = any>(path: string, query?: Query): Promise<T> { return this.request('GET', path, query).then(r => r.data as T); }
  /**
   * Every row of a list. The backend allows at most 100 rows per page (AbstractCrudService.MAX_PAGE_SIZE),
   * so this reads page after page until X-Total-Count is reached. Pass page/size yourself to get just one page.
   */
  async all<T = any>(path: string, query?: Query): Promise<T[]> {
    if (query && (query['page'] != null || query['size'] != null)) return (await this.request('GET', path, query)).data || [];
    const out: T[] = [];
    for (let page = 0; page < 200; page++) {
      const r = await this.request('GET', path, { ...(query || {}), page, size: ApiService.PAGE_MAX });
      const rows: T[] = Array.isArray(r.data) ? r.data : [];
      out.push(...rows);
      const total = r.total != null ? Number(r.total) : null;
      if (rows.length < ApiService.PAGE_MAX || (total != null && out.length >= total)) break;
    }
    return out;
  }
  static readonly PAGE_MAX = 100;
  page<T = any>(path: string, query?: Query): Promise<Page<T>> {
    return this.request('GET', path, query).then(r => ({ rows: (r.data || []) as T[], total: Number(r.total ?? (r.data || []).length) }));
  }
  post<T = any>(path: string, body?: any, query?: Query): Promise<T> { return this.request('POST', path, query, body ?? {}).then(r => r.data as T); }
  put<T = any>(path: string, body?: any): Promise<T> { return this.request('PUT', path, undefined, body ?? {}).then(r => r.data as T); }
  del(path: string): Promise<void> { return this.request('DELETE', path).then(() => undefined); }

  /** Exports and attachment downloads: the backend sends a file, the mock sends text. */
  async download(path: string, query?: Query): Promise<DownloadFile> {
    if (!this.live) {
      const data = await this.get<any>(path, query);
      return { name: data.file.name, blob: new Blob([data.file.text], { type: data.file.type || 'text/plain' }) };
    }
    const res: any = await firstValueFrom(this.http.request('GET', this.url(path), {
      params: this.params(query), headers: this.headers(), observe: 'response', responseType: 'blob'
    })).catch(e => { throw this.toApiError(e, path); });
    const cd: string = res.headers.get('Content-Disposition') || '';
    const name = (cd.split('filename=')[1] || 'download').replace(/"/g, '');
    return { name, blob: res.body as Blob };
  }

  /**
   * File upload (ticket evidence). Live: multipart/form-data with the field "file", as the backend expects.
   * Mock: only the file's name, type and size are kept.
   */
  async upload<T = any>(path: string, file: File): Promise<T> {
    if (!this.live) return this.post<T>(path, { fileName: file.name, contentType: file.type || 'application/octet-stream', sizeBytes: file.size });
    const form = new FormData();
    form.append('file', file, file.name);
    try {
      const res: any = await firstValueFrom(this.http.request('POST', this.url(path), { body: form, headers: this.headers(), observe: 'response' }));
      return res.body as T;
    } catch (e) {
      throw this.toApiError(e, path);
    }
  }

  async login(email: string, password: string): Promise<any> {
    const basic = btoa(`${email}:${password}`);
    let me: any;
    if (this.live) {
      me = await firstValueFrom(this.http.request('POST', this.url('/auth/login'), { headers: new HttpHeaders({ Authorization: 'Basic ' + basic }), body: {} }))
        .catch(e => { throw this.toApiError(e, '/auth/login'); });
    } else {
      me = (await this.mock.login(email, password)).data;
    }
    const s: Session = { userId: me.userId, basic: this.live ? basic : null };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(s));
    return me;
  }
  logout(): void { sessionStorage.removeItem(SESSION_KEY); }
  hasSession(): boolean { return !!this.session(); }
  sessionUserId(): number | null { return this.session()?.userId ?? null; }
  resetDemo(): void { this.mock.resetDemo(); }
  normalise(path: string): string { return this.mock.normalise(path); }

  // ------------------------------------------------------------------ internals
  private session(): Session | null {
    try { return JSON.parse(sessionStorage.getItem(SESSION_KEY) || 'null'); } catch { return null; }
  }
  private url(path: string): string { return environment.apiBaseUrl + environment.apiPrefix + '/' + this.normalisePath(path); }
  private normalisePath(path: string): string { return String(path).replace(/^\/?api\/v1\//, '').replace(/^\/+/, ''); }
  private params(query?: Query): HttpParams {
    let p = new HttpParams();
    Object.entries(query || {}).forEach(([k, v]) => { if (v !== '' && v != null) p = p.set(k, String(v)); });
    return p;
  }
  private headers(): HttpHeaders {
    const s = this.session();
    return new HttpHeaders(s?.basic ? { Authorization: 'Basic ' + s.basic, Accept: 'application/json' } : { Accept: 'application/json' });
  }
  private toApiError(e: any, path: string): ApiError {
    if (e instanceof ApiError) return e;
    const err = e instanceof HttpErrorResponse ? e : e;
    const b = err?.error && typeof err.error === 'object' ? err.error : {};
    const status = err?.status || 0;
    const e2 = new ApiError(status, b.code || (status ? 'HTTP_' + status : 'NETWORK_ERROR'), b.message || '', b.fieldErrors, path);
    e2.message = friendlyError(e2);
    return e2;
  }
  private async request(method: string, path: string, query?: Query, body?: any): Promise<{ data: any; total: string | null }> {
    if (!this.live) {
      let r: any;
      try { r = await this.mock.request(method, path, { query: query || {}, body }); } catch (e: any) {
        if (e instanceof ApiError) e.message = friendlyError(e);
        throw e;
      }
      return { data: r.data, total: r.headers['X-Total-Count'] ?? null };
    }
    try {
      const res: any = await firstValueFrom(this.http.request(method, this.url(path), {
        params: this.params(query), headers: this.headers(), body, observe: 'response'
      }));
      return { data: res.body, total: res.headers.get('X-Total-Count') };
    } catch (e) {
      throw this.toApiError(e, path);
    }
  }
}
