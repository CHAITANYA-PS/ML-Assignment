/**
 * Dsphere settings (replaces config.js).
 *   apiMode     'mock' = the demo backend in src/app/mock answers every call (no Spring Boot needed).
 *               'live' = the same calls go to Spring Boot through HttpClient (tomorrow's integration).
 *   apiBaseUrl  '' = same origin; with proxy.conf.json the dev server forwards /api to http://localhost:8081.
 */
export const environment = {
  production: false,
  apiMode: 'mock' as 'mock' | 'live',
  apiBaseUrl: '',
  apiPrefix: '/api/v1',
  pageSize: 10,
  currency: 'INR',
  locale: 'en-IN',
  appName: 'Dsphere',
  appTagline: 'Distributor Operations Management Platform',
  mockLatency: [120, 320] as [number, number]
};
