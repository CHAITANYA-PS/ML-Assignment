package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.MovementType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovementTypeRepository extends JpaRepository<MovementType, Long> {
}
