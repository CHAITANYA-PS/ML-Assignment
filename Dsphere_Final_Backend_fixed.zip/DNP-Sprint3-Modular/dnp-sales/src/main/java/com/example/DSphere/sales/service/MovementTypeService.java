package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.MovementType;
import com.example.DSphere.sales.repository.MovementTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class MovementTypeService extends AbstractCrudService<MovementType, Long> {
    public MovementTypeService(MovementTypeRepository repository) {
        super(repository, MovementType.class);
    }
}
