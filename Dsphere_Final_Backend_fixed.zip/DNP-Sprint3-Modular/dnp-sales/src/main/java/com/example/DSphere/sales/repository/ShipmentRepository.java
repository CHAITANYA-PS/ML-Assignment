package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.Shipment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShipmentRepository extends JpaRepository<Shipment, Long> {
}
