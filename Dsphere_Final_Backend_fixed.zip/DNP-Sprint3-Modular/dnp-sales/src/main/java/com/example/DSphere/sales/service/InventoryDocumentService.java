package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.InventoryDocument;
import com.example.DSphere.sales.repository.InventoryDocumentRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryDocumentService extends AbstractCrudService<InventoryDocument, Long> {
    public InventoryDocumentService(InventoryDocumentRepository repository) {
        super(repository, InventoryDocument.class);
    }
}
