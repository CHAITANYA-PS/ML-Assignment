package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.StockWriteOff;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StockWriteOffRepository extends JpaRepository<StockWriteOff, Long> {
}
