package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.OrderStatus;
import com.example.DSphere.sales.repository.OrderStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderStatusService extends AbstractCrudService<OrderStatus, Long> {
    public OrderStatusService(OrderStatusRepository repository) {
        super(repository, OrderStatus.class);
    }
}
