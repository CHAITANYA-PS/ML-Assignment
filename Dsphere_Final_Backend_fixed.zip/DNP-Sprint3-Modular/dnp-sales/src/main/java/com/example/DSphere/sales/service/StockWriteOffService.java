package com.example.DSphere.sales.service;

import com.example.DSphere.manufacturer.repository.ProductBatchRepository;
import com.example.DSphere.manufacturer.repository.ProductRepository;
import com.example.DSphere.sales.entity.StockWriteOff;
import com.example.DSphere.sales.entity.WarehouseStock;
import com.example.DSphere.sales.repository.StockWriteOffRepository;
import com.example.DSphere.systemadmin.security.CurrentUser;
import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.systemadmin.service.BusinessRuleException;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Write-off of stock that can be neither sold nor returned. The quantity leaves the stock through the ledger
 * and the value (quantity x product unit cost) is recorded. A write-off cannot be changed or deleted.
 */
@Service
public class StockWriteOffService extends AbstractCrudService<StockWriteOff, Long> {
    private final StockLedgerService ledger;
    private final ProductBatchRepository batches;
    private final ProductRepository products;

    public StockWriteOffService(StockWriteOffRepository repository, StockLedgerService ledger, ProductBatchRepository batches,
            ProductRepository products) {
        super(repository, StockWriteOff.class);
        this.ledger = ledger;
        this.batches = batches;
        this.products = products;
    }

    @Override
    protected void beforeCreate(StockWriteOff w) {
        WarehouseStock stock = ledger.lock(w.getWarehouseStockId());
        ledger.post(stock.getWarehouseStockId(), StockLedgerService.OUT, w.getQuantity(), "Write-off", "WOF");
        BigDecimal unitCost = batches.findById(stock.getProductBatchId())
                .flatMap(b -> products.findById(b.getProductId()))
                .map(p -> p.getUnitCost()).orElse(null);
        w.setWriteOffValue(unitCost == null ? null : unitCost.multiply(w.getQuantity()));
        w.setWrittenOffBy(CurrentUser.id());
        w.setWrittenOffAt(OffsetDateTime.now());
    }

    @Override
    protected void beforeUpdate(Long id, StockWriteOff w, StockWriteOff existing) {
        throw new BusinessRuleException("A write-off cannot be changed");
    }

    @Override
    protected void beforeDelete(StockWriteOff existing) {
        throw new BusinessRuleException("A write-off cannot be deleted");
    }
}
