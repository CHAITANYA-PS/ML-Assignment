package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.OrderStatusHistory;
import com.example.DSphere.sales.repository.OrderStatusHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderStatusHistoryService extends AbstractCrudService<OrderStatusHistory, Long> {
    public OrderStatusHistoryService(OrderStatusHistoryRepository repository) {
        super(repository, OrderStatusHistory.class);
    }
}
