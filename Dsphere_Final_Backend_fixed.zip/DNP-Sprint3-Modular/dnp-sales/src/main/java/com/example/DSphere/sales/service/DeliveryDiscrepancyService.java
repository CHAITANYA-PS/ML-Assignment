package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.sales.entity.DeliveryDiscrepancy;
import com.example.DSphere.sales.repository.DeliveryDiscrepancyRepository;
import org.springframework.stereotype.Service;

@Service
public class DeliveryDiscrepancyService extends AbstractCrudService<DeliveryDiscrepancy, Long> {
    public DeliveryDiscrepancyService(DeliveryDiscrepancyRepository repository) {
        super(repository, DeliveryDiscrepancy.class);
    }
}
