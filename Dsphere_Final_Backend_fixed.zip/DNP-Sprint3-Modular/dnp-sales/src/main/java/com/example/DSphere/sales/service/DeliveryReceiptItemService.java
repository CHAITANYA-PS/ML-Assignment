package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.sales.entity.DeliveryReceiptItem;
import com.example.DSphere.sales.repository.DeliveryReceiptItemRepository;
import org.springframework.stereotype.Service;

@Service
public class DeliveryReceiptItemService extends AbstractCrudService<DeliveryReceiptItem, Long> {
    public DeliveryReceiptItemService(DeliveryReceiptItemRepository repository) {
        super(repository, DeliveryReceiptItem.class);
    }
}
