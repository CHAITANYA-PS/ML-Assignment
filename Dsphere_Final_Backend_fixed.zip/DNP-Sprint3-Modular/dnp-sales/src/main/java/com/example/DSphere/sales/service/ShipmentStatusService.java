package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.ShipmentStatus;
import com.example.DSphere.sales.repository.ShipmentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentStatusService extends AbstractCrudService<ShipmentStatus, Long> {
    public ShipmentStatusService(ShipmentStatusRepository repository) {
        super(repository, ShipmentStatus.class);
    }
}
