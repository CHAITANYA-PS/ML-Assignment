package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.SalesTarget;
import com.example.DSphere.sales.repository.SalesTargetRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesTargetService extends AbstractCrudService<SalesTarget, Long> {
    public SalesTargetService(SalesTargetRepository repository) {
        super(repository, SalesTarget.class);
    }
}
