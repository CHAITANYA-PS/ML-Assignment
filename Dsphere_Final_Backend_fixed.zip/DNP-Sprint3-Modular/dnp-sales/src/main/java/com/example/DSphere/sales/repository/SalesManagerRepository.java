package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.SalesManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesManagerRepository extends JpaRepository<SalesManager, Long> {
}
