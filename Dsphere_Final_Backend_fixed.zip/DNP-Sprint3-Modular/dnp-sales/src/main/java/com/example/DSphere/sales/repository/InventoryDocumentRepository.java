package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.InventoryDocument;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryDocumentRepository extends JpaRepository<InventoryDocument, Long> {
}
