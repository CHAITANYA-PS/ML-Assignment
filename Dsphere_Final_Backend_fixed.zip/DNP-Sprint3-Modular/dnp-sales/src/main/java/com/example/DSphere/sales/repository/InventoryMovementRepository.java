package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.InventoryMovement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface InventoryMovementRepository extends JpaRepository<InventoryMovement, Long> {
    List<InventoryMovement> findByWarehouseStockId(Long warehouseStockId);
}
