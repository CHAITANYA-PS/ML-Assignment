package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.sales.entity.DeliveryReceipt;
import com.example.DSphere.sales.repository.DeliveryReceiptRepository;
import org.springframework.stereotype.Service;

@Service
public class DeliveryReceiptService extends AbstractCrudService<DeliveryReceipt, Long> {
    public DeliveryReceiptService(DeliveryReceiptRepository repository) {
        super(repository, DeliveryReceipt.class);
    }
}
