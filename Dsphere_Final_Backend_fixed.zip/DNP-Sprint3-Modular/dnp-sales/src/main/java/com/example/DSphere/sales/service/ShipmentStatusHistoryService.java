package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.sales.entity.ShipmentStatusHistory;
import com.example.DSphere.sales.repository.ShipmentStatusHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentStatusHistoryService extends AbstractCrudService<ShipmentStatusHistory, Long> {
    public ShipmentStatusHistoryService(ShipmentStatusHistoryRepository repository) {
        super(repository, ShipmentStatusHistory.class);
    }
}
