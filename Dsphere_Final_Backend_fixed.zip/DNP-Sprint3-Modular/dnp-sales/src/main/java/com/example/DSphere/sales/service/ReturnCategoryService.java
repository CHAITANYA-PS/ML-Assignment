package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.sales.entity.ReturnCategory;
import com.example.DSphere.sales.repository.ReturnCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class ReturnCategoryService extends AbstractCrudService<ReturnCategory, Long> {
    public ReturnCategoryService(ReturnCategoryRepository repository) {
        super(repository, ReturnCategory.class);
    }
}
