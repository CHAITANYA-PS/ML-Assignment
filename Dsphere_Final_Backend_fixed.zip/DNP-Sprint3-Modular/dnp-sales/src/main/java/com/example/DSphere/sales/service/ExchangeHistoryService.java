package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.ExchangeHistory;
import com.example.DSphere.sales.repository.ExchangeHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class ExchangeHistoryService extends AbstractCrudService<ExchangeHistory, Long> {
    public ExchangeHistoryService(ExchangeHistoryRepository repository) {
        super(repository, ExchangeHistory.class);
    }
}
