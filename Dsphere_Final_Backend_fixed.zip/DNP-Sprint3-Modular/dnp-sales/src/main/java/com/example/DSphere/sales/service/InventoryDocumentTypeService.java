package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.InventoryDocumentType;
import com.example.DSphere.sales.repository.InventoryDocumentTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryDocumentTypeService extends AbstractCrudService<InventoryDocumentType, Long> {
    public InventoryDocumentTypeService(InventoryDocumentTypeRepository repository) {
        super(repository, InventoryDocumentType.class);
    }
}
