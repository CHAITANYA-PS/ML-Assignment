package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.Shipment;
import com.example.DSphere.sales.repository.ShipmentRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentService extends AbstractCrudService<Shipment, Long> {
    public ShipmentService(ShipmentRepository repository) {
        super(repository, Shipment.class);
    }
}
