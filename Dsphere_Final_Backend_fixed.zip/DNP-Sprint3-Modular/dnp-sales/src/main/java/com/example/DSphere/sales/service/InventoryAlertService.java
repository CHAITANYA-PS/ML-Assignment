package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.InventoryAlert;
import com.example.DSphere.sales.repository.InventoryAlertRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryAlertService extends AbstractCrudService<InventoryAlert, Long> {
    public InventoryAlertService(InventoryAlertRepository repository) {
        super(repository, InventoryAlert.class);
    }
}
