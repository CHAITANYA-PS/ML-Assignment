package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.ShipmentItem;
import com.example.DSphere.sales.repository.ShipmentItemRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentItemService extends AbstractCrudService<ShipmentItem, Long> {
    public ShipmentItemService(ShipmentItemRepository repository) {
        super(repository, ShipmentItem.class);
    }
}
