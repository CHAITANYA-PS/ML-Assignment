package com.example.DSphere.sales.service;

import com.example.DSphere.distributor.entity.DistributorOrder;
import com.example.DSphere.distributor.repository.DistributorOrderRepository;
import com.example.DSphere.sales.entity.OrderStatus;
import com.example.DSphere.sales.entity.OrderStatusHistory;
import com.example.DSphere.sales.repository.OrderStatusHistoryRepository;
import com.example.DSphere.systemadmin.security.CurrentUser;
import com.example.DSphere.systemadmin.security.Roles;
import com.example.DSphere.systemadmin.security.UserRoleResolver;
import com.example.DSphere.systemadmin.service.AuditTrail;
import com.example.DSphere.systemadmin.service.BusinessRuleException;
import com.example.DSphere.systemadmin.service.ForbiddenOperationException;
import com.example.DSphere.systemadmin.service.LookupSupport;
import com.example.DSphere.systemadmin.service.NotificationGateway;
import com.example.DSphere.systemadmin.service.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Order status flow. A status can only move forward (higher sequence number); a terminal status (Delivered,
 * Cancelled ...) never changes. An order can be cancelled until it is shipped. Every change is kept in
 * order_status_history and the distributor is notified.
 */
@Service
@Transactional
public class OrderWorkflowService {
    public static final String CANCELLED = "Cancelled";
    private static final Set<String> NOT_CANCELLABLE = Set.of("shipped", "dispatched", "intransit", "delivered", "completed", "closed");

    private final DistributorOrderRepository orders;
    private final OrderStatusHistoryRepository history;
    private final SalesStatuses statuses;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;

    public OrderWorkflowService(DistributorOrderRepository orders, OrderStatusHistoryRepository history, SalesStatuses statuses,
            NotificationGateway notifications, UserRoleResolver users) {
        this.orders = orders;
        this.history = history;
        this.statuses = statuses;
        this.notifications = notifications;
        this.users = users;
    }

    public DistributorOrder changeStatus(Long orderId, String statusName, String remarks) {
        if (LookupSupport.same(statusName, CANCELLED)) {
            return cancel(orderId, remarks == null ? "Cancelled" : remarks);
        }
        DistributorOrder order = load(orderId);
        OrderStatus current = current(order);
        OrderStatus target = statuses.orderStatuses().findAll().stream()
                .filter(s -> LookupSupport.same(s.getStatusName(), statusName)).findFirst()
                .orElseThrow(() -> new BusinessRuleException("Unknown order status '" + statusName + "'. Known: "
                        + statuses.orderStatuses().findAll().stream().map(OrderStatus::getStatusName).toList()));
        if (current != null) {
            if (Boolean.TRUE.equals(current.getIsTerminal())) {
                throw new BusinessRuleException("Order is " + current.getStatusName() + "; its status cannot change any more");
            }
            int from = current.getSequenceNumber() == null ? 0 : current.getSequenceNumber();
            int to = target.getSequenceNumber() == null ? 0 : target.getSequenceNumber();
            if (to <= from) {
                throw new BusinessRuleException("Order status can only move forward: " + current.getStatusName() + " (" + from + ") -> "
                        + target.getStatusName() + " (" + to + ") is not allowed");
            }
        }
        return apply(order, current, target, remarks);
    }

    public DistributorOrder cancel(Long orderId, String reason) {
        DistributorOrder order = load(orderId);
        OrderStatus current = current(order);
        if (current != null) {
            if (Boolean.TRUE.equals(current.getIsTerminal())) {
                throw new BusinessRuleException("Order is already " + current.getStatusName());
            }
            String n = current.getStatusName() == null ? "" : current.getStatusName().replaceAll("[\\s_-]", "").toLowerCase();
            if (NOT_CANCELLABLE.contains(n)) {
                throw new BusinessRuleException("Order is " + current.getStatusName() + " and can no longer be cancelled; raise a return instead");
            }
        }
        return apply(order, current, statuses.order(CANCELLED, 99, true), "Cancelled: " + reason);
    }

    @Transactional(readOnly = true)
    public List<OrderStatusHistory> history(Long orderId) {
        load(orderId);
        return history.findByOrderIdOrderByChangedAtAsc(orderId);
    }

    private DistributorOrder apply(DistributorOrder order, OrderStatus current, OrderStatus target, String remarks) {
        order.setOrderStatusId(target.getOrderStatusId());
        order.setUpdatedAt(OffsetDateTime.now());
        DistributorOrder saved = orders.save(order);
        OrderStatusHistory h = new OrderStatusHistory();
        h.setOrderId(order.getOrderId());
        h.setOrderStatusId(target.getOrderStatusId());
        h.setChangedBy(CurrentUser.id());
        h.setRemarks(remarks != null && remarks.length() > 500 ? remarks.substring(0, 500) : remarks);
        h.setChangedAt(OffsetDateTime.now());
        history.save(h);
        AuditTrail.record("STATUS_CHANGE", "DistributorOrder", order.getOrderId(), current == null ? null : current.getStatusName(),
                target.getStatusName());
        notifications.notify(users.usersOfDistributor(order.getDistributorId()), "Order status",
                "Order " + order.getOrderNumber() + " is now " + target.getStatusName() + (remarks == null ? "" : " (" + remarks + ")"));
        // Finance follows approved orders (credit exposure) and delivered orders (to invoice).
        if (LookupSupport.same(target.getStatusName(), "Approved")) {
            notifications.notify(users.usersWithRole(Roles.FINANCE_MANAGER), "Order status",
                    "Order " + order.getOrderNumber() + " was approved. Check the distributor's credit limit and credit risk.");
        } else if (LookupSupport.same(target.getStatusName(), "Delivered")) {
            notifications.notify(users.usersWithRole(Roles.FINANCE_MANAGER), "Order status",
                    "Order " + order.getOrderNumber() + " was delivered and is ready to invoice.");
        }
        return saved;
    }

    private OrderStatus current(DistributorOrder order) {
        return order.getOrderStatusId() == null ? null : statuses.orderStatuses().findById(order.getOrderStatusId()).orElse(null);
    }

    private DistributorOrder load(Long id) {
        DistributorOrder o = orders.findById(id).orElseThrow(() -> new ResourceNotFoundException("Order not found: " + id));
        if (CurrentUser.isDistributorOnly() && !Objects.equals(CurrentUser.distributorId(), o.getDistributorId())) {
            throw new ForbiddenOperationException("This order belongs to another distributor");
        }
        return o;
    }
}
