package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.InventoryDocumentType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryDocumentTypeRepository extends JpaRepository<InventoryDocumentType, Long> {
}
