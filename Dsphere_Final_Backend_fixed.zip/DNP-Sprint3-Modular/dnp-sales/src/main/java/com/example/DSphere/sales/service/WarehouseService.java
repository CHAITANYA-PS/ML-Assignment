package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.Warehouse;
import com.example.DSphere.sales.repository.WarehouseRepository;
import org.springframework.stereotype.Service;

@Service
public class WarehouseService extends AbstractCrudService<Warehouse, Long> {
    public WarehouseService(WarehouseRepository repository) {
        super(repository, Warehouse.class);
    }
}
