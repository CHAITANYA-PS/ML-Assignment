package com.example.DSphere.sales.service;

import com.example.DSphere.sales.entity.InventoryMovement;
import com.example.DSphere.sales.repository.InventoryMovementRepository;
import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.systemadmin.service.BusinessRuleException;
import org.springframework.stereotype.Service;

/**
 * Stock movements. Creating a movement changes the stock quantity (IN adds, OUT subtracts, never below zero).
 * Movements are the ledger, so they cannot be edited or deleted: post a correcting movement instead.
 */
@Service
public class InventoryMovementService extends AbstractCrudService<InventoryMovement, Long> {
    private final StockLedgerService ledger;

    public InventoryMovementService(InventoryMovementRepository repository, StockLedgerService ledger) {
        super(repository, InventoryMovement.class);
        this.ledger = ledger;
    }

    @Override
    protected void beforeCreate(InventoryMovement m) {
        ledger.applyUserMovement(m);
    }

    @Override
    protected void beforeUpdate(Long id, InventoryMovement m, InventoryMovement existing) {
        throw new BusinessRuleException("Stock movements cannot be changed; post a correcting movement instead");
    }

    @Override
    protected void beforeDelete(InventoryMovement existing) {
        throw new BusinessRuleException("Stock movements cannot be deleted; post a correcting movement instead");
    }
}
