package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.ReturnCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReturnCategoryRepository extends JpaRepository<ReturnCategory, Long> {
}
