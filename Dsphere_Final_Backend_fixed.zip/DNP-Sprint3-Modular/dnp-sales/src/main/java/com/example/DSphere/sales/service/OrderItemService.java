package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.OrderItem;
import com.example.DSphere.sales.repository.OrderItemRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderItemService extends AbstractCrudService<OrderItem, Long> {
    public OrderItemService(OrderItemRepository repository) {
        super(repository, OrderItem.class);
    }
}
