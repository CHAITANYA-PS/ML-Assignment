package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WarehouseRepository extends JpaRepository<Warehouse, Long> {
}
