package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.sales.entity.ProductVerification;
import com.example.DSphere.sales.repository.ProductVerificationRepository;
import org.springframework.stereotype.Service;

@Service
public class ProductVerificationService extends AbstractCrudService<ProductVerification, Long> {
    public ProductVerificationService(ProductVerificationRepository repository) {
        super(repository, ProductVerification.class);
    }
}
