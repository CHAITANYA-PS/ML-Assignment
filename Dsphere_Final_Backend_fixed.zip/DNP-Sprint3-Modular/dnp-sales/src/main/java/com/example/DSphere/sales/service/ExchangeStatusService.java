package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.ExchangeStatus;
import com.example.DSphere.sales.repository.ExchangeStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class ExchangeStatusService extends AbstractCrudService<ExchangeStatus, Long> {
    public ExchangeStatusService(ExchangeStatusRepository repository) {
        super(repository, ExchangeStatus.class);
    }
}
