package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.NotificationType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificationTypeRepository extends JpaRepository<NotificationType, Long> {
}
