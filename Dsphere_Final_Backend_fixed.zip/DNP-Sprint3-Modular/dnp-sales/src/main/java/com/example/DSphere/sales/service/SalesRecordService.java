package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.SalesRecord;
import com.example.DSphere.sales.repository.SalesRecordRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesRecordService extends AbstractCrudService<SalesRecord, Long> {
    public SalesRecordService(SalesRecordRepository repository) {
        super(repository, SalesRecord.class);
    }
}
