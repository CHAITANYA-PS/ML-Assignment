package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.ProductReturn;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface ProductReturnRepository extends JpaRepository<ProductReturn, Long> {
    boolean existsByWarehouseStockIdAndStatusIn(Long warehouseStockId, java.util.Collection<String> statuses);
}
