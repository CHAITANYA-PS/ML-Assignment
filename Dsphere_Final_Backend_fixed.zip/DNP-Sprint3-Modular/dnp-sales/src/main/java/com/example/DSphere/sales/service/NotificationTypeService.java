package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.NotificationType;
import com.example.DSphere.sales.repository.NotificationTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class NotificationTypeService extends AbstractCrudService<NotificationType, Long> {
    public NotificationTypeService(NotificationTypeRepository repository) {
        super(repository, NotificationType.class);
    }
}
