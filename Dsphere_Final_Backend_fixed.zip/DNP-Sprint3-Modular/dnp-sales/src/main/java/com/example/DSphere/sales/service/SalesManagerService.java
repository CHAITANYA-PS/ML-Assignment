package com.example.DSphere.sales.service;

import com.example.DSphere.systemadmin.security.Roles;
import com.example.DSphere.systemadmin.service.StakeholderRoleService;
import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.sales.entity.SalesManager;
import com.example.DSphere.sales.repository.SalesManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesManagerService extends AbstractCrudService<SalesManager, Long> {
    private final StakeholderRoleService stakeholders;

    public SalesManagerService(SalesManagerRepository repository, StakeholderRoleService stakeholders) {
        super(repository, SalesManager.class);
        this.stakeholders = stakeholders;
    }

    /** A SalesManager row gives the user the SALES_MANAGER role (one user = one stakeholder). */
    @Override
    protected void afterCreate(SalesManager saved) {
        stakeholders.assign(saved.getUserId(), Roles.SALES_MANAGER);
    }

    @Override
    protected void beforeDelete(SalesManager existing) {
        stakeholders.unassign(existing.getUserId(), Roles.SALES_MANAGER);
    }

    /** The id is the user_id of an existing user (one-to-one sub-type of app_user), so the client supplies it. */
    @Override
    protected boolean idAssignedByClient() {
        return true;
    }
}
