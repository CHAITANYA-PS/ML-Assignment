package com.example.DSphere.sales.service;

import com.example.DSphere.distributor.repository.DistributorOrderRepository;
import com.example.DSphere.manufacturer.entity.Product;
import com.example.DSphere.manufacturer.entity.ProductBatch;
import com.example.DSphere.manufacturer.repository.ProductBatchRepository;
import com.example.DSphere.manufacturer.repository.ProductRepository;
import com.example.DSphere.sales.dto.WorkflowRequests;
import com.example.DSphere.sales.entity.OrderItem;
import com.example.DSphere.sales.entity.Shipment;
import com.example.DSphere.sales.entity.ShipmentItem;
import com.example.DSphere.sales.repository.DeliveryDiscrepancyRepository;
import com.example.DSphere.sales.repository.DeliveryReceiptItemRepository;
import com.example.DSphere.sales.repository.DeliveryReceiptRepository;
import com.example.DSphere.sales.repository.OrderItemRepository;
import com.example.DSphere.sales.repository.ProductVerificationRepository;
import com.example.DSphere.sales.repository.ShipmentItemRepository;
import com.example.DSphere.sales.repository.ShipmentRepository;
import com.example.DSphere.sales.repository.ShipmentStatusHistoryRepository;
import com.example.DSphere.sales.repository.WarehouseStockRepository;
import com.example.DSphere.sales.entity.ProductVerification;
import com.example.DSphere.systemadmin.security.UserRoleResolver;
import com.example.DSphere.systemadmin.service.BusinessRuleException;
import com.example.DSphere.systemadmin.service.NotificationGateway;
import com.example.DSphere.systemadmin.service.TicketOpener;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.ObjectProvider;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Dispatch without a scanner: typed product code, batch and quantity are verified before stock leaves. */
@ExtendWith(MockitoExtension.class)
class ShipmentWorkflowServiceTest {
    @Mock ShipmentRepository shipments;
    @Mock ShipmentItemRepository items;
    @Mock OrderItemRepository orderItems;
    @Mock DistributorOrderRepository orders;
    @Mock ProductRepository products;
    @Mock ProductBatchRepository batches;
    @Mock ProductVerificationRepository verifications;
    @Mock ShipmentStatusHistoryRepository history;
    @Mock DeliveryReceiptRepository receipts;
    @Mock DeliveryReceiptItemRepository receiptItems;
    @Mock DeliveryDiscrepancyRepository discrepancies;
    @Mock WarehouseStockRepository stocks;
    @Mock StockLedgerService ledger;
    @Mock SalesStatuses statuses;
    @Mock NotificationGateway notifications;
    @Mock UserRoleResolver users;
    @Mock ObjectProvider<TicketOpener> tickets;
    @InjectMocks ShipmentWorkflowService service;

    private Shipment shipment() {
        Shipment s = new Shipment();
        s.setShipmentId(1L);
        s.setWarehouseId(3L);
        return s;
    }

    private ShipmentItem item(String status) {
        ShipmentItem i = new ShipmentItem();
        i.setShipmentItemId(10L);
        i.setShipmentId(1L);
        i.setOrderItemId(20L);
        i.setProductBatchId(40L);
        i.setQuantity(new BigDecimal("5"));
        i.setVerificationStatus(status);
        return i;
    }

    private void productSetup() {
        OrderItem oi = new OrderItem();
        oi.setOrderItemId(20L);
        oi.setProductId(30L);
        when(orderItems.findById(20L)).thenReturn(Optional.of(oi));
        Product p = new Product();
        p.setProductId(30L);
        p.setProductName("Soap 100g");
        p.setProductCode("4006381333931");
        when(products.findById(30L)).thenReturn(Optional.of(p));
        ProductBatch b = new ProductBatch();
        b.setProductBatchId(40L);
        b.setProductId(30L);
        b.setBatchNumber("B-001");
        b.setExpiryDate(LocalDate.now().plusMonths(6));
        when(batches.findById(40L)).thenReturn(Optional.of(b));
        when(verifications.save(any(ProductVerification.class))).thenAnswer(a -> a.getArgument(0));
    }

    @Test
    void dispatch_withUnverifiedItems_isRejected() {
        when(shipments.findById(1L)).thenReturn(Optional.of(shipment()));
        when(items.findByShipmentId(1L)).thenReturn(List.of(item("PENDING")));
        BusinessRuleException e = assertThrows(BusinessRuleException.class, () -> service.dispatch(1L, null));
        assertTrue(e.getMessage().contains("Verify every item"));
        verifyNoInteractions(ledger);
    }

    @Test
    void verify_matchingCodeBatchAndQuantity_marksItemVerified() {
        when(shipments.findById(1L)).thenReturn(Optional.of(shipment()));
        ShipmentItem i = item("PENDING");
        when(items.findById(10L)).thenReturn(Optional.of(i));
        productSetup();
        var r = service.verifyItem(1L, 10L, new WorkflowRequests.VerifyItem("4006381333931", "B-001", new BigDecimal("5")));
        assertEquals("MATCH", r.result());
        assertEquals("VERIFIED", i.getVerificationStatus());
    }

    @Test
    void verify_typingMistakeInTheCode_isAMismatch() {
        when(shipments.findById(1L)).thenReturn(Optional.of(shipment()));
        ShipmentItem i = item("PENDING");
        when(items.findById(10L)).thenReturn(Optional.of(i));
        productSetup();
        var r = service.verifyItem(1L, 10L, new WorkflowRequests.VerifyItem("4006381333932", "B-001", new BigDecimal("4")));
        assertEquals("MISMATCH", r.result());
        assertEquals("MISMATCH", i.getVerificationStatus());
        assertEquals(2, r.messages().size());
    }
}
