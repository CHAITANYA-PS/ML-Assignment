package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.distributor.entity.HealthScoreHistory;
import com.example.DSphere.distributor.repository.HealthScoreHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthScoreHistoryService extends AbstractCrudService<HealthScoreHistory, Long> {
    public HealthScoreHistoryService(HealthScoreHistoryRepository repository) {
        super(repository, HealthScoreHistory.class);
    }
}
