package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.CommitmentStatusDTO;
import com.example.DSphere.distributor.entity.CommitmentStatus;
import com.example.DSphere.distributor.service.CommitmentStatusService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/commitment-statuses")
public class CommitmentStatusController {
    private final CommitmentStatusService service;

    public CommitmentStatusController(CommitmentStatusService service) {
        this.service = service;
    }

    @Operation(summary = "Create CommitmentStatus")
    @PostMapping
    public ResponseEntity<CommitmentStatusDTO> create(@Validated(OnCreate.class) @RequestBody CommitmentStatusDTO body) {
        CommitmentStatus saved = service.create(DtoMapper.toEntity(body, CommitmentStatus.class));
        return ResponseEntity.created(URI.create("/api/v1/commitment-statuses/" + saved.getCommitmentStatusId())).body(DtoMapper.toDto(saved, CommitmentStatusDTO.class));
    }

    @Operation(summary = "Get one CommitmentStatus by id")
    @GetMapping("/{id}")
    public CommitmentStatusDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), CommitmentStatusDTO.class);
    }

    @Operation(summary = "List / search CommitmentStatus", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<CommitmentStatusDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), CommitmentStatusDTO.class));
        }
        Page<CommitmentStatus> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), CommitmentStatusDTO.class));
    }

    @Operation(summary = "Update CommitmentStatus (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public CommitmentStatusDTO update(@PathVariable Long id, @Valid @RequestBody CommitmentStatusDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, CommitmentStatus.class)), CommitmentStatusDTO.class);
    }

    @Operation(summary = "Delete CommitmentStatus")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
