package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.ActivityType;
import com.example.DSphere.distributor.repository.ActivityTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class ActivityTypeService extends AbstractCrudService<ActivityType, Long> {
    public ActivityTypeService(ActivityTypeRepository repository) {
        super(repository, ActivityType.class);
    }
}
