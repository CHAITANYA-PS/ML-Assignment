package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="commitment_progress",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class CommitmentProgress implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="progress_id")
 private Long progressId;
 @NotNull(groups=OnCreate.class, message="Commitment id is required")
 @Column(name="commitment_id")
 private Long commitmentId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "commitment_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Commitment commitment;
 @NotNull(groups=OnCreate.class, message="Progress value is required")
 @PositiveOrZero(message="Progress value must be 0 or greater")
 @Column(name="progress_value")
 private BigDecimal progressValue;
 @NotNull(groups=OnCreate.class, message="Recorded by is required")
 @Column(name="recorded_by")
 private Long recordedBy;
 @Column(name="recorded_at")
 private OffsetDateTime recordedAt;
 @Column(name="remarks")
 private String remarks;
}