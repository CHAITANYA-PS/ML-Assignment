package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.CommitmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentStatusRepository extends JpaRepository<CommitmentStatus, Long> {
}
