package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.CommitmentHistoryDTO;
import com.example.DSphere.distributor.entity.CommitmentHistory;
import com.example.DSphere.distributor.service.CommitmentHistoryService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/commitment-histories")
public class CommitmentHistoryController {
    private final CommitmentHistoryService service;

    public CommitmentHistoryController(CommitmentHistoryService service) {
        this.service = service;
    }

    @Operation(summary = "Create CommitmentHistory")
    @PostMapping
    public ResponseEntity<CommitmentHistoryDTO> create(@Validated(OnCreate.class) @RequestBody CommitmentHistoryDTO body) {
        CommitmentHistory saved = service.create(DtoMapper.toEntity(body, CommitmentHistory.class));
        return ResponseEntity.created(URI.create("/api/v1/commitment-histories/" + saved.getHistoryId())).body(DtoMapper.toDto(saved, CommitmentHistoryDTO.class));
    }

    @Operation(summary = "Get one CommitmentHistory by id")
    @GetMapping("/{id}")
    public CommitmentHistoryDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), CommitmentHistoryDTO.class);
    }

    @Operation(summary = "List / search CommitmentHistory", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<CommitmentHistoryDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), CommitmentHistoryDTO.class));
        }
        Page<CommitmentHistory> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), CommitmentHistoryDTO.class));
    }

    @Operation(summary = "Update CommitmentHistory (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public CommitmentHistoryDTO update(@PathVariable Long id, @Valid @RequestBody CommitmentHistoryDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, CommitmentHistory.class)), CommitmentHistoryDTO.class);
    }

    @Operation(summary = "Delete CommitmentHistory")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
