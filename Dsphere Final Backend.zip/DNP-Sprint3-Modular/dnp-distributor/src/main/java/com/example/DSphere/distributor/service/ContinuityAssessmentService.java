package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.ContinuityAssessment;
import com.example.DSphere.distributor.repository.ContinuityAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class ContinuityAssessmentService extends AbstractCrudService<ContinuityAssessment, Long> {
    public ContinuityAssessmentService(ContinuityAssessmentRepository repository) {
        super(repository, ContinuityAssessment.class);
    }
}
