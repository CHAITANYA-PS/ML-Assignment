package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.RiskLevel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskLevelRepository extends JpaRepository<RiskLevel, Long> {
}
