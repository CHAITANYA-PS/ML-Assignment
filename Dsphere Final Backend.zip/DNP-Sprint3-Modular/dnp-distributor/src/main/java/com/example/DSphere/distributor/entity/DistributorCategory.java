package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.CreateDefault;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="distributor_category",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DistributorCategory implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="distributor_category_id")
 private Long distributorCategoryId;
 @NotNull(groups=OnCreate.class, message="Distributor id is required")
 @Column(name="distributor_id")
 private Long distributorId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "distributor_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Distributor distributor;
 @NotNull(groups=OnCreate.class, message="Category id is required")
 @Column(name="category_id")
 private Long categoryId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "category_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Category category;
 @Column(name="assigned_at")
 private OffsetDateTime assignedAt;
 @CreateDefault("Active")
 @Size(max=20, message="Status must be at most 20 characters")
 @Pattern(regexp="Active|Inactive", message="Status must be one of: Active, Inactive")
 @Column(name="status")
 private String status;
}