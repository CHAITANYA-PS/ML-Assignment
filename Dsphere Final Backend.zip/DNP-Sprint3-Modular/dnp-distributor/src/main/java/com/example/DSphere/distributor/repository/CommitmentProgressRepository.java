package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.CommitmentProgress;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface CommitmentProgressRepository extends JpaRepository<CommitmentProgress, Long> {
    List<CommitmentProgress> findByCommitmentId(Long commitmentId);
}
