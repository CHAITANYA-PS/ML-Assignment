package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.CommitmentHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface CommitmentHistoryRepository extends JpaRepository<CommitmentHistory, Long> {
    List<CommitmentHistory> findByCommitmentIdOrderByActionAtAsc(Long commitmentId);
}
