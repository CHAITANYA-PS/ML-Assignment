package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.DistributorHealthAssessmentDTO;
import com.example.DSphere.distributor.entity.DistributorHealthAssessment;
import com.example.DSphere.distributor.service.DistributorHealthAssessmentService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/distributor-health-assessments")
public class DistributorHealthAssessmentController {
    private final DistributorHealthAssessmentService service;

    public DistributorHealthAssessmentController(DistributorHealthAssessmentService service) {
        this.service = service;
    }

    @Operation(summary = "Create DistributorHealthAssessment")
    @PostMapping
    public ResponseEntity<DistributorHealthAssessmentDTO> create(@Validated(OnCreate.class) @RequestBody DistributorHealthAssessmentDTO body) {
        DistributorHealthAssessment saved = service.create(DtoMapper.toEntity(body, DistributorHealthAssessment.class));
        return ResponseEntity.created(URI.create("/api/v1/distributor-health-assessments/" + saved.getAssessmentId())).body(DtoMapper.toDto(saved, DistributorHealthAssessmentDTO.class));
    }

    @Operation(summary = "Get one DistributorHealthAssessment by id")
    @GetMapping("/{id}")
    public DistributorHealthAssessmentDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), DistributorHealthAssessmentDTO.class);
    }

    @Operation(summary = "List / search DistributorHealthAssessment", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<DistributorHealthAssessmentDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), DistributorHealthAssessmentDTO.class));
        }
        Page<DistributorHealthAssessment> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), DistributorHealthAssessmentDTO.class));
    }

    @Operation(summary = "Update DistributorHealthAssessment (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public DistributorHealthAssessmentDTO update(@PathVariable Long id, @Valid @RequestBody DistributorHealthAssessmentDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, DistributorHealthAssessment.class)), DistributorHealthAssessmentDTO.class);
    }

    @Operation(summary = "Delete DistributorHealthAssessment")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
