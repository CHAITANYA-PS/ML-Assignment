package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.DistributorDTO;
import com.example.DSphere.distributor.entity.Distributor;
import com.example.DSphere.distributor.service.DistributorService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/distributors")
public class DistributorController {
    private final DistributorService service;

    public DistributorController(DistributorService service) {
        this.service = service;
    }

    @Operation(summary = "Create Distributor")
    @PostMapping
    public ResponseEntity<DistributorDTO> create(@Validated(OnCreate.class) @RequestBody DistributorDTO body) {
        Distributor saved = service.create(DtoMapper.toEntity(body, Distributor.class));
        return ResponseEntity.created(URI.create("/api/v1/distributors/" + saved.getDistributorId())).body(DtoMapper.toDto(saved, DistributorDTO.class));
    }

    @Operation(summary = "Get one Distributor by id")
    @GetMapping("/{id}")
    public DistributorDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), DistributorDTO.class);
    }

    @Operation(summary = "List / search Distributor", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<DistributorDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), DistributorDTO.class));
        }
        Page<Distributor> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), DistributorDTO.class));
    }

    @Operation(summary = "Update Distributor (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public DistributorDTO update(@PathVariable Long id, @Valid @RequestBody DistributorDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, Distributor.class)), DistributorDTO.class);
    }

    @Operation(summary = "Delete Distributor")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    @Operation(summary = "Relationship DSphere: categories of a distributor", description = "Read through the @ManyToMany Distributor.categories (table distributor_category)")
    @GetMapping("/{id}/categories")
    public List<Map<String, Object>> categories(@PathVariable Long id) {
        return service.categories(id);
    }
}
