package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="credit_risk_assessment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class CreditRiskAssessment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="risk_assessment_id")
 private Long riskAssessmentId;
 @Column(name="distributor_id")
 private Long distributorId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "distributor_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Distributor distributor;
 @Column(name="credit_limit_id")
 private Long creditLimitId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "credit_limit_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private DistributorCreditLimit creditLimit;
 @Column(name="risk_score")
 private BigDecimal riskScore;
 @Column(name="assessed_by")
 private Long assessedBy;
 @Column(name="assessed_at")
 private OffsetDateTime assessedAt;
}