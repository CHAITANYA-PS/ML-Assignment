package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.Category;
import com.example.DSphere.distributor.repository.CategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class CategoryService extends AbstractCrudService<Category, Long> {
    public CategoryService(CategoryRepository repository) {
        super(repository, Category.class);
    }
}
