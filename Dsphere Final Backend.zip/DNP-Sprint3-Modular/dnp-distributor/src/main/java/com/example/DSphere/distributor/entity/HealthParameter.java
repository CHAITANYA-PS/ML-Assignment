package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.CreateDefault;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="health_parameter",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class HealthParameter implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="parameter_id")
 private Long parameterId;
 @NotBlank(groups=OnCreate.class, message="Parameter name is required")
 @Size(max=150, message="Parameter name must be at most 150 characters")
 @Column(name="parameter_name")
 private String parameterName;
 @Size(max=500, message="Description must be at most 500 characters")
 @Column(name="description", length=500)
 private String description;
 @CreateDefault("true")
 @Column(name="is_active")
 private Boolean isActive;

 @JsonIgnore
 @OneToMany(mappedBy = "parameter", fetch = FetchType.LAZY)
 private List<HealthParameterWeight> healthParameterWeights;

}