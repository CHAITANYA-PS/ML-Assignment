package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.CommitmentDTO;
import com.example.DSphere.distributor.dto.CommitmentHistoryDTO;
import com.example.DSphere.distributor.dto.HealthScoreHistoryDTO;
import com.example.DSphere.distributor.service.CommitmentWorkflowService;
import com.example.DSphere.distributor.service.ContinuityService;
import com.example.DSphere.distributor.service.HealthScoreService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.security.CurrentUser;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/** Health score, commitment approval / completion and continuity risk. */
@RestController
@RequestMapping("/api/v1")
public class DistributorWorkflowController {
    private final HealthScoreService health;
    private final CommitmentWorkflowService commitments;
    private final ContinuityService continuity;

    public DistributorWorkflowController(HealthScoreService health, CommitmentWorkflowService commitments, ContinuityService continuity) {
        this.health = health;
        this.commitments = commitments;
        this.continuity = continuity;
    }

    public record Remarks(@Size(max = 500, message = "Remarks must be at most 500 characters") String remarks) {
    }

    public record Reason(@NotBlank(message = "Reason is required") @Size(max = 500) String reason) {
    }

    // ---- health score

    @Operation(summary = "Calculate a distributor's health score now", description = "Weighted: sum of (assessment score x weight). "
            + "reportingPeriodId is optional. Stored in the history and alerts below health.alert.threshold.")
    @PostMapping("/health-scores/calculate/{distributorId}")
    public HealthScoreService.HealthScoreResult calculate(@PathVariable Long distributorId, @RequestParam(required = false) Long reportingPeriodId) {
        return health.calculate(distributorId, reportingPeriodId);
    }

    @Operation(summary = "Health score trend of a distributor (oldest first)")
    @GetMapping("/health-scores/{distributorId}/trend")
    public List<HealthScoreHistoryDTO> trend(@PathVariable Long distributorId) {
        CurrentUser.checkDistributor(distributorId);
        return DtoMapper.toDtoList(health.trend(distributorId), HealthScoreHistoryDTO.class);
    }

    @Operation(summary = "Check that the active health parameter weights total 100%")
    @GetMapping("/health-scores/weights/check")
    public Map<String, Object> weights() {
        return health.weightCheck();
    }

    // ---- commitments

    @Operation(summary = "Approve a Pending commitment")
    @PostMapping("/commitments/{id}/approve")
    public CommitmentDTO approve(@PathVariable Long id, @Valid @RequestBody(required = false) Remarks body) {
        return DtoMapper.toDto(commitments.approve(id, body == null ? null : body.remarks()), CommitmentDTO.class);
    }

    @Operation(summary = "Reject a Pending commitment")
    @PostMapping("/commitments/{id}/reject")
    public CommitmentDTO reject(@PathVariable Long id, @Valid @RequestBody Reason body) {
        return DtoMapper.toDto(commitments.reject(id, body.reason()), CommitmentDTO.class);
    }

    @Operation(summary = "Completion % of a commitment (progress / target)")
    @GetMapping("/commitments/{id}/completion")
    public CommitmentWorkflowService.Completion completion(@PathVariable Long id) {
        return commitments.completion(id);
    }

    @Operation(summary = "Approval and status history of a commitment")
    @GetMapping("/commitments/{id}/history")
    public List<CommitmentHistoryDTO> history(@PathVariable Long id) {
        return DtoMapper.toDtoList(commitments.history(id), CommitmentHistoryDTO.class);
    }

    // ---- continuity

    @Operation(summary = "Active distributors at continuity risk, with reasons and recommendations")
    @GetMapping("/continuity/at-risk")
    public List<ContinuityService.ContinuityCheck> atRisk() {
        return continuity.atRisk();
    }

    @Operation(summary = "Continuity check of one distributor")
    @GetMapping("/continuity/{distributorId}")
    public ContinuityService.ContinuityCheck check(@PathVariable Long distributorId) {
        CurrentUser.checkDistributor(distributorId);
        return continuity.check(distributorId);
    }
}
