package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.ActivityTypeDTO;
import com.example.DSphere.distributor.entity.ActivityType;
import com.example.DSphere.distributor.service.ActivityTypeService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/activity-types")
public class ActivityTypeController {
    private final ActivityTypeService service;

    public ActivityTypeController(ActivityTypeService service) {
        this.service = service;
    }

    @Operation(summary = "Create ActivityType")
    @PostMapping
    public ResponseEntity<ActivityTypeDTO> create(@Validated(OnCreate.class) @RequestBody ActivityTypeDTO body) {
        ActivityType saved = service.create(DtoMapper.toEntity(body, ActivityType.class));
        return ResponseEntity.created(URI.create("/api/v1/activity-types/" + saved.getActivityTypeId())).body(DtoMapper.toDto(saved, ActivityTypeDTO.class));
    }

    @Operation(summary = "Get one ActivityType by id")
    @GetMapping("/{id}")
    public ActivityTypeDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ActivityTypeDTO.class);
    }

    @Operation(summary = "List / search ActivityType", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ActivityTypeDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ActivityTypeDTO.class));
        }
        Page<ActivityType> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ActivityTypeDTO.class));
    }

    @Operation(summary = "Update ActivityType (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ActivityTypeDTO update(@PathVariable Long id, @Valid @RequestBody ActivityTypeDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ActivityType.class)), ActivityTypeDTO.class);
    }

    @Operation(summary = "Delete ActivityType")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
