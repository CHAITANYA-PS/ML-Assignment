package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.Region;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegionRepository extends JpaRepository<Region, Long> {
}
