package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.ContinuityStatusType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContinuityStatusTypeRepository extends JpaRepository<ContinuityStatusType, Long> {
}
