package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="continuity_assessment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ContinuityAssessment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="continuity_assessment_id")
 private Long continuityAssessmentId;
 @Column(name="distributor_id")
 private Long distributorId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "distributor_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Distributor distributor;
 @Column(name="continuity_status_id")
 private Long continuityStatusId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "continuity_status_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private ContinuityStatusType continuityStatus;
 @Column(name="risk_level_id")
 private Long riskLevelId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "risk_level_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private RiskLevel riskLevel;
 @Column(name="assessed_by")
 private Long assessedBy;
 @Column(name="assessment_date")
 private OffsetDateTime assessmentDate;
 @Column(name="remarks")
 private String remarks;
}