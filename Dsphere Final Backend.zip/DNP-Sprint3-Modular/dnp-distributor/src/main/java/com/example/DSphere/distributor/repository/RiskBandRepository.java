package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.RiskBand;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskBandRepository extends JpaRepository<RiskBand, Long> {
}
