package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.CreateDefault;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="health_assessment_alert",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class HealthAssessmentAlert implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="alert_id")
 private Long alertId;
 @NotNull(groups=OnCreate.class, message="Assessment id is required")
 @Column(name="assessment_id")
 private Long assessmentId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "assessment_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private DistributorHealthAssessment assessment;
 @NotNull(groups=OnCreate.class, message="Threshold value is required")
 @DecimalMin(value="0", message="Threshold value must be between 0 and 100")
 @DecimalMax(value="100", message="Threshold value must be between 0 and 100")
 @Column(name="threshold_value")
 private BigDecimal thresholdValue;
 @NotBlank(groups=OnCreate.class, message="Message is required")
 @Column(name="message")
 private String message;
 @CreateDefault("false")
 @Column(name="read_status")
 private Boolean readStatus;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}