package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.DistributorOrderDTO;
import com.example.DSphere.distributor.entity.DistributorOrder;
import com.example.DSphere.distributor.service.DistributorOrderService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/distributor-orders")
public class DistributorOrderController {
    private final DistributorOrderService service;

    public DistributorOrderController(DistributorOrderService service) {
        this.service = service;
    }

    @Operation(summary = "Create DistributorOrder")
    @PostMapping
    public ResponseEntity<DistributorOrderDTO> create(@Validated(OnCreate.class) @RequestBody DistributorOrderDTO body) {
        DistributorOrder saved = service.create(DtoMapper.toEntity(body, DistributorOrder.class));
        return ResponseEntity.created(URI.create("/api/v1/distributor-orders/" + saved.getOrderId())).body(DtoMapper.toDto(saved, DistributorOrderDTO.class));
    }

    @Operation(summary = "Get one DistributorOrder by id")
    @GetMapping("/{id}")
    public DistributorOrderDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), DistributorOrderDTO.class);
    }

    @Operation(summary = "List / search DistributorOrder", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<DistributorOrderDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), DistributorOrderDTO.class));
        }
        Page<DistributorOrder> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), DistributorOrderDTO.class));
    }

    @Operation(summary = "Update DistributorOrder (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public DistributorOrderDTO update(@PathVariable Long id, @Valid @RequestBody DistributorOrderDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, DistributorOrder.class)), DistributorOrderDTO.class);
    }

    @Operation(summary = "Delete DistributorOrder")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
