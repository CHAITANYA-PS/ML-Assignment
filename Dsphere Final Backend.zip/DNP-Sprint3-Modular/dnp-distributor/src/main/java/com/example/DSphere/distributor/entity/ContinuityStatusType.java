package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="continuity_status_type",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ContinuityStatusType implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="continuity_status_id")
 private Long continuityStatusId;
 @Column(name="status_name")
 private String statusName;
 @Column(name="description")
 private String description;

 @JsonIgnore
 @OneToMany(mappedBy = "continuityStatus", fetch = FetchType.LAZY)
 private List<ContinuityAssessment> continuityAssessments;

}