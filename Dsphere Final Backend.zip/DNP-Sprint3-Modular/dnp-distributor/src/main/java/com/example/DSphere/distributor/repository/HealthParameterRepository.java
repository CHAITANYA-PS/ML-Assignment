package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.HealthParameter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthParameterRepository extends JpaRepository<HealthParameter, Long> {
}
