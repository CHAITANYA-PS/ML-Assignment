package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="health_parameter_weight",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class HealthParameterWeight implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="parameter_weight_id")
 private Long parameterWeightId;
 @NotNull(groups=OnCreate.class, message="Parameter id is required")
 @Column(name="parameter_id")
 private Long parameterId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "parameter_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private HealthParameter parameter;
 @NotNull(groups=OnCreate.class, message="Weight is required")
 @DecimalMin(value="0", message="Weight must be between 0 and 1")
 @DecimalMax(value="1", message="Weight must be between 0 and 1")
 @Column(name="weight")
 private BigDecimal weight;
 @NotNull(groups=OnCreate.class, message="Valid from is required")
 @Column(name="valid_from")
 private LocalDate validFrom;
 @Column(name="valid_to")
 private LocalDate validTo;

 @JsonIgnore
 @OneToMany(mappedBy = "parameterWeight", fetch = FetchType.LAZY)
 private List<DistributorHealthAssessment> distributorHealthAssessments;

}