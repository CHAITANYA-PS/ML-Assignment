package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.DistributorCategoryDTO;
import com.example.DSphere.distributor.entity.DistributorCategory;
import com.example.DSphere.distributor.service.DistributorCategoryService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/distributor-categories")
public class DistributorCategoryController {
    private final DistributorCategoryService service;

    public DistributorCategoryController(DistributorCategoryService service) {
        this.service = service;
    }

    @Operation(summary = "Create DistributorCategory")
    @PostMapping
    public ResponseEntity<DistributorCategoryDTO> create(@Validated(OnCreate.class) @RequestBody DistributorCategoryDTO body) {
        DistributorCategory saved = service.create(DtoMapper.toEntity(body, DistributorCategory.class));
        return ResponseEntity.created(URI.create("/api/v1/distributor-categories/" + saved.getDistributorCategoryId())).body(DtoMapper.toDto(saved, DistributorCategoryDTO.class));
    }

    @Operation(summary = "Get one DistributorCategory by id")
    @GetMapping("/{id}")
    public DistributorCategoryDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), DistributorCategoryDTO.class);
    }

    @Operation(summary = "List / search DistributorCategory", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<DistributorCategoryDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), DistributorCategoryDTO.class));
        }
        Page<DistributorCategory> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), DistributorCategoryDTO.class));
    }

    @Operation(summary = "Update DistributorCategory (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public DistributorCategoryDTO update(@PathVariable Long id, @Valid @RequestBody DistributorCategoryDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, DistributorCategory.class)), DistributorCategoryDTO.class);
    }

    @Operation(summary = "Delete DistributorCategory")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
