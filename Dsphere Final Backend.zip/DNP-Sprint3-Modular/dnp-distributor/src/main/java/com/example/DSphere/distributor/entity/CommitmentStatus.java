package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.CreateDefault;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="commitment_status",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class CommitmentStatus implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="commitment_status_id")
 private Long commitmentStatusId;
 @NotBlank(groups=OnCreate.class, message="Status name is required")
 @Size(max=50, message="Status name must be at most 50 characters")
 @Column(name="status_name")
 private String statusName;
 @CreateDefault("false")
 @Column(name="is_terminal")
 private Boolean isTerminal;

 @JsonIgnore
 @OneToMany(mappedBy = "commitmentStatus", fetch = FetchType.LAZY)
 private List<Commitment> commitments;

}