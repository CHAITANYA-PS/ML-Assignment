package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.time.LocalDate; import java.time.OffsetDateTime;
@Entity @Table(name="distributor_order",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DistributorOrder implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="order_id")
 private Long orderId;
 @NotBlank(groups=OnCreate.class, message="Order number is required")
 @Size(max=50, message="Order number must be at most 50 characters")
 @Column(name="order_number")
 private String orderNumber;
 @NotNull(groups=OnCreate.class, message="Distributor id is required")
 @Column(name="distributor_id")
 private Long distributorId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "distributor_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Distributor distributor;
 @NotNull(groups=OnCreate.class, message="Order status id is required")
 @Column(name="order_status_id")
 private Long orderStatusId;
 @NotNull(groups=OnCreate.class, message="Order date is required")
 @Column(name="order_date")
 private LocalDate orderDate;
 @NotNull(groups=OnCreate.class, message="Created by is required")
 @Column(name="created_by")
 private Long createdBy;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 @Column(name="updated_at")
 private OffsetDateTime updatedAt;
}