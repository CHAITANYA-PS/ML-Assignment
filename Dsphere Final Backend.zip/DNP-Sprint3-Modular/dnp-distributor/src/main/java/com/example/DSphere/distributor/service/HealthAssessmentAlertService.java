package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.HealthAssessmentAlert;
import com.example.DSphere.distributor.repository.HealthAssessmentAlertRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthAssessmentAlertService extends AbstractCrudService<HealthAssessmentAlert, Long> {
    public HealthAssessmentAlertService(HealthAssessmentAlertRepository repository) {
        super(repository, HealthAssessmentAlert.class);
    }
}
