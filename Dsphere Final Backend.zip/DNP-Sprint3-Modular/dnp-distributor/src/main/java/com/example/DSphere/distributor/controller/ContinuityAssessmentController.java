package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.ContinuityAssessmentDTO;
import com.example.DSphere.distributor.entity.ContinuityAssessment;
import com.example.DSphere.distributor.service.ContinuityAssessmentService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/continuity-assessments")
public class ContinuityAssessmentController {
    private final ContinuityAssessmentService service;

    public ContinuityAssessmentController(ContinuityAssessmentService service) {
        this.service = service;
    }

    @Operation(summary = "Create ContinuityAssessment")
    @PostMapping
    public ResponseEntity<ContinuityAssessmentDTO> create(@Validated(OnCreate.class) @RequestBody ContinuityAssessmentDTO body) {
        ContinuityAssessment saved = service.create(DtoMapper.toEntity(body, ContinuityAssessment.class));
        return ResponseEntity.created(URI.create("/api/v1/continuity-assessments/" + saved.getContinuityAssessmentId())).body(DtoMapper.toDto(saved, ContinuityAssessmentDTO.class));
    }

    @Operation(summary = "Get one ContinuityAssessment by id")
    @GetMapping("/{id}")
    public ContinuityAssessmentDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ContinuityAssessmentDTO.class);
    }

    @Operation(summary = "List / search ContinuityAssessment", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ContinuityAssessmentDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ContinuityAssessmentDTO.class));
        }
        Page<ContinuityAssessment> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ContinuityAssessmentDTO.class));
    }

    @Operation(summary = "Update ContinuityAssessment (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ContinuityAssessmentDTO update(@PathVariable Long id, @Valid @RequestBody ContinuityAssessmentDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ContinuityAssessment.class)), ContinuityAssessmentDTO.class);
    }

    @Operation(summary = "Delete ContinuityAssessment")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
