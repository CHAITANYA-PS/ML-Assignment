package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.DistributorUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorUserRepository extends JpaRepository<DistributorUser, Long> {
}
