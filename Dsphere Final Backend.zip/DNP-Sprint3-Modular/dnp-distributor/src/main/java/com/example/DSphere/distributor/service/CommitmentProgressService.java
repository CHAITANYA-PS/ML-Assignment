package com.example.DSphere.distributor.service;

import com.example.DSphere.distributor.entity.CommitmentProgress;
import com.example.DSphere.distributor.repository.CommitmentProgressRepository;
import com.example.DSphere.systemadmin.service.AbstractCrudService;
import org.springframework.stereotype.Service;

/** Progress entries of a commitment; an approved commitment is completed automatically when it reaches 100 %. */
@Service
public class CommitmentProgressService extends AbstractCrudService<CommitmentProgress, Long> {
    private final CommitmentWorkflowService workflow;

    public CommitmentProgressService(CommitmentProgressRepository repository, CommitmentWorkflowService workflow) {
        super(repository, CommitmentProgress.class);
        this.workflow = workflow;
    }

    @Override
    protected void afterCreate(CommitmentProgress saved) {
        if (saved.getCommitmentId() != null) {
            workflow.checkCompleted(saved.getCommitmentId());
        }
    }
}
