package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal;
@Entity @Table(name="risk_band",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class RiskBand implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="risk_band_id")
 private Long riskBandId;
 @Column(name="risk_category")
 private String riskCategory;
 @Column(name="minimum_score")
 private BigDecimal minimumScore;
 @Column(name="maximum_score")
 private BigDecimal maximumScore;

 @JsonIgnore
 @OneToMany(mappedBy = "riskBand", fetch = FetchType.LAZY)
 private List<HealthScoreHistory> healthScoreHistories;

}