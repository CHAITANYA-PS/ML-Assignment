package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="risk_level",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class RiskLevel implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="risk_level_id")
 private Long riskLevelId;
 @Column(name="risk_level_name")
 private String riskLevelName;
 @Column(name="severity_rank")
 private Integer severityRank;

 @JsonIgnore
 @OneToMany(mappedBy = "riskLevel", fetch = FetchType.LAZY)
 private List<ContinuityAssessment> continuityAssessments;

}