package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.CommitmentHistory;
import com.example.DSphere.distributor.repository.CommitmentHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentHistoryService extends AbstractCrudService<CommitmentHistory, Long> {
    public CommitmentHistoryService(CommitmentHistoryRepository repository) {
        super(repository, CommitmentHistory.class);
    }
}
