package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*;  import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
@Entity @Table(name="commitment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Commitment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="commitment_id")
 private Long commitmentId;
 @NotNull(groups=OnCreate.class, message="Distributor id is required")
 @Column(name="distributor_id")
 private Long distributorId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "distributor_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Distributor distributor;
 @NotNull(groups=OnCreate.class, message="Measurement unit id is required")
 @Column(name="measurement_unit_id")
 private Long measurementUnitId;
 @NotNull(groups=OnCreate.class, message="Commitment status id is required")
 @Column(name="commitment_status_id")
 private Long commitmentStatusId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "commitment_status_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private CommitmentStatus commitmentStatus;
 @NotBlank(groups=OnCreate.class, message="Target name is required")
 @Size(max=200, message="Target name must be at most 200 characters")
 @Column(name="target_name")
 private String targetName;
 @NotNull(groups=OnCreate.class, message="Target value is required")
 @PositiveOrZero(message="Target value must be 0 or greater")
 @Column(name="target_value")
 private BigDecimal targetValue;
 @NotNull(groups=OnCreate.class, message="Due date is required")
 @Column(name="due_date")
 private LocalDate dueDate;
 @NotNull(groups=OnCreate.class, message="Created by is required")
 @Column(name="created_by")
 private Long createdBy;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 @Column(name="updated_at")
 private OffsetDateTime updatedAt;
 // ---- V4 columns
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="approved_by")
 private Long approvedBy;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="approved_at")
 private OffsetDateTime approvedAt;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Size(max=500, message="Rejection reason must be at most 500 characters")
 @Column(name="rejection_reason", length=500)
 private String rejectionReason;

 @JsonIgnore
 @OneToMany(mappedBy = "commitment", fetch = FetchType.LAZY)
 private List<CommitmentHistory> commitmentHistories;

 @JsonIgnore
 @OneToMany(mappedBy = "commitment", fetch = FetchType.LAZY)
 private List<CommitmentProgress> commitmentProgresses;

}