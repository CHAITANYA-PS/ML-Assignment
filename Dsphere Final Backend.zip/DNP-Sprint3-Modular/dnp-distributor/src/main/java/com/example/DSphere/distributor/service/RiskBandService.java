package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.RiskBand;
import com.example.DSphere.distributor.repository.RiskBandRepository;
import org.springframework.stereotype.Service;

@Service
public class RiskBandService extends AbstractCrudService<RiskBand, Long> {
    public RiskBandService(RiskBandRepository repository) {
        super(repository, RiskBand.class);
    }
}
