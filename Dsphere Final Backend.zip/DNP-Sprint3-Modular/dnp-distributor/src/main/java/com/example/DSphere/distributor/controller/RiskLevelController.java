package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.RiskLevelDTO;
import com.example.DSphere.distributor.entity.RiskLevel;
import com.example.DSphere.distributor.service.RiskLevelService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/risk-levels")
public class RiskLevelController {
    private final RiskLevelService service;

    public RiskLevelController(RiskLevelService service) {
        this.service = service;
    }

    @Operation(summary = "Create RiskLevel")
    @PostMapping
    public ResponseEntity<RiskLevelDTO> create(@Validated(OnCreate.class) @RequestBody RiskLevelDTO body) {
        RiskLevel saved = service.create(DtoMapper.toEntity(body, RiskLevel.class));
        return ResponseEntity.created(URI.create("/api/v1/risk-levels/" + saved.getRiskLevelId())).body(DtoMapper.toDto(saved, RiskLevelDTO.class));
    }

    @Operation(summary = "Get one RiskLevel by id")
    @GetMapping("/{id}")
    public RiskLevelDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), RiskLevelDTO.class);
    }

    @Operation(summary = "List / search RiskLevel", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<RiskLevelDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), RiskLevelDTO.class));
        }
        Page<RiskLevel> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), RiskLevelDTO.class));
    }

    @Operation(summary = "Update RiskLevel (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public RiskLevelDTO update(@PathVariable Long id, @Valid @RequestBody RiskLevelDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, RiskLevel.class)), RiskLevelDTO.class);
    }

    @Operation(summary = "Delete RiskLevel")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
