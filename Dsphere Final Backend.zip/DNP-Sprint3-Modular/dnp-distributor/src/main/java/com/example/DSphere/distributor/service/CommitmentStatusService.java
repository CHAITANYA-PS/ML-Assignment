package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.CommitmentStatus;
import com.example.DSphere.distributor.repository.CommitmentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentStatusService extends AbstractCrudService<CommitmentStatus, Long> {
    public CommitmentStatusService(CommitmentStatusRepository repository) {
        super(repository, CommitmentStatus.class);
    }
}
