package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="distributor_health_assessment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DistributorHealthAssessment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="assessment_id")
 private Long assessmentId;
 @NotNull(groups=OnCreate.class, message="Distributor id is required")
 @Column(name="distributor_id")
 private Long distributorId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "distributor_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Distributor distributor;
 @NotNull(groups=OnCreate.class, message="Parameter weight id is required")
 @Column(name="parameter_weight_id")
 private Long parameterWeightId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "parameter_weight_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private HealthParameterWeight parameterWeight;
 @NotNull(groups=OnCreate.class, message="Reporting period id is required")
 @Column(name="reporting_period_id")
 private Long reportingPeriodId;
 @NotNull(groups=OnCreate.class, message="Score is required")
 @DecimalMin(value="0", message="Score must be between 0 and 100")
 @DecimalMax(value="100", message="Score must be between 0 and 100")
 @Column(name="score")
 private BigDecimal score;
 @NotNull(groups=OnCreate.class, message="Assessed by is required")
 @Column(name="assessed_by")
 private Long assessedBy;
 @Column(name="assessed_at")
 private OffsetDateTime assessedAt;
 @Column(name="remarks")
 private String remarks;

 @JsonIgnore
 @OneToMany(mappedBy = "assessment", fetch = FetchType.LAZY)
 private List<HealthAssessmentAlert> healthAssessmentAlerts;

}