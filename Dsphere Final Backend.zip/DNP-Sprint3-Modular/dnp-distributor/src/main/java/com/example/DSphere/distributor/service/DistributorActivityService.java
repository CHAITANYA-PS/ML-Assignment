package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.DistributorActivity;
import com.example.DSphere.distributor.repository.DistributorActivityRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorActivityService extends AbstractCrudService<DistributorActivity, Long> {
    public DistributorActivityService(DistributorActivityRepository repository) {
        super(repository, DistributorActivity.class);
    }
}
