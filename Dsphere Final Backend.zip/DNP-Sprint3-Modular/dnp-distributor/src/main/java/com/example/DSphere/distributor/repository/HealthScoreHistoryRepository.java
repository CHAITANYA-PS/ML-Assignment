package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.HealthScoreHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface HealthScoreHistoryRepository extends JpaRepository<HealthScoreHistory, Long> {
    List<HealthScoreHistory> findByDistributorIdOrderByCalculatedAtAsc(Long distributorId);
}
