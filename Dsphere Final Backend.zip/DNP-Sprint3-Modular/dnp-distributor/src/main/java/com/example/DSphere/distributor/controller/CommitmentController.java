package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.CommitmentDTO;
import com.example.DSphere.distributor.entity.Commitment;
import com.example.DSphere.distributor.service.CommitmentService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/commitments")
public class CommitmentController {
    private final CommitmentService service;

    public CommitmentController(CommitmentService service) {
        this.service = service;
    }

    @Operation(summary = "Create Commitment")
    @PostMapping
    public ResponseEntity<CommitmentDTO> create(@Validated(OnCreate.class) @RequestBody CommitmentDTO body) {
        Commitment saved = service.create(DtoMapper.toEntity(body, Commitment.class));
        return ResponseEntity.created(URI.create("/api/v1/commitments/" + saved.getCommitmentId())).body(DtoMapper.toDto(saved, CommitmentDTO.class));
    }

    @Operation(summary = "Get one Commitment by id")
    @GetMapping("/{id}")
    public CommitmentDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), CommitmentDTO.class);
    }

    @Operation(summary = "List / search Commitment", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<CommitmentDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), CommitmentDTO.class));
        }
        Page<Commitment> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), CommitmentDTO.class));
    }

    @Operation(summary = "Update Commitment (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public CommitmentDTO update(@PathVariable Long id, @Valid @RequestBody CommitmentDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, Commitment.class)), CommitmentDTO.class);
    }

    @Operation(summary = "Delete Commitment")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
