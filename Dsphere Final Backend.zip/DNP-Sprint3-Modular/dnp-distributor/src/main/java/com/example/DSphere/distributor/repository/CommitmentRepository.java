package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.Commitment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentRepository extends JpaRepository<Commitment, Long> {
}
