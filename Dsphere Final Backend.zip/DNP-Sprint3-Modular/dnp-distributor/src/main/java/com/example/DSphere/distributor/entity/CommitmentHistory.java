package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="commitment_history",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class CommitmentHistory implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="history_id")
 private Long historyId;
 @NotNull(groups=OnCreate.class, message="Commitment id is required")
 @Column(name="commitment_id")
 private Long commitmentId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "commitment_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Commitment commitment;
 @NotBlank(groups=OnCreate.class, message="Action is required")
 @Size(max=100, message="Action must be at most 100 characters")
 @Column(name="action")
 private String action;
 @NotNull(groups=OnCreate.class, message="Action by is required")
 @Column(name="action_by")
 private Long actionBy;
 @Column(name="remarks")
 private String remarks;
 @Column(name="action_at")
 private OffsetDateTime actionAt;
}