package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.Region;
import com.example.DSphere.distributor.repository.RegionRepository;
import org.springframework.stereotype.Service;

@Service
public class RegionService extends AbstractCrudService<Region, Long> {
    public RegionService(RegionRepository repository) {
        super(repository, Region.class);
    }
}
