package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.CreditRiskAssessment;
import com.example.DSphere.distributor.repository.CreditRiskAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class CreditRiskAssessmentService extends AbstractCrudService<CreditRiskAssessment, Long> {
    public CreditRiskAssessmentService(CreditRiskAssessmentRepository repository) {
        super(repository, CreditRiskAssessment.class);
    }
}
