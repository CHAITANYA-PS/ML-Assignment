package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.RiskLevel;
import com.example.DSphere.distributor.repository.RiskLevelRepository;
import org.springframework.stereotype.Service;

@Service
public class RiskLevelService extends AbstractCrudService<RiskLevel, Long> {
    public RiskLevelService(RiskLevelRepository repository) {
        super(repository, RiskLevel.class);
    }
}
