package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.HealthAssessmentAlertDTO;
import com.example.DSphere.distributor.entity.HealthAssessmentAlert;
import com.example.DSphere.distributor.service.HealthAssessmentAlertService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/health-assessment-alerts")
public class HealthAssessmentAlertController {
    private final HealthAssessmentAlertService service;

    public HealthAssessmentAlertController(HealthAssessmentAlertService service) {
        this.service = service;
    }

    @Operation(summary = "Create HealthAssessmentAlert")
    @PostMapping
    public ResponseEntity<HealthAssessmentAlertDTO> create(@Validated(OnCreate.class) @RequestBody HealthAssessmentAlertDTO body) {
        HealthAssessmentAlert saved = service.create(DtoMapper.toEntity(body, HealthAssessmentAlert.class));
        return ResponseEntity.created(URI.create("/api/v1/health-assessment-alerts/" + saved.getAlertId())).body(DtoMapper.toDto(saved, HealthAssessmentAlertDTO.class));
    }

    @Operation(summary = "Get one HealthAssessmentAlert by id")
    @GetMapping("/{id}")
    public HealthAssessmentAlertDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), HealthAssessmentAlertDTO.class);
    }

    @Operation(summary = "List / search HealthAssessmentAlert", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<HealthAssessmentAlertDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), HealthAssessmentAlertDTO.class));
        }
        Page<HealthAssessmentAlert> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), HealthAssessmentAlertDTO.class));
    }

    @Operation(summary = "Update HealthAssessmentAlert (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public HealthAssessmentAlertDTO update(@PathVariable Long id, @Valid @RequestBody HealthAssessmentAlertDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, HealthAssessmentAlert.class)), HealthAssessmentAlertDTO.class);
    }

    @Operation(summary = "Delete HealthAssessmentAlert")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
