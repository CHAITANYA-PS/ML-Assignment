package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="activity_type",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ActivityType implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="activity_type_id")
 private Long activityTypeId;
 @Column(name="activity_type_name")
 private String activityTypeName;
 @Column(name="description")
 private String description;

 @JsonIgnore
 @OneToMany(mappedBy = "activityType", fetch = FetchType.LAZY)
 private List<DistributorActivity> distributorActivities;

}