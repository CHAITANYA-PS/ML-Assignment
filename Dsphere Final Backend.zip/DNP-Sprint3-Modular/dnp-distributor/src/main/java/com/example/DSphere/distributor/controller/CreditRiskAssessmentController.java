package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.CreditRiskAssessmentDTO;
import com.example.DSphere.distributor.entity.CreditRiskAssessment;
import com.example.DSphere.distributor.service.CreditRiskAssessmentService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/credit-risk-assessments")
public class CreditRiskAssessmentController {
    private final CreditRiskAssessmentService service;

    public CreditRiskAssessmentController(CreditRiskAssessmentService service) {
        this.service = service;
    }

    @Operation(summary = "Create CreditRiskAssessment")
    @PostMapping
    public ResponseEntity<CreditRiskAssessmentDTO> create(@Validated(OnCreate.class) @RequestBody CreditRiskAssessmentDTO body) {
        CreditRiskAssessment saved = service.create(DtoMapper.toEntity(body, CreditRiskAssessment.class));
        return ResponseEntity.created(URI.create("/api/v1/credit-risk-assessments/" + saved.getRiskAssessmentId())).body(DtoMapper.toDto(saved, CreditRiskAssessmentDTO.class));
    }

    @Operation(summary = "Get one CreditRiskAssessment by id")
    @GetMapping("/{id}")
    public CreditRiskAssessmentDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), CreditRiskAssessmentDTO.class);
    }

    @Operation(summary = "List / search CreditRiskAssessment", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<CreditRiskAssessmentDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), CreditRiskAssessmentDTO.class));
        }
        Page<CreditRiskAssessment> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), CreditRiskAssessmentDTO.class));
    }

    @Operation(summary = "Update CreditRiskAssessment (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public CreditRiskAssessmentDTO update(@PathVariable Long id, @Valid @RequestBody CreditRiskAssessmentDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, CreditRiskAssessment.class)), CreditRiskAssessmentDTO.class);
    }

    @Operation(summary = "Delete CreditRiskAssessment")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
