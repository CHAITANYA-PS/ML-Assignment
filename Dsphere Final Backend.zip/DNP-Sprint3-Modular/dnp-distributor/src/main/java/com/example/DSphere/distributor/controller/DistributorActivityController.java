package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.DistributorActivityDTO;
import com.example.DSphere.distributor.entity.DistributorActivity;
import com.example.DSphere.distributor.service.DistributorActivityService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/distributor-activities")
public class DistributorActivityController {
    private final DistributorActivityService service;

    public DistributorActivityController(DistributorActivityService service) {
        this.service = service;
    }

    @Operation(summary = "Create DistributorActivity")
    @PostMapping
    public ResponseEntity<DistributorActivityDTO> create(@Validated(OnCreate.class) @RequestBody DistributorActivityDTO body) {
        DistributorActivity saved = service.create(DtoMapper.toEntity(body, DistributorActivity.class));
        return ResponseEntity.created(URI.create("/api/v1/distributor-activities/" + saved.getActivityId())).body(DtoMapper.toDto(saved, DistributorActivityDTO.class));
    }

    @Operation(summary = "Get one DistributorActivity by id")
    @GetMapping("/{id}")
    public DistributorActivityDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), DistributorActivityDTO.class);
    }

    @Operation(summary = "List / search DistributorActivity", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<DistributorActivityDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), DistributorActivityDTO.class));
        }
        Page<DistributorActivity> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), DistributorActivityDTO.class));
    }

    @Operation(summary = "Update DistributorActivity (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public DistributorActivityDTO update(@PathVariable Long id, @Valid @RequestBody DistributorActivityDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, DistributorActivity.class)), DistributorActivityDTO.class);
    }

    @Operation(summary = "Delete DistributorActivity")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
