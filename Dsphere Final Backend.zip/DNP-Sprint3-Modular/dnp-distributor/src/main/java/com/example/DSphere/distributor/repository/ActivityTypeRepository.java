package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.ActivityType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ActivityTypeRepository extends JpaRepository<ActivityType, Long> {
}
