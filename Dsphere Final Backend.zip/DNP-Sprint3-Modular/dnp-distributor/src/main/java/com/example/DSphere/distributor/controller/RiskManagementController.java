package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.CreditRiskAssessmentDTO;
import com.example.DSphere.distributor.dto.DistributorCreditLimitDTO;
import com.example.DSphere.distributor.entity.CreditRiskAssessment;
import com.example.DSphere.distributor.entity.DistributorCreditLimit;
import com.example.DSphere.distributor.service.CreditRiskAssessmentService;
import com.example.DSphere.distributor.service.DistributorCreditLimitService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** Credit risk assessments and credit limits. Controller only maps HTTP to service calls; all rules live in the services package. */
@RestController
@RequestMapping("/api/v1/risk-management")
public class RiskManagementController {
    private final CreditRiskAssessmentService creditRiskAssessmentService;
    private final DistributorCreditLimitService distributorCreditLimitService;

    public RiskManagementController(CreditRiskAssessmentService creditRiskAssessmentService, DistributorCreditLimitService distributorCreditLimitService) {
        this.creditRiskAssessmentService = creditRiskAssessmentService;
        this.distributorCreditLimitService = distributorCreditLimitService;
    }

    @Operation(summary = "Create CreditRiskAssessment")
    @PostMapping("/assessments")
    public ResponseEntity<CreditRiskAssessmentDTO> createCreditRiskAssessment(@Validated(OnCreate.class) @RequestBody CreditRiskAssessmentDTO body) {
        CreditRiskAssessment saved = creditRiskAssessmentService.create(DtoMapper.toEntity(body, CreditRiskAssessment.class));
        return ResponseEntity.created(URI.create("/api/v1/risk-management/assessments/" + saved.getRiskAssessmentId())).body(DtoMapper.toDto(saved, CreditRiskAssessmentDTO.class));
    }

    @Operation(summary = "List / search CreditRiskAssessment", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping("/assessments")
    public ResponseEntity<List<CreditRiskAssessmentDTO>> getAllCreditRiskAssessment(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(creditRiskAssessmentService.getAll(), CreditRiskAssessmentDTO.class));
        }
        Page<CreditRiskAssessment> result = creditRiskAssessmentService.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), CreditRiskAssessmentDTO.class));
    }

    @Operation(summary = "Get one CreditRiskAssessment by id")
    @GetMapping("/assessments/{id}")
    public CreditRiskAssessmentDTO getCreditRiskAssessment(@PathVariable Long id) {
        return DtoMapper.toDto(creditRiskAssessmentService.get(id), CreditRiskAssessmentDTO.class);
    }

    @Operation(summary = "Update CreditRiskAssessment (send only the fields to change, plus version)")
    @PutMapping("/assessments/{id}")
    public CreditRiskAssessmentDTO updateCreditRiskAssessment(@PathVariable Long id, @Valid @RequestBody CreditRiskAssessmentDTO body) {
        return DtoMapper.toDto(creditRiskAssessmentService.update(id, DtoMapper.toEntity(body, CreditRiskAssessment.class)), CreditRiskAssessmentDTO.class);
    }

    @Operation(summary = "Delete CreditRiskAssessment")
    @DeleteMapping("/assessments/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteCreditRiskAssessment(@PathVariable Long id) {
        creditRiskAssessmentService.delete(id);
    }

    @Operation(summary = "Create DistributorCreditLimit")
    @PostMapping("/credit-limits")
    public ResponseEntity<DistributorCreditLimitDTO> createDistributorCreditLimit(@Validated(OnCreate.class) @RequestBody DistributorCreditLimitDTO body) {
        DistributorCreditLimit saved = distributorCreditLimitService.create(DtoMapper.toEntity(body, DistributorCreditLimit.class));
        return ResponseEntity.created(URI.create("/api/v1/risk-management/credit-limits/" + saved.getCreditLimitId())).body(DtoMapper.toDto(saved, DistributorCreditLimitDTO.class));
    }

    @Operation(summary = "List / search DistributorCreditLimit", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping("/credit-limits")
    public ResponseEntity<List<DistributorCreditLimitDTO>> getAllDistributorCreditLimit(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(distributorCreditLimitService.getAll(), DistributorCreditLimitDTO.class));
        }
        Page<DistributorCreditLimit> result = distributorCreditLimitService.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), DistributorCreditLimitDTO.class));
    }

    @Operation(summary = "Get one DistributorCreditLimit by id")
    @GetMapping("/credit-limits/{id}")
    public DistributorCreditLimitDTO getDistributorCreditLimit(@PathVariable Long id) {
        return DtoMapper.toDto(distributorCreditLimitService.get(id), DistributorCreditLimitDTO.class);
    }

    @Operation(summary = "Update DistributorCreditLimit (send only the fields to change, plus version)")
    @PutMapping("/credit-limits/{id}")
    public DistributorCreditLimitDTO updateDistributorCreditLimit(@PathVariable Long id, @Valid @RequestBody DistributorCreditLimitDTO body) {
        return DtoMapper.toDto(distributorCreditLimitService.update(id, DtoMapper.toEntity(body, DistributorCreditLimit.class)), DistributorCreditLimitDTO.class);
    }

    @Operation(summary = "Delete DistributorCreditLimit")
    @DeleteMapping("/credit-limits/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteDistributorCreditLimit(@PathVariable Long id) {
        distributorCreditLimitService.delete(id);
    }
}
