package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.HealthAssessmentAlert;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthAssessmentAlertRepository extends JpaRepository<HealthAssessmentAlert, Long> {
}
