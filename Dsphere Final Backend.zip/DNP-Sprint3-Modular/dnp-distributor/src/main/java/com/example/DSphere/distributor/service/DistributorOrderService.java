package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.DistributorOrder;
import com.example.DSphere.distributor.repository.DistributorOrderRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorOrderService extends AbstractCrudService<DistributorOrder, Long> {
    public DistributorOrderService(DistributorOrderRepository repository) {
        super(repository, DistributorOrder.class);
    }
}
