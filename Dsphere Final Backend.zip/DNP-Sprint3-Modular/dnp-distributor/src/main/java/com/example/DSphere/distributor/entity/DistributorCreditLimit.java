package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="distributor_credit_limit",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DistributorCreditLimit implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="credit_limit_id")
 private Long creditLimitId;
 @Column(name="distributor_id")
 private Long distributorId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "distributor_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Distributor distributor;
 @Column(name="credit_limit")
 private BigDecimal creditLimit;
 @Column(name="valid_from")
 private LocalDate validFrom;
 @Column(name="valid_to")
 private LocalDate validTo;
 @Column(name="approved_by")
 private Long approvedBy;

 @JsonIgnore
 @OneToMany(mappedBy = "creditLimit", fetch = FetchType.LAZY)
 private List<CreditRiskAssessment> creditRiskAssessments;

}