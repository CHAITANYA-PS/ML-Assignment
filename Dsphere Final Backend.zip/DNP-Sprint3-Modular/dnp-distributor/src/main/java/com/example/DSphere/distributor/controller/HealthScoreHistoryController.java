package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.HealthScoreHistoryDTO;
import com.example.DSphere.distributor.entity.HealthScoreHistory;
import com.example.DSphere.distributor.service.HealthScoreHistoryService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** HealthScoreHistory API. Read-only: rows are written by the system (workflow actions), never typed in. */
@RestController
@RequestMapping("/api/v1/health-score-histories")
public class HealthScoreHistoryController {
    private final HealthScoreHistoryService service;

    public HealthScoreHistoryController(HealthScoreHistoryService service) {
        this.service = service;
    }

    @Operation(summary = "Get one HealthScoreHistory by id")
    @GetMapping("/{id}")
    public HealthScoreHistoryDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), HealthScoreHistoryDTO.class);
    }

    @Operation(summary = "List / search HealthScoreHistory", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<HealthScoreHistoryDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), HealthScoreHistoryDTO.class));
        }
        Page<HealthScoreHistory> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), HealthScoreHistoryDTO.class));
    }
}
