package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.HealthParameter;
import com.example.DSphere.distributor.repository.HealthParameterRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthParameterService extends AbstractCrudService<HealthParameter, Long> {
    public HealthParameterService(HealthParameterRepository repository) {
        super(repository, HealthParameter.class);
    }
}
