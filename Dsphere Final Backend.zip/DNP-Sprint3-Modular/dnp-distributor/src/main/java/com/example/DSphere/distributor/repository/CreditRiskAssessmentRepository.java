package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.CreditRiskAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CreditRiskAssessmentRepository extends JpaRepository<CreditRiskAssessment, Long> {
}
