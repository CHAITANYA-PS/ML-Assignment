package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.DistributorCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorCategoryRepository extends JpaRepository<DistributorCategory, Long> {
}
