package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.HealthParameterDTO;
import com.example.DSphere.distributor.entity.HealthParameter;
import com.example.DSphere.distributor.service.HealthParameterService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/health-parameters")
public class HealthParameterController {
    private final HealthParameterService service;

    public HealthParameterController(HealthParameterService service) {
        this.service = service;
    }

    @Operation(summary = "Create HealthParameter")
    @PostMapping
    public ResponseEntity<HealthParameterDTO> create(@Validated(OnCreate.class) @RequestBody HealthParameterDTO body) {
        HealthParameter saved = service.create(DtoMapper.toEntity(body, HealthParameter.class));
        return ResponseEntity.created(URI.create("/api/v1/health-parameters/" + saved.getParameterId())).body(DtoMapper.toDto(saved, HealthParameterDTO.class));
    }

    @Operation(summary = "Get one HealthParameter by id")
    @GetMapping("/{id}")
    public HealthParameterDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), HealthParameterDTO.class);
    }

    @Operation(summary = "List / search HealthParameter", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<HealthParameterDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), HealthParameterDTO.class));
        }
        Page<HealthParameter> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), HealthParameterDTO.class));
    }

    @Operation(summary = "Update HealthParameter (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public HealthParameterDTO update(@PathVariable Long id, @Valid @RequestBody HealthParameterDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, HealthParameter.class)), HealthParameterDTO.class);
    }

    @Operation(summary = "Delete HealthParameter")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
