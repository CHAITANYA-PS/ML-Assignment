package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.RiskBandDTO;
import com.example.DSphere.distributor.entity.RiskBand;
import com.example.DSphere.distributor.service.RiskBandService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/risk-bands")
public class RiskBandController {
    private final RiskBandService service;

    public RiskBandController(RiskBandService service) {
        this.service = service;
    }

    @Operation(summary = "Create RiskBand")
    @PostMapping
    public ResponseEntity<RiskBandDTO> create(@Validated(OnCreate.class) @RequestBody RiskBandDTO body) {
        RiskBand saved = service.create(DtoMapper.toEntity(body, RiskBand.class));
        return ResponseEntity.created(URI.create("/api/v1/risk-bands/" + saved.getRiskBandId())).body(DtoMapper.toDto(saved, RiskBandDTO.class));
    }

    @Operation(summary = "Get one RiskBand by id")
    @GetMapping("/{id}")
    public RiskBandDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), RiskBandDTO.class);
    }

    @Operation(summary = "List / search RiskBand", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<RiskBandDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), RiskBandDTO.class));
        }
        Page<RiskBand> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), RiskBandDTO.class));
    }

    @Operation(summary = "Update RiskBand (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public RiskBandDTO update(@PathVariable Long id, @Valid @RequestBody RiskBandDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, RiskBand.class)), RiskBandDTO.class);
    }

    @Operation(summary = "Delete RiskBand")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
