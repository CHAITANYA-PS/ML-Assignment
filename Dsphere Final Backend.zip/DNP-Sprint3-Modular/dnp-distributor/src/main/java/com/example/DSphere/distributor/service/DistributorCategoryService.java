package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.DistributorCategory;
import com.example.DSphere.distributor.repository.DistributorCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorCategoryService extends AbstractCrudService<DistributorCategory, Long> {
    public DistributorCategoryService(DistributorCategoryRepository repository) {
        super(repository, DistributorCategory.class);
    }
}
