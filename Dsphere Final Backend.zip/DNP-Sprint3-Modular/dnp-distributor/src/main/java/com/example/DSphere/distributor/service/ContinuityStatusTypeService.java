package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.ContinuityStatusType;
import com.example.DSphere.distributor.repository.ContinuityStatusTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class ContinuityStatusTypeService extends AbstractCrudService<ContinuityStatusType, Long> {
    public ContinuityStatusTypeService(ContinuityStatusTypeRepository repository) {
        super(repository, ContinuityStatusType.class);
    }
}
