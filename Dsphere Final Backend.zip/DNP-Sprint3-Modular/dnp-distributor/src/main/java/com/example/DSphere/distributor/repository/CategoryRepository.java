package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {
}
