package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.RegionDTO;
import com.example.DSphere.distributor.entity.Region;
import com.example.DSphere.distributor.service.RegionService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/regions")
public class RegionController {
    private final RegionService service;

    public RegionController(RegionService service) {
        this.service = service;
    }

    @Operation(summary = "Create Region")
    @PostMapping
    public ResponseEntity<RegionDTO> create(@Validated(OnCreate.class) @RequestBody RegionDTO body) {
        Region saved = service.create(DtoMapper.toEntity(body, Region.class));
        return ResponseEntity.created(URI.create("/api/v1/regions/" + saved.getRegionId())).body(DtoMapper.toDto(saved, RegionDTO.class));
    }

    @Operation(summary = "Get one Region by id")
    @GetMapping("/{id}")
    public RegionDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), RegionDTO.class);
    }

    @Operation(summary = "List / search Region", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<RegionDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), RegionDTO.class));
        }
        Page<Region> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), RegionDTO.class));
    }

    @Operation(summary = "Update Region (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public RegionDTO update(@PathVariable Long id, @Valid @RequestBody RegionDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, Region.class)), RegionDTO.class);
    }

    @Operation(summary = "Delete Region")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
