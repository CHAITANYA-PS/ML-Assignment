package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.HealthParameterWeightDTO;
import com.example.DSphere.distributor.entity.HealthParameterWeight;
import com.example.DSphere.distributor.service.HealthParameterWeightService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/health-parameter-weights")
public class HealthParameterWeightController {
    private final HealthParameterWeightService service;

    public HealthParameterWeightController(HealthParameterWeightService service) {
        this.service = service;
    }

    @Operation(summary = "Create HealthParameterWeight")
    @PostMapping
    public ResponseEntity<HealthParameterWeightDTO> create(@Validated(OnCreate.class) @RequestBody HealthParameterWeightDTO body) {
        HealthParameterWeight saved = service.create(DtoMapper.toEntity(body, HealthParameterWeight.class));
        return ResponseEntity.created(URI.create("/api/v1/health-parameter-weights/" + saved.getParameterWeightId())).body(DtoMapper.toDto(saved, HealthParameterWeightDTO.class));
    }

    @Operation(summary = "Get one HealthParameterWeight by id")
    @GetMapping("/{id}")
    public HealthParameterWeightDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), HealthParameterWeightDTO.class);
    }

    @Operation(summary = "List / search HealthParameterWeight", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<HealthParameterWeightDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), HealthParameterWeightDTO.class));
        }
        Page<HealthParameterWeight> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), HealthParameterWeightDTO.class));
    }

    @Operation(summary = "Update HealthParameterWeight (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public HealthParameterWeightDTO update(@PathVariable Long id, @Valid @RequestBody HealthParameterWeightDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, HealthParameterWeight.class)), HealthParameterWeightDTO.class);
    }

    @Operation(summary = "Delete HealthParameterWeight")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
