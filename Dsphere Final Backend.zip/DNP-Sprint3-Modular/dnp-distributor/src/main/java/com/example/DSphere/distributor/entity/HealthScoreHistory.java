package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.example.DSphere.systemadmin.entity.OnCreate;
import com.example.DSphere.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Health score history (one row per distributor per calculation; breakdown kept as JSON text) (table dsphere.health_score_history, added in V4). */
@Entity @Table(name="health_score_history",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class HealthScoreHistory implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="health_score_history_id")
 private Long healthScoreHistoryId;
 @NotNull(groups=OnCreate.class, message="Distributor id is required")
 @Column(name="distributor_id")
 private Long distributorId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "distributor_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Distributor distributor;
 @Column(name="reporting_period_id")
 private Long reportingPeriodId;
 @NotNull(groups=OnCreate.class, message="Total score is required")
 @DecimalMin(value="0", message="Total score must be 0 or greater")
 @DecimalMax(value="100", message="Total score must be at most 100")
 @Column(name="total_score")
 private BigDecimal totalScore;
 @Column(name="risk_band_id")
 private Long riskBandId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "risk_band_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private RiskBand riskBand;
 @Column(name="breakdown", length=100000)
 private String breakdown;
 @Column(name="calculated_by")
 private Long calculatedBy;
 @Column(name="calculated_at")
 private OffsetDateTime calculatedAt;
}
