package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.HealthParameterWeight;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthParameterWeightRepository extends JpaRepository<HealthParameterWeight, Long> {
}
