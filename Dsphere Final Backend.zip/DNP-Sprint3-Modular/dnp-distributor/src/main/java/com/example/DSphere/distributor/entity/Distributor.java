package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.persistence.*; import jakarta.validation.constraints.*; import lombok.*; import java.time.LocalDate; import java.time.OffsetDateTime;
@Entity @Table(name="distributor",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Distributor implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="distributor_id")
 private Long distributorId;
 @NotBlank(groups=OnCreate.class, message="Distributor code is required")
 @Size(max=50)
 @Column(name="distributor_code")
 private String distributorCode;
 @NotBlank(groups=OnCreate.class, message="Distributor name is required")
 @Size(max=150)
 @Column(name="distributor_name")
 private String distributorName;
 @NotNull(groups=OnCreate.class, message="Region id is required")
 @Column(name="region_id")
 private Long regionId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "region_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Region region;
 @NotBlank(groups=OnCreate.class, message="Contact person is required")
 @Size(max=150, message="Contact person must be at most 150 characters")
 @Column(name="contact_person")
 private String contactPerson;
 @Email(message="Email must be valid")
 @NotBlank(groups=OnCreate.class, message="Email is required")
 @Size(max=255, message="Email must be at most 255 characters")
 @Column(name="email")
 private String email;
 @Pattern(regexp="^[0-9+() -]{7,20}$", message="Phone must contain 7 to 20 valid characters")
 @Column(name="phone")
 private String phone;
 @NotBlank(groups=OnCreate.class, message="Address is required")
 @Column(name="address")
 private String address;
 @Size(max=20, message="Status must be at most 20 characters")
 @Pattern(regexp="Pending|Active|Suspended|Inactive", message="Status must be one of: Pending, Active, Suspended, Inactive")
 @Column(name="status")
 private String status;
 @Column(name="onboarding_date")
 private LocalDate onboardingDate;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 @Column(name="updated_at")
 private OffsetDateTime updatedAt;

 @JsonIgnore
 @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
 private List<Commitment> commitments;

 @JsonIgnore
 @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
 private List<ContinuityAssessment> continuityAssessments;

 @JsonIgnore
 @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
 private List<CreditRiskAssessment> creditRiskAssessments;

 @JsonIgnore
 @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
 private List<DistributorActivity> distributorActivities;

 @JsonIgnore
 @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
 private List<DistributorCategory> distributorCategories;

 @JsonIgnore
 @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
 private List<DistributorCreditLimit> distributorCreditLimits;

 @JsonIgnore
 @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
 private List<DistributorHealthAssessment> distributorHealthAssessments;

 @JsonIgnore
 @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
 private List<DistributorOrder> distributorOrders;

 @JsonIgnore
 @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
 private List<DistributorUser> distributorUsers;

 @JsonIgnore
 @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
 private List<HealthScoreHistory> healthScoreHistories;

 /** Many-to-many view of the distributor_category link table (read side; links are still created through the link entity). */
 @JsonIgnore
 @ManyToMany(fetch = FetchType.LAZY)
 @JoinTable(name = "distributor_category", schema = "dsphere",
   joinColumns = @JoinColumn(name = "distributor_id"),
   inverseJoinColumns = @JoinColumn(name = "category_id"),
   foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT),
   inverseForeignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private List<Category> categories;

}