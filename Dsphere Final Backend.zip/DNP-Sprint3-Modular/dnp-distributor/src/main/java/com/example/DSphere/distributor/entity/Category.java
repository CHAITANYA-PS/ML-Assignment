package com.example.DSphere.distributor.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="category",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Category implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="category_id")
 private Long categoryId;
 @NotBlank(groups=OnCreate.class, message="Category name is required")
 @Size(max=100, message="Category name must be at most 100 characters")
 @Column(name="category_name")
 private String categoryName;
 @Size(max=500, message="Description must be at most 500 characters")
 @Column(name="description", length=500)
 private String description;

 @JsonIgnore
 @OneToMany(mappedBy = "category", fetch = FetchType.LAZY)
 private List<DistributorCategory> distributorCategories;

 @JsonIgnore
 @ManyToMany(mappedBy = "categories", fetch = FetchType.LAZY)
 private List<Distributor> distributors;

}