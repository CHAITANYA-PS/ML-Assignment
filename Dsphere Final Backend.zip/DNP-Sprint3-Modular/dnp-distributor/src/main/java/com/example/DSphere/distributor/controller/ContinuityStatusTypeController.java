package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.ContinuityStatusTypeDTO;
import com.example.DSphere.distributor.entity.ContinuityStatusType;
import com.example.DSphere.distributor.service.ContinuityStatusTypeService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/continuity-status-types")
public class ContinuityStatusTypeController {
    private final ContinuityStatusTypeService service;

    public ContinuityStatusTypeController(ContinuityStatusTypeService service) {
        this.service = service;
    }

    @Operation(summary = "Create ContinuityStatusType")
    @PostMapping
    public ResponseEntity<ContinuityStatusTypeDTO> create(@Validated(OnCreate.class) @RequestBody ContinuityStatusTypeDTO body) {
        ContinuityStatusType saved = service.create(DtoMapper.toEntity(body, ContinuityStatusType.class));
        return ResponseEntity.created(URI.create("/api/v1/continuity-status-types/" + saved.getContinuityStatusId())).body(DtoMapper.toDto(saved, ContinuityStatusTypeDTO.class));
    }

    @Operation(summary = "Get one ContinuityStatusType by id")
    @GetMapping("/{id}")
    public ContinuityStatusTypeDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ContinuityStatusTypeDTO.class);
    }

    @Operation(summary = "List / search ContinuityStatusType", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ContinuityStatusTypeDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ContinuityStatusTypeDTO.class));
        }
        Page<ContinuityStatusType> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ContinuityStatusTypeDTO.class));
    }

    @Operation(summary = "Update ContinuityStatusType (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ContinuityStatusTypeDTO update(@PathVariable Long id, @Valid @RequestBody ContinuityStatusTypeDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ContinuityStatusType.class)), ContinuityStatusTypeDTO.class);
    }

    @Operation(summary = "Delete ContinuityStatusType")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
