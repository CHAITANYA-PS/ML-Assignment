package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.DistributorOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface DistributorOrderRepository extends JpaRepository<DistributorOrder, Long> {
    List<DistributorOrder> findByDistributorId(Long distributorId);
}
