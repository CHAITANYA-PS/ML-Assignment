package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.CategoryDTO;
import com.example.DSphere.distributor.entity.Category;
import com.example.DSphere.distributor.service.CategoryService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/categories")
public class CategoryController {
    private final CategoryService service;

    public CategoryController(CategoryService service) {
        this.service = service;
    }

    @Operation(summary = "Create Category")
    @PostMapping
    public ResponseEntity<CategoryDTO> create(@Validated(OnCreate.class) @RequestBody CategoryDTO body) {
        Category saved = service.create(DtoMapper.toEntity(body, Category.class));
        return ResponseEntity.created(URI.create("/api/v1/categories/" + saved.getCategoryId())).body(DtoMapper.toDto(saved, CategoryDTO.class));
    }

    @Operation(summary = "Get one Category by id")
    @GetMapping("/{id}")
    public CategoryDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), CategoryDTO.class);
    }

    @Operation(summary = "List / search Category", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<CategoryDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), CategoryDTO.class));
        }
        Page<Category> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), CategoryDTO.class));
    }

    @Operation(summary = "Update Category (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public CategoryDTO update(@PathVariable Long id, @Valid @RequestBody CategoryDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, Category.class)), CategoryDTO.class);
    }

    @Operation(summary = "Delete Category")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
