package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.security.Roles;
import com.example.DSphere.systemadmin.service.StakeholderRoleService;
import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.DistributorUser;
import com.example.DSphere.distributor.repository.DistributorUserRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorUserService extends AbstractCrudService<DistributorUser, Long> {
    private final StakeholderRoleService stakeholders;

    public DistributorUserService(DistributorUserRepository repository, StakeholderRoleService stakeholders) {
        super(repository, DistributorUser.class);
        this.stakeholders = stakeholders;
    }

    /** A DistributorUser row gives the user the DISTRIBUTOR role (one user = one stakeholder). */
    @Override
    protected void afterCreate(DistributorUser saved) {
        stakeholders.assign(saved.getUserId(), Roles.DISTRIBUTOR);
    }

    @Override
    protected void beforeDelete(DistributorUser existing) {
        stakeholders.unassign(existing.getUserId(), Roles.DISTRIBUTOR);
    }

    /** The id is the user_id of an existing user (one-to-one sub-type of app_user), so the client supplies it. */
    @Override
    protected boolean idAssignedByClient() {
        return true;
    }
}
