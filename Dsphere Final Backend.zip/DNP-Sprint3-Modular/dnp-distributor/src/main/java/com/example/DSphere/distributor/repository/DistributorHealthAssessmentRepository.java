package com.example.DSphere.distributor.repository;

import com.example.DSphere.distributor.entity.DistributorHealthAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface DistributorHealthAssessmentRepository extends JpaRepository<DistributorHealthAssessment, Long> {
    List<DistributorHealthAssessment> findByDistributorId(Long distributorId);
}
