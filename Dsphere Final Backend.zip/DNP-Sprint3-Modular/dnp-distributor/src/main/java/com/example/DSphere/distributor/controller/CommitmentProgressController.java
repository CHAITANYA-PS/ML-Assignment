package com.example.DSphere.distributor.controller;

import com.example.DSphere.distributor.dto.CommitmentProgressDTO;
import com.example.DSphere.distributor.entity.CommitmentProgress;
import com.example.DSphere.distributor.service.CommitmentProgressService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/commitment-progresses")
public class CommitmentProgressController {
    private final CommitmentProgressService service;

    public CommitmentProgressController(CommitmentProgressService service) {
        this.service = service;
    }

    @Operation(summary = "Create CommitmentProgress")
    @PostMapping
    public ResponseEntity<CommitmentProgressDTO> create(@Validated(OnCreate.class) @RequestBody CommitmentProgressDTO body) {
        CommitmentProgress saved = service.create(DtoMapper.toEntity(body, CommitmentProgress.class));
        return ResponseEntity.created(URI.create("/api/v1/commitment-progresses/" + saved.getProgressId())).body(DtoMapper.toDto(saved, CommitmentProgressDTO.class));
    }

    @Operation(summary = "Get one CommitmentProgress by id")
    @GetMapping("/{id}")
    public CommitmentProgressDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), CommitmentProgressDTO.class);
    }

    @Operation(summary = "List / search CommitmentProgress", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<CommitmentProgressDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), CommitmentProgressDTO.class));
        }
        Page<CommitmentProgress> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), CommitmentProgressDTO.class));
    }

    @Operation(summary = "Update CommitmentProgress (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public CommitmentProgressDTO update(@PathVariable Long id, @Valid @RequestBody CommitmentProgressDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, CommitmentProgress.class)), CommitmentProgressDTO.class);
    }

    @Operation(summary = "Delete CommitmentProgress")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
