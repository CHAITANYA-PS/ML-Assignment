package com.example.DSphere.distributor.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.distributor.entity.DistributorHealthAssessment;
import com.example.DSphere.distributor.repository.DistributorHealthAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorHealthAssessmentService extends AbstractCrudService<DistributorHealthAssessment, Long> {
    public DistributorHealthAssessmentService(DistributorHealthAssessmentRepository repository) {
        super(repository, DistributorHealthAssessment.class);
    }
}
