package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.ExchangeHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface ExchangeHistoryRepository extends JpaRepository<ExchangeHistory, Long> {
    List<ExchangeHistory> findByExchangeIdOrderByChangedAtAsc(Long exchangeId);
}
