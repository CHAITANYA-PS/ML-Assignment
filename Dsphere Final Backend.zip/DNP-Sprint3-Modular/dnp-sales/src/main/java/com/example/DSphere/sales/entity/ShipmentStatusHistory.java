package com.example.DSphere.sales.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.example.DSphere.systemadmin.entity.OnCreate;
import com.example.DSphere.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Shipment status history (every status change of a shipment) (table dsphere.shipment_status_history, added in V4). */
@Entity @Table(name="shipment_status_history",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ShipmentStatusHistory implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="shipment_status_history_id")
 private Long shipmentStatusHistoryId;
 @NotNull(groups=OnCreate.class, message="Shipment id is required")
 @Column(name="shipment_id")
 private Long shipmentId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "shipment_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Shipment shipment;
 @NotNull(groups=OnCreate.class, message="Shipment status id is required")
 @Column(name="shipment_status_id")
 private Long shipmentStatusId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "shipment_status_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private ShipmentStatus shipmentStatus;
 @Column(name="changed_by")
 private Long changedBy;
 @Size(max=500, message="Remarks must be at most 500 characters")
 @Column(name="remarks", length=500)
 private String remarks;
 @Column(name="changed_at")
 private OffsetDateTime changedAt;
}
