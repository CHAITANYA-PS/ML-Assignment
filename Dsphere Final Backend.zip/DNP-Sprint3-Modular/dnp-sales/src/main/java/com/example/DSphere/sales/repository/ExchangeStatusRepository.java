package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.ExchangeStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExchangeStatusRepository extends JpaRepository<ExchangeStatus, Long> {
}
