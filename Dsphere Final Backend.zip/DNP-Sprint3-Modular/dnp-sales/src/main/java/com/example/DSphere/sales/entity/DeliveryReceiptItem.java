package com.example.DSphere.sales.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.example.DSphere.systemadmin.entity.OnCreate;
import com.example.DSphere.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Delivery receipt lines (expected vs received vs damaged per shipment item) (table dsphere.delivery_receipt_item, added in V4). */
@Entity @Table(name="delivery_receipt_item",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DeliveryReceiptItem implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="delivery_receipt_item_id")
 private Long deliveryReceiptItemId;
 @NotNull(groups=OnCreate.class, message="Delivery receipt id is required")
 @Column(name="delivery_receipt_id")
 private Long deliveryReceiptId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "delivery_receipt_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private DeliveryReceipt deliveryReceipt;
 @NotNull(groups=OnCreate.class, message="Shipment item id is required")
 @Column(name="shipment_item_id")
 private Long shipmentItemId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "shipment_item_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private ShipmentItem shipmentItem;
 @NotNull(groups=OnCreate.class, message="Expected quantity is required")
 @PositiveOrZero(message="Expected quantity must be 0 or greater")
 @Column(name="expected_quantity")
 private BigDecimal expectedQuantity;
 @NotNull(groups=OnCreate.class, message="Received quantity is required")
 @PositiveOrZero(message="Received quantity must be 0 or greater")
 @Column(name="received_quantity")
 private BigDecimal receivedQuantity;
 @CreateDefault("0")
 @PositiveOrZero(message="Damaged quantity must be 0 or greater")
 @Column(name="damaged_quantity")
 private BigDecimal damagedQuantity;
}
