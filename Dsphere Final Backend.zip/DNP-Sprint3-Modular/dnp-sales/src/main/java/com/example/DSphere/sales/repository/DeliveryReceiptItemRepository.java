package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.DeliveryReceiptItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface DeliveryReceiptItemRepository extends JpaRepository<DeliveryReceiptItem, Long> {
    List<DeliveryReceiptItem> findByDeliveryReceiptId(Long deliveryReceiptId);
}
