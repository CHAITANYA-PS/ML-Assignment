package com.example.DSphere.sales.repository;

import com.example.DSphere.sales.entity.DeliveryDiscrepancy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface DeliveryDiscrepancyRepository extends JpaRepository<DeliveryDiscrepancy, Long> {
    List<DeliveryDiscrepancy> findByDeliveryReceiptId(Long deliveryReceiptId);
}
