package com.example.DSphere.manufacturer.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.manufacturer.entity.ProductBatch;
import com.example.DSphere.manufacturer.repository.ProductBatchRepository;
import org.springframework.stereotype.Service;

@Service
public class ProductBatchService extends AbstractCrudService<ProductBatch, Long> {
    public ProductBatchService(ProductBatchRepository repository) {
        super(repository, ProductBatch.class);
    }
}
