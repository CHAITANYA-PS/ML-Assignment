package com.example.DSphere.manufacturer.repository;

import com.example.DSphere.manufacturer.entity.MeasurementUnit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MeasurementUnitRepository extends JpaRepository<MeasurementUnit, Long> {
}
