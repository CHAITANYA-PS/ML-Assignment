package com.example.DSphere.manufacturer.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.manufacturer.entity.VehicleType;
import com.example.DSphere.manufacturer.repository.VehicleTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class VehicleTypeService extends AbstractCrudService<VehicleType, Long> {
    public VehicleTypeService(VehicleTypeRepository repository) {
        super(repository, VehicleType.class);
    }
}
