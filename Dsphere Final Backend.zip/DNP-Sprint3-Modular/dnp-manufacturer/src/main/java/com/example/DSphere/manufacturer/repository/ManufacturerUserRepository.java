package com.example.DSphere.manufacturer.repository;

import com.example.DSphere.manufacturer.entity.ManufacturerUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManufacturerUserRepository extends JpaRepository<ManufacturerUser, Long> {
}
