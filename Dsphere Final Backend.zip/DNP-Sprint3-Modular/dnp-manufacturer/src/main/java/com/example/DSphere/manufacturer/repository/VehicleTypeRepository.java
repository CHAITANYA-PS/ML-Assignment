package com.example.DSphere.manufacturer.repository;

import com.example.DSphere.manufacturer.entity.VehicleType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleTypeRepository extends JpaRepository<VehicleType, Long> {
}
