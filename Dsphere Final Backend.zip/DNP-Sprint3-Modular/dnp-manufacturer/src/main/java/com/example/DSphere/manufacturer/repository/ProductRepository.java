package com.example.DSphere.manufacturer.repository;

import com.example.DSphere.manufacturer.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Long> {
    Optional<Product> findByProductCode(String productCode);

    boolean existsByProductCodeAndProductIdNot(String productCode, Long productId);

    boolean existsByProductCode(String productCode);
}
