package com.example.DSphere.manufacturer.repository;

import com.example.DSphere.manufacturer.entity.Manufacturer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManufacturerRepository extends JpaRepository<Manufacturer, Long> {
}
