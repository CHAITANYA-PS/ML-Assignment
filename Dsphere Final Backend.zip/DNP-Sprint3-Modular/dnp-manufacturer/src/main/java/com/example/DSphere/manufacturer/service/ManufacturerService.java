package com.example.DSphere.manufacturer.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.manufacturer.entity.Manufacturer;
import com.example.DSphere.manufacturer.repository.ManufacturerRepository;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerService extends AbstractCrudService<Manufacturer, Long> {
    public ManufacturerService(ManufacturerRepository repository) {
        super(repository, Manufacturer.class);
    }
}
