package com.example.DSphere.manufacturer.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.manufacturer.entity.MeasurementUnit;
import com.example.DSphere.manufacturer.repository.MeasurementUnitRepository;
import org.springframework.stereotype.Service;

@Service
public class MeasurementUnitService extends AbstractCrudService<MeasurementUnit, Long> {
    public MeasurementUnitService(MeasurementUnitRepository repository) {
        super(repository, MeasurementUnit.class);
    }
}
