package com.example.DSphere.manufacturer.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="manufacturer_user",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ManufacturerUser implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @NotNull(groups=OnCreate.class, message="User id is required (send the id of an existing user)")
 @Column(name="user_id")
 private Long userId;
 @NotNull(groups=OnCreate.class, message="Manufacturer id is required")
 @Column(name="manufacturer_id")
 private Long manufacturerId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "manufacturer_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Manufacturer manufacturer;
}