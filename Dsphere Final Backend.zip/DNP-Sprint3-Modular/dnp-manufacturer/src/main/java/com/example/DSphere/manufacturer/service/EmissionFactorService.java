package com.example.DSphere.manufacturer.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.manufacturer.entity.EmissionFactor;
import com.example.DSphere.manufacturer.repository.EmissionFactorRepository;
import org.springframework.stereotype.Service;

@Service
public class EmissionFactorService extends AbstractCrudService<EmissionFactor, Long> {
    public EmissionFactorService(EmissionFactorRepository repository) {
        super(repository, EmissionFactor.class);
    }
}
