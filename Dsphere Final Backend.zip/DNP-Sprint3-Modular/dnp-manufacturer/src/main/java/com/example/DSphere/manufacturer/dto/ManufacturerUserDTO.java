package com.example.DSphere.manufacturer.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.DSphere.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Request and response body for ManufacturerUser. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class ManufacturerUserDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @NotNull(groups=OnCreate.class, message="User id is required (send the id of an existing user)")
    private Long userId;

    @NotNull(groups=OnCreate.class, message="Manufacturer id is required")
    private Long manufacturerId;
}
