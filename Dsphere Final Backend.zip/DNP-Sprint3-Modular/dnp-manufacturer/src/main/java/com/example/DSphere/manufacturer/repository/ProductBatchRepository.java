package com.example.DSphere.manufacturer.repository;

import com.example.DSphere.manufacturer.entity.ProductBatch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductBatchRepository extends JpaRepository<ProductBatch, Long> {
}
