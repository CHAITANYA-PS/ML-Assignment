package com.example.DSphere.manufacturer.repository;

import com.example.DSphere.manufacturer.entity.EmissionFactor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmissionFactorRepository extends JpaRepository<EmissionFactor, Long> {
}
