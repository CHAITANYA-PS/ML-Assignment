package com.example.DSphere.recovery.repository;

import com.example.DSphere.recovery.entity.TicketStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketStatusRepository extends JpaRepository<TicketStatus, Long> {
}
