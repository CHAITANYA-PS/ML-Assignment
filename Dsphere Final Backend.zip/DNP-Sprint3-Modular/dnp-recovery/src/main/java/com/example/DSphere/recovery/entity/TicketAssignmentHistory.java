package com.example.DSphere.recovery.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.example.DSphere.systemadmin.entity.OnCreate;
import com.example.DSphere.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Ticket assignment history (assign / reassign) (table dsphere.ticket_assignment_history, added in V4). */
@Entity @Table(name="ticket_assignment_history",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class TicketAssignmentHistory implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="assignment_id")
 private Long assignmentId;
 @NotNull(groups=OnCreate.class, message="Ticket id is required")
 @Column(name="ticket_id")
 private Long ticketId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "ticket_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Ticket ticket;
 @NotNull(groups=OnCreate.class, message="Assigned to is required")
 @Column(name="assigned_to")
 private Long assignedTo;
 @Column(name="assigned_by")
 private Long assignedBy;
 @Column(name="assigned_at")
 private OffsetDateTime assignedAt;
 @Size(max=500, message="Remarks must be at most 500 characters")
 @Column(name="remarks", length=500)
 private String remarks;
}
