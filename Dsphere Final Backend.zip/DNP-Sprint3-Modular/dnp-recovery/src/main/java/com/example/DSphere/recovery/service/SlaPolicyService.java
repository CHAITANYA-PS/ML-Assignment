package com.example.DSphere.recovery.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.recovery.entity.SlaPolicy;
import com.example.DSphere.recovery.repository.SlaPolicyRepository;
import org.springframework.stereotype.Service;

@Service
public class SlaPolicyService extends AbstractCrudService<SlaPolicy, Long> {
    public SlaPolicyService(SlaPolicyRepository repository) {
        super(repository, SlaPolicy.class);
    }
}
