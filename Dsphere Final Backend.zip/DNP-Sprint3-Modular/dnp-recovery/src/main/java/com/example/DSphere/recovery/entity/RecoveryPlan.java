package com.example.DSphere.recovery.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import com.example.DSphere.systemadmin.entity.CreateDefault; import jakarta.validation.constraints.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
@Entity @Table(name="recovery_plan",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class RecoveryPlan implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="recovery_plan_id")
 private Long recoveryPlanId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="recovery_status_id")
 private Long recoveryStatusId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "recovery_status_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private RecoveryPlanStatus recoveryStatus;
 @Column(name="target_amount")
 private BigDecimal targetAmount;
 @Column(name="start_date")
 private LocalDate startDate;
 @Column(name="end_date")
 private LocalDate endDate;
 @Column(name="created_by")
 private Long createdBy;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 // ---- V4 columns
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @CreateDefault("false")
 @Column(name="recovery_mode")
 private Boolean recoveryMode;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @CreateDefault("0")
 @PositiveOrZero(message="Recovered amount must be 0 or greater")
 @Column(name="recovered_amount")
 private BigDecimal recoveredAmount;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Size(max=30, message="Outcome must be at most 30 characters")
 @Pattern(regexp="RECOVERED|PARTIALLY_RECOVERED|NOT_RECOVERED|CANCELLED", message="Outcome must be one of: RECOVERED, PARTIALLY_RECOVERED, NOT_RECOVERED, CANCELLED")
 @Column(name="outcome")
 private String outcome;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Size(max=1000, message="Outcome remarks must be at most 1000 characters")
 @Column(name="outcome_remarks", length=1000)
 private String outcomeRemarks;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="closed_at")
 private OffsetDateTime closedAt;

 @JsonIgnore
 @OneToMany(mappedBy = "recoveryPlan", fetch = FetchType.LAZY)
 private List<RecoveryMilestone> recoveryMilestones;

 @JsonIgnore
 @OneToMany(mappedBy = "recoveryPlan", fetch = FetchType.LAZY)
 private List<RecoveryPlanTicket> recoveryPlanTickets;

 /** Many-to-many view of the recovery_plan_ticket link table (read side; links are still created through the link entity). */
 @JsonIgnore
 @ManyToMany(fetch = FetchType.LAZY)
 @JoinTable(name = "recovery_plan_ticket", schema = "dsphere",
   joinColumns = @JoinColumn(name = "recovery_plan_id"),
   inverseJoinColumns = @JoinColumn(name = "ticket_id"),
   foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT),
   inverseForeignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private List<Ticket> linkedTickets;

}