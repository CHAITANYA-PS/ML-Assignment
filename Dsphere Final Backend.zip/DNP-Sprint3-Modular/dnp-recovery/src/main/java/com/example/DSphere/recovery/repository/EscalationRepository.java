package com.example.DSphere.recovery.repository;

import com.example.DSphere.recovery.entity.Escalation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface EscalationRepository extends JpaRepository<Escalation, Long> {
    List<Escalation> findByTicketId(Long ticketId);
}
