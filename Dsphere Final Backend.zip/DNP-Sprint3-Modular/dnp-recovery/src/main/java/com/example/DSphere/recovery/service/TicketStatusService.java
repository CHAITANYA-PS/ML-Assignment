package com.example.DSphere.recovery.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.recovery.entity.TicketStatus;
import com.example.DSphere.recovery.repository.TicketStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketStatusService extends AbstractCrudService<TicketStatus, Long> {
    public TicketStatusService(TicketStatusRepository repository) {
        super(repository, TicketStatus.class);
    }
}
