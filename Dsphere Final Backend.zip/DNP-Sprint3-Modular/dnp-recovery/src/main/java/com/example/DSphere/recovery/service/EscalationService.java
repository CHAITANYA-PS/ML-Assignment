package com.example.DSphere.recovery.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.recovery.entity.Escalation;
import com.example.DSphere.recovery.repository.EscalationRepository;
import org.springframework.stereotype.Service;

@Service
public class EscalationService extends AbstractCrudService<Escalation, Long> {
    public EscalationService(EscalationRepository repository) {
        super(repository, Escalation.class);
    }
}
