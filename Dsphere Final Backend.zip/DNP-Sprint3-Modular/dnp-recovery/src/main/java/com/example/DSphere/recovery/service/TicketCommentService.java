package com.example.DSphere.recovery.service;

import org.springframework.transaction.annotation.Transactional;
import com.example.DSphere.recovery.entity.Ticket;
import com.example.DSphere.systemadmin.service.ResourceNotFoundException;
import java.util.LinkedHashMap;
import java.util.Map;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.recovery.entity.TicketComment;
import com.example.DSphere.recovery.repository.TicketCommentRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketCommentService extends AbstractCrudService<TicketComment, Long> {
    public TicketCommentService(TicketCommentRepository repository) {
        super(repository, TicketComment.class);
    }

    /** Relationship DSphere (@ManyToOne): the ticket a comment belongs to, read through comment.getTicket(). */
    @Transactional(readOnly = true)
    public Map<String, Object> ticketOf(Long commentId) {
        TicketComment c = get(commentId);
        Ticket t = c.getTicket();
        if (t == null) {
            throw new ResourceNotFoundException("Ticket not found for comment " + commentId);
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("commentId", c.getCommentId());
        out.put("ticketId", t.getTicketId());
        out.put("referenceNumber", t.getReferenceNumber());
        out.put("subject", t.getSubject());
        return out;
    }
}
