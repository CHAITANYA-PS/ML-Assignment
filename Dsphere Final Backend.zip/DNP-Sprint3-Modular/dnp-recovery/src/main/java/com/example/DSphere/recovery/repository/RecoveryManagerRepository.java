package com.example.DSphere.recovery.repository;

import com.example.DSphere.recovery.entity.RecoveryManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryManagerRepository extends JpaRepository<RecoveryManager, Long> {
}
