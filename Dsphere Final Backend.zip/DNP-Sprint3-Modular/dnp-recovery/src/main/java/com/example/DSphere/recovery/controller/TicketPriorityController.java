package com.example.DSphere.recovery.controller;

import com.example.DSphere.recovery.dto.TicketPriorityDTO;
import com.example.DSphere.recovery.entity.TicketPriority;
import com.example.DSphere.recovery.service.TicketPriorityService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/ticket-priorities")
public class TicketPriorityController {
    private final TicketPriorityService service;

    public TicketPriorityController(TicketPriorityService service) {
        this.service = service;
    }

    @Operation(summary = "Create TicketPriority")
    @PostMapping
    public ResponseEntity<TicketPriorityDTO> create(@Validated(OnCreate.class) @RequestBody TicketPriorityDTO body) {
        TicketPriority saved = service.create(DtoMapper.toEntity(body, TicketPriority.class));
        return ResponseEntity.created(URI.create("/api/v1/ticket-priorities/" + saved.getTicketPriorityId())).body(DtoMapper.toDto(saved, TicketPriorityDTO.class));
    }

    @Operation(summary = "Get one TicketPriority by id")
    @GetMapping("/{id}")
    public TicketPriorityDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), TicketPriorityDTO.class);
    }

    @Operation(summary = "List / search TicketPriority", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<TicketPriorityDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), TicketPriorityDTO.class));
        }
        Page<TicketPriority> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), TicketPriorityDTO.class));
    }

    @Operation(summary = "Update TicketPriority (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public TicketPriorityDTO update(@PathVariable Long id, @Valid @RequestBody TicketPriorityDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, TicketPriority.class)), TicketPriorityDTO.class);
    }

    @Operation(summary = "Delete TicketPriority")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
