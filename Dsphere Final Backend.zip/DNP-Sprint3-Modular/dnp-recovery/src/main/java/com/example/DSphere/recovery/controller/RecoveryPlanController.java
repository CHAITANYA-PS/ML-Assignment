package com.example.DSphere.recovery.controller;

import com.example.DSphere.recovery.dto.RecoveryPlanDTO;
import com.example.DSphere.recovery.entity.RecoveryPlan;
import com.example.DSphere.recovery.service.RecoveryPlanService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/recovery-plans")
public class RecoveryPlanController {
    private final RecoveryPlanService service;

    public RecoveryPlanController(RecoveryPlanService service) {
        this.service = service;
    }

    @Operation(summary = "Create RecoveryPlan")
    @PostMapping
    public ResponseEntity<RecoveryPlanDTO> create(@Validated(OnCreate.class) @RequestBody RecoveryPlanDTO body) {
        RecoveryPlan saved = service.create(DtoMapper.toEntity(body, RecoveryPlan.class));
        return ResponseEntity.created(URI.create("/api/v1/recovery-plans/" + saved.getRecoveryPlanId())).body(DtoMapper.toDto(saved, RecoveryPlanDTO.class));
    }

    @Operation(summary = "Get one RecoveryPlan by id")
    @GetMapping("/{id}")
    public RecoveryPlanDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), RecoveryPlanDTO.class);
    }

    @Operation(summary = "List / search RecoveryPlan", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<RecoveryPlanDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), RecoveryPlanDTO.class));
        }
        Page<RecoveryPlan> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), RecoveryPlanDTO.class));
    }

    @Operation(summary = "Update RecoveryPlan (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public RecoveryPlanDTO update(@PathVariable Long id, @Valid @RequestBody RecoveryPlanDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, RecoveryPlan.class)), RecoveryPlanDTO.class);
    }

    @Operation(summary = "Delete RecoveryPlan")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
