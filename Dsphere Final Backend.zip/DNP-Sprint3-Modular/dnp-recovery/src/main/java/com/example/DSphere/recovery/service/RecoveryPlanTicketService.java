package com.example.DSphere.recovery.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.recovery.entity.RecoveryPlanTicket;
import com.example.DSphere.recovery.repository.RecoveryPlanTicketRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanTicketService extends AbstractCrudService<RecoveryPlanTicket, Long> {
    public RecoveryPlanTicketService(RecoveryPlanTicketRepository repository) {
        super(repository, RecoveryPlanTicket.class);
    }
}
