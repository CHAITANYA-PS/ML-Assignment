package com.example.DSphere.recovery.service;

import com.example.DSphere.systemadmin.security.Roles;
import com.example.DSphere.systemadmin.service.StakeholderRoleService;
import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.recovery.entity.RecoveryManager;
import com.example.DSphere.recovery.repository.RecoveryManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryManagerService extends AbstractCrudService<RecoveryManager, Long> {
    private final StakeholderRoleService stakeholders;

    public RecoveryManagerService(RecoveryManagerRepository repository, StakeholderRoleService stakeholders) {
        super(repository, RecoveryManager.class);
        this.stakeholders = stakeholders;
    }

    /** A RecoveryManager row gives the user the RECOVERY_MANAGER role (one user = one stakeholder). */
    @Override
    protected void afterCreate(RecoveryManager saved) {
        stakeholders.assign(saved.getUserId(), Roles.RECOVERY_MANAGER);
    }

    @Override
    protected void beforeDelete(RecoveryManager existing) {
        stakeholders.unassign(existing.getUserId(), Roles.RECOVERY_MANAGER);
    }

    /** The id is the user_id of an existing user (one-to-one sub-type of app_user), so the client supplies it. */
    @Override
    protected boolean idAssignedByClient() {
        return true;
    }
}
