package com.example.DSphere.recovery.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.recovery.entity.TicketAttachment;
import com.example.DSphere.recovery.repository.TicketAttachmentRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketAttachmentService extends AbstractCrudService<TicketAttachment, Long> {
    public TicketAttachmentService(TicketAttachmentRepository repository) {
        super(repository, TicketAttachment.class);
    }
}
