package com.example.DSphere.recovery.repository;

import com.example.DSphere.recovery.entity.TicketAssignmentHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface TicketAssignmentHistoryRepository extends JpaRepository<TicketAssignmentHistory, Long> {
    List<TicketAssignmentHistory> findByTicketIdOrderByAssignedAtAsc(Long ticketId);
}
