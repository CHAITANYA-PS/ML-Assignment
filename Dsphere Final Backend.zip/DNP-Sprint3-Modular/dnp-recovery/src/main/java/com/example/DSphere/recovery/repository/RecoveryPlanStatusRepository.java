package com.example.DSphere.recovery.repository;

import com.example.DSphere.recovery.entity.RecoveryPlanStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryPlanStatusRepository extends JpaRepository<RecoveryPlanStatus, Long> {
}
