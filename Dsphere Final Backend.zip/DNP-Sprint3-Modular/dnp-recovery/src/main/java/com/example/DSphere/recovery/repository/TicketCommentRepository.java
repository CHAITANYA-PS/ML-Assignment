package com.example.DSphere.recovery.repository;

import com.example.DSphere.recovery.entity.TicketComment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketCommentRepository extends JpaRepository<TicketComment, Long> {
}
