package com.example.DSphere.recovery.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.recovery.entity.TicketCategory;
import com.example.DSphere.recovery.repository.TicketCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketCategoryService extends AbstractCrudService<TicketCategory, Long> {
    public TicketCategoryService(TicketCategoryRepository repository) {
        super(repository, TicketCategory.class);
    }
}
