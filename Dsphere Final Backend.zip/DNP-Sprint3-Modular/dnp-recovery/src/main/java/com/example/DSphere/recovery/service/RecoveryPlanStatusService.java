package com.example.DSphere.recovery.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.recovery.entity.RecoveryPlanStatus;
import com.example.DSphere.recovery.repository.RecoveryPlanStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanStatusService extends AbstractCrudService<RecoveryPlanStatus, Long> {
    public RecoveryPlanStatusService(RecoveryPlanStatusRepository repository) {
        super(repository, RecoveryPlanStatus.class);
    }
}
