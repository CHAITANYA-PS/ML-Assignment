package com.example.DSphere.recovery.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.recovery.entity.TicketStatusHistory;
import com.example.DSphere.recovery.repository.TicketStatusHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketStatusHistoryService extends AbstractCrudService<TicketStatusHistory, Long> {
    public TicketStatusHistoryService(TicketStatusHistoryRepository repository) {
        super(repository, TicketStatusHistory.class);
    }
}
