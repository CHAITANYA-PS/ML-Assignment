package com.example.DSphere.recovery.repository;

import com.example.DSphere.recovery.entity.TicketPriority;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketPriorityRepository extends JpaRepository<TicketPriority, Long> {
}
