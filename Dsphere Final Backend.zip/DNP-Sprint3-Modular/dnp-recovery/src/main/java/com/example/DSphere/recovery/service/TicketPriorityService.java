package com.example.DSphere.recovery.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.recovery.entity.TicketPriority;
import com.example.DSphere.recovery.repository.TicketPriorityRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketPriorityService extends AbstractCrudService<TicketPriority, Long> {
    public TicketPriorityService(TicketPriorityRepository repository) {
        super(repository, TicketPriority.class);
    }
}
