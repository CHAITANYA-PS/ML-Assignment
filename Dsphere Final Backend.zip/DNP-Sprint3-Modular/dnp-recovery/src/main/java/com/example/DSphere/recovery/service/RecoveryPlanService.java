package com.example.DSphere.recovery.service;

import com.example.DSphere.recovery.entity.RecoveryPlan;
import com.example.DSphere.recovery.repository.RecoveryPlanRepository;
import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.systemadmin.service.BusinessRuleException;
import org.springframework.stereotype.Service;

/** Recovery plans. A new plan is Active unless a status is given; the end date cannot be before the start date. */
@Service
public class RecoveryPlanService extends AbstractCrudService<RecoveryPlan, Long> {
    private final RecoveryLookups lookups;

    public RecoveryPlanService(RecoveryPlanRepository repository, RecoveryLookups lookups) {
        super(repository, RecoveryPlan.class);
        this.lookups = lookups;
    }

    @Override
    protected void beforeCreate(RecoveryPlan p) {
        if (p.getRecoveryStatusId() == null) {
            p.setRecoveryStatusId(lookups.planStatus(RecoveryPlanWorkflowService.ACTIVE).getRecoveryStatusId());
        }
        checkDates(p);
    }

    @Override
    protected void beforeUpdate(Long id, RecoveryPlan p, RecoveryPlan existing) {
        if (existing.getClosedAt() != null) {
            throw new BusinessRuleException("Recovery plan " + id + " is closed and cannot be changed");
        }
        checkDates(p);
    }

    private static void checkDates(RecoveryPlan p) {
        if (p.getStartDate() != null && p.getEndDate() != null && p.getEndDate().isBefore(p.getStartDate())) {
            throw new BusinessRuleException("End date cannot be before the start date");
        }
    }

    /** The @ManyToMany side owns recovery_plan_ticket: do not let Hibernate remove the links silently. */
    @Override
    protected void beforeDelete(RecoveryPlan existing) {
        if (existing.getLinkedTickets() != null && !existing.getLinkedTickets().isEmpty()) {
            throw new BusinessRuleException("Recovery plan " + existing.getRecoveryPlanId() + " is still linked to "
                    + existing.getLinkedTickets().size() + " tickets. Remove the recovery plan tickets first");
        }
    }
}
