package com.example.DSphere.recovery.repository;

import com.example.DSphere.recovery.entity.TicketCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketCategoryRepository extends JpaRepository<TicketCategory, Long> {
}
