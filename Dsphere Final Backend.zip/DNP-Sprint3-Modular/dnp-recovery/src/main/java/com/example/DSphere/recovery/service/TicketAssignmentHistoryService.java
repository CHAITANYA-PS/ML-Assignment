package com.example.DSphere.recovery.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;
import com.example.DSphere.recovery.entity.TicketAssignmentHistory;
import com.example.DSphere.recovery.repository.TicketAssignmentHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketAssignmentHistoryService extends AbstractCrudService<TicketAssignmentHistory, Long> {
    public TicketAssignmentHistoryService(TicketAssignmentHistoryRepository repository) {
        super(repository, TicketAssignmentHistory.class);
    }
}
