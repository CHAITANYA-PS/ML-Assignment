package com.example.DSphere.finance.service;

import com.example.DSphere.systemadmin.service.BusinessRuleException;
import com.example.DSphere.systemadmin.service.ResourceNotFoundException;
import com.example.DSphere.finance.entity.FinanceManager;
import com.example.DSphere.finance.repository.FinanceManagerRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.orm.ObjectOptimisticLockingFailureException;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Logic-only test: the repository is a Mockito mock, no database is used. */
@ExtendWith(MockitoExtension.class)
class FinanceManagerServiceTest {
    @Mock FinanceManagerRepository repository;
    @Mock com.example.DSphere.systemadmin.service.StakeholderRoleService stakeholders;
    @InjectMocks FinanceManagerService service;

    private FinanceManager row(Long id, Long version) {
        FinanceManager x = new FinanceManager();
        x.setUserId(id);
        x.setVersion(version);
        return x;
    }

    @Test
    void create_keepsClientUserIdAndClearsVersion_thenSaves() {
        when(repository.save(any(FinanceManager.class))).thenAnswer(a -> a.getArgument(0));
        FinanceManager result = service.create(row(99L, 5L));
        assertEquals(99L, result.getUserId());
        assertNull(result.getVersion());
        verify(repository).save(any(FinanceManager.class));
    }

    @Test
    void create_nullBody_isRejected() {
        assertThrows(BusinessRuleException.class, () -> service.create(null));
        verifyNoInteractions(repository);
    }

    @Test
    void get_existing_returnsRow() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 0L)));
        assertEquals(1L, service.get(1L).getUserId());
    }

    @Test
    void get_missing_throwsNotFound() {
        when(repository.findById(2L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.get(2L));
    }

    @Test
    void getAll_returnsEveryRow() {
        when(repository.findAll()).thenReturn(List.of(row(1L, 0L), row(2L, 0L)));
        assertEquals(2, service.getAll().size());
    }

    @Test
    void update_existing_keepsPathIdAndStoredVersion() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 3L)));
        when(repository.save(any(FinanceManager.class))).thenAnswer(a -> a.getArgument(0));
        FinanceManager result = service.update(1L, row(null, null));
        assertEquals(1L, result.getUserId());
        assertEquals(3L, result.getVersion());
    }

    @Test
    void update_staleVersion_raisesOptimisticLockFailure() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 3L)));
        assertThrows(ObjectOptimisticLockingFailureException.class, () -> service.update(1L, row(null, 2L)));
        verify(repository, never()).save(any(FinanceManager.class));
    }

    @Test
    void update_missing_throwsNotFound() {
        when(repository.findById(9L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.update(9L, row(null, null)));
    }

    @Test
    void delete_existing_deletesById() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 0L)));
        service.delete(1L);
        verify(repository).deleteById(1L);
    }

    @Test
    void delete_missing_throwsNotFoundAndDeletesNothing() {
        when(repository.findById(8L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.delete(8L));
        verify(repository, never()).deleteById(any());
    }
}
