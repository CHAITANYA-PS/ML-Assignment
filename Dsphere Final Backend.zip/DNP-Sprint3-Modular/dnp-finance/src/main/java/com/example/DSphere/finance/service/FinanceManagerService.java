package com.example.DSphere.finance.service;

import com.example.DSphere.systemadmin.security.Roles;
import com.example.DSphere.systemadmin.service.StakeholderRoleService;
import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.finance.entity.FinanceManager;
import com.example.DSphere.finance.repository.FinanceManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class FinanceManagerService extends AbstractCrudService<FinanceManager, Long> {
    private final StakeholderRoleService stakeholders;

    public FinanceManagerService(FinanceManagerRepository repository, StakeholderRoleService stakeholders) {
        super(repository, FinanceManager.class);
        this.stakeholders = stakeholders;
    }

    /** A FinanceManager row gives the user the FINANCE_MANAGER role (one user = one stakeholder). */
    @Override
    protected void afterCreate(FinanceManager saved) {
        stakeholders.assign(saved.getUserId(), Roles.FINANCE_MANAGER);
    }

    @Override
    protected void beforeDelete(FinanceManager existing) {
        stakeholders.unassign(existing.getUserId(), Roles.FINANCE_MANAGER);
    }

    /** The id is the user_id of an existing user (one-to-one sub-type of app_user), so the client supplies it. */
    @Override
    protected boolean idAssignedByClient() {
        return true;
    }
}
