package com.example.DSphere.finance.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.finance.entity.PaymentStatus;
import com.example.DSphere.finance.repository.PaymentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class PaymentStatusService extends AbstractCrudService<PaymentStatus, Long> {
    public PaymentStatusService(PaymentStatusRepository repository) {
        super(repository, PaymentStatus.class);
    }
}
