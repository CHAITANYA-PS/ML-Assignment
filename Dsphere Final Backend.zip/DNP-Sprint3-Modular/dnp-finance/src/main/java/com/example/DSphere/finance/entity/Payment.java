package com.example.DSphere.finance.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.persistence.*; import jakarta.validation.constraints.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="payment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Payment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="payment_id")
 private Long paymentId;
 @NotNull(groups=OnCreate.class, message="Invoice id is required")
 @Column(name="invoice_id")
 private Long invoiceId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "invoice_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Invoice invoice;
 @NotNull(groups=OnCreate.class, message="Payment method id is required")
 @Column(name="payment_method_id")
 private Long paymentMethodId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "payment_method_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private PaymentMethod paymentMethod;
 @NotNull(groups=OnCreate.class, message="Payment status id is required")
 @Column(name="payment_status_id")
 private Long paymentStatusId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "payment_status_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private PaymentStatus paymentStatus;
 @NotBlank(groups=OnCreate.class, message="Transaction reference is required")
 @Size(max=150, message="Transaction reference must be at most 150 characters")
 @Column(name="transaction_reference")
 private String transactionReference;
 @Column(name="payment_date")
 private LocalDate paymentDate;
 @NotNull(groups=OnCreate.class, message="Amount is required")
 @DecimalMin(value="0.01", message="Amount must be at least 0.01")
 @Column(name="amount")
 private BigDecimal amount;
}