package com.example.DSphere.finance.controller;

import com.example.DSphere.finance.dto.InvoiceDTO;
import com.example.DSphere.finance.entity.Invoice;
import com.example.DSphere.finance.service.InvoiceService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/invoices")
public class InvoiceController {
    private final InvoiceService service;

    public InvoiceController(InvoiceService service) {
        this.service = service;
    }

    @Operation(summary = "Create Invoice")
    @PostMapping
    public ResponseEntity<InvoiceDTO> create(@Validated(OnCreate.class) @RequestBody InvoiceDTO body) {
        Invoice saved = service.create(DtoMapper.toEntity(body, Invoice.class));
        return ResponseEntity.created(URI.create("/api/v1/invoices/" + saved.getInvoiceId())).body(DtoMapper.toDto(saved, InvoiceDTO.class));
    }

    @Operation(summary = "Get one Invoice by id")
    @GetMapping("/{id}")
    public InvoiceDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), InvoiceDTO.class);
    }

    @Operation(summary = "List / search Invoice", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<InvoiceDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), InvoiceDTO.class));
        }
        Page<Invoice> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), InvoiceDTO.class));
    }

    @Operation(summary = "Update Invoice (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public InvoiceDTO update(@PathVariable Long id, @Valid @RequestBody InvoiceDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, Invoice.class)), InvoiceDTO.class);
    }

    @Operation(summary = "Delete Invoice")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
