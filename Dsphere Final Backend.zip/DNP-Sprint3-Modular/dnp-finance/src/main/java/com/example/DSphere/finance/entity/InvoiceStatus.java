package com.example.DSphere.finance.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="invoice_status",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class InvoiceStatus implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="invoice_status_id")
 private Long invoiceStatusId;
 @NotBlank(groups=OnCreate.class, message="Status name is required")
 @Size(max=50, message="Status name must be at most 50 characters")
 @Column(name="status_name")
 private String statusName;

 @JsonIgnore
 @OneToMany(mappedBy = "invoiceStatus", fetch = FetchType.LAZY)
 private List<Invoice> invoices;

}