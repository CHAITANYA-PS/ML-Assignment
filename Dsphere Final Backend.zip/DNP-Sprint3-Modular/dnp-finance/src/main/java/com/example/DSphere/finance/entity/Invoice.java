package com.example.DSphere.finance.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="invoice",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Invoice implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="invoice_id")
 private Long invoiceId;
 @NotBlank(groups=OnCreate.class, message="Invoice number is required")
 @Size(max=100, message="Invoice number must be at most 100 characters")
 @Column(name="invoice_number")
 private String invoiceNumber;
 @NotNull(groups=OnCreate.class, message="Order id is required")
 @Column(name="order_id")
 private Long orderId;
 @NotNull(groups=OnCreate.class, message="Invoice status id is required")
 @Column(name="invoice_status_id")
 private Long invoiceStatusId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "invoice_status_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private InvoiceStatus invoiceStatus;
 @NotNull(groups=OnCreate.class, message="Invoice date is required")
 @Column(name="invoice_date")
 private LocalDate invoiceDate;
 @NotNull(groups=OnCreate.class, message="Due date is required")
 @Column(name="due_date")
 private LocalDate dueDate;
 @NotNull(groups=OnCreate.class, message="Invoice amount is required")
 @PositiveOrZero(message="Invoice amount must be 0 or greater")
 @Column(name="invoice_amount")
 private BigDecimal invoiceAmount;

 @JsonIgnore
 @OneToMany(mappedBy = "invoice", fetch = FetchType.LAZY)
 private List<Payment> payments;

}