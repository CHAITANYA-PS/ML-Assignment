package com.example.DSphere.finance.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.finance.entity.PaymentMethod;
import com.example.DSphere.finance.repository.PaymentMethodRepository;
import org.springframework.stereotype.Service;

@Service
public class PaymentMethodService extends AbstractCrudService<PaymentMethod, Long> {
    public PaymentMethodService(PaymentMethodRepository repository) {
        super(repository, PaymentMethod.class);
    }
}
