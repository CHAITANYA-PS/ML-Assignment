package com.example.DSphere.finance.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="payment_method",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class PaymentMethod implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="payment_method_id")
 private Long paymentMethodId;
 @NotBlank(groups=OnCreate.class, message="Method name is required")
 @Size(max=50, message="Method name must be at most 50 characters")
 @Column(name="method_name")
 private String methodName;

 @JsonIgnore
 @OneToMany(mappedBy = "paymentMethod", fetch = FetchType.LAZY)
 private List<Payment> payments;

}