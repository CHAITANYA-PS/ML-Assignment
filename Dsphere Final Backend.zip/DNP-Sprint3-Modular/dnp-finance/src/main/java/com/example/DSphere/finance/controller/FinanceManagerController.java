package com.example.DSphere.finance.controller;

import com.example.DSphere.finance.dto.FinanceManagerDTO;
import com.example.DSphere.finance.entity.FinanceManager;
import com.example.DSphere.finance.service.FinanceManagerService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/finance-managers")
public class FinanceManagerController {
    private final FinanceManagerService service;

    public FinanceManagerController(FinanceManagerService service) {
        this.service = service;
    }

    @Operation(summary = "Create FinanceManager")
    @PostMapping
    public ResponseEntity<FinanceManagerDTO> create(@Validated(OnCreate.class) @RequestBody FinanceManagerDTO body) {
        FinanceManager saved = service.create(DtoMapper.toEntity(body, FinanceManager.class));
        return ResponseEntity.created(URI.create("/api/v1/finance-managers/" + saved.getUserId())).body(DtoMapper.toDto(saved, FinanceManagerDTO.class));
    }

    @Operation(summary = "Get one FinanceManager by id")
    @GetMapping("/{id}")
    public FinanceManagerDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), FinanceManagerDTO.class);
    }

    @Operation(summary = "List / search FinanceManager", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<FinanceManagerDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), FinanceManagerDTO.class));
        }
        Page<FinanceManager> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), FinanceManagerDTO.class));
    }

    @Operation(summary = "Update FinanceManager (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public FinanceManagerDTO update(@PathVariable Long id, @Valid @RequestBody FinanceManagerDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, FinanceManager.class)), FinanceManagerDTO.class);
    }

    @Operation(summary = "Delete FinanceManager")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
