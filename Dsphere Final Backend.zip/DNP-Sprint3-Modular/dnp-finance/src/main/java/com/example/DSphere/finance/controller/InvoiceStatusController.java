package com.example.DSphere.finance.controller;

import com.example.DSphere.finance.dto.InvoiceStatusDTO;
import com.example.DSphere.finance.entity.InvoiceStatus;
import com.example.DSphere.finance.service.InvoiceStatusService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/invoice-statuses")
public class InvoiceStatusController {
    private final InvoiceStatusService service;

    public InvoiceStatusController(InvoiceStatusService service) {
        this.service = service;
    }

    @Operation(summary = "Create InvoiceStatus")
    @PostMapping
    public ResponseEntity<InvoiceStatusDTO> create(@Validated(OnCreate.class) @RequestBody InvoiceStatusDTO body) {
        InvoiceStatus saved = service.create(DtoMapper.toEntity(body, InvoiceStatus.class));
        return ResponseEntity.created(URI.create("/api/v1/invoice-statuses/" + saved.getInvoiceStatusId())).body(DtoMapper.toDto(saved, InvoiceStatusDTO.class));
    }

    @Operation(summary = "Get one InvoiceStatus by id")
    @GetMapping("/{id}")
    public InvoiceStatusDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), InvoiceStatusDTO.class);
    }

    @Operation(summary = "List / search InvoiceStatus", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<InvoiceStatusDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), InvoiceStatusDTO.class));
        }
        Page<InvoiceStatus> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), InvoiceStatusDTO.class));
    }

    @Operation(summary = "Update InvoiceStatus (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public InvoiceStatusDTO update(@PathVariable Long id, @Valid @RequestBody InvoiceStatusDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, InvoiceStatus.class)), InvoiceStatusDTO.class);
    }

    @Operation(summary = "Delete InvoiceStatus")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
