package com.example.DSphere.finance.entity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.Immutable; import java.io.Serializable; import java.math.BigDecimal;
/** Read-only mapping of the database view dsphere.outstanding_payment_view. */
@Entity @Immutable @Table(name="outstanding_payment_view",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class OutstandingPaymentView implements Serializable {
 private static final long serialVersionUID = 1L;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @Column(name="payment_id")
 private Long paymentId;
 @Column(name="customer_id")
 private Long customerId;
 @Column(name="customer_name")
 private String customerName;
 @Column(name="outstanding_amount")
 private BigDecimal outstandingAmount;
 @Column(name="payment_status")
 private String paymentStatus;
 @Column(name="due_date")
 private String dueDate;
}
