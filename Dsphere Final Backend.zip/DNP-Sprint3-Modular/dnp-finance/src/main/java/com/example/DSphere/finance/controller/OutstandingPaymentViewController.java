package com.example.DSphere.finance.controller;

import com.example.DSphere.finance.dto.OutstandingPaymentViewDTO;
import com.example.DSphere.finance.entity.OutstandingPaymentView;
import com.example.DSphere.finance.service.OutstandingPaymentViewService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** Read-only endpoints over the OutstandingPaymentView database view. */
@RestController
@RequestMapping("/api/v1/views/outstanding-payments")
public class OutstandingPaymentViewController {
    private final OutstandingPaymentViewService service;

    public OutstandingPaymentViewController(OutstandingPaymentViewService service) {
        this.service = service;
    }

    @Operation(summary = "List OutstandingPaymentView (optional paging)")
    @GetMapping
    public ResponseEntity<List<OutstandingPaymentViewDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        if (page == null && size == null) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), OutstandingPaymentViewDTO.class));
        }
        Page<OutstandingPaymentView> result = service.getPage(page, size);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), OutstandingPaymentViewDTO.class));
    }

    @Operation(summary = "Get one OutstandingPaymentView by id")
    @GetMapping("/{id}")
    public OutstandingPaymentViewDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), OutstandingPaymentViewDTO.class);
    }
}
