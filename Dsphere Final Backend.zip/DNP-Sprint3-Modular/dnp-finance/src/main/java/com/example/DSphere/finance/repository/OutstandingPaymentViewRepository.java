package com.example.DSphere.finance.repository;

import com.example.DSphere.finance.entity.OutstandingPaymentView;
import org.springframework.data.repository.Repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/** Read-only repository: a view cannot be saved or deleted. */
public interface OutstandingPaymentViewRepository extends Repository<OutstandingPaymentView, Long> {
    List<OutstandingPaymentView> findAll();

    Page<OutstandingPaymentView> findAll(Pageable pageable);

    Optional<OutstandingPaymentView> findById(Long id);
}
