package com.example.DSphere.finance.controller;

import com.example.DSphere.finance.dto.PaymentStatusDTO;
import com.example.DSphere.finance.entity.PaymentStatus;
import com.example.DSphere.finance.service.PaymentStatusService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/payment-statuses")
public class PaymentStatusController {
    private final PaymentStatusService service;

    public PaymentStatusController(PaymentStatusService service) {
        this.service = service;
    }

    @Operation(summary = "Create PaymentStatus")
    @PostMapping
    public ResponseEntity<PaymentStatusDTO> create(@Validated(OnCreate.class) @RequestBody PaymentStatusDTO body) {
        PaymentStatus saved = service.create(DtoMapper.toEntity(body, PaymentStatus.class));
        return ResponseEntity.created(URI.create("/api/v1/payment-statuses/" + saved.getPaymentStatusId())).body(DtoMapper.toDto(saved, PaymentStatusDTO.class));
    }

    @Operation(summary = "Get one PaymentStatus by id")
    @GetMapping("/{id}")
    public PaymentStatusDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), PaymentStatusDTO.class);
    }

    @Operation(summary = "List / search PaymentStatus", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<PaymentStatusDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), PaymentStatusDTO.class));
        }
        Page<PaymentStatus> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), PaymentStatusDTO.class));
    }

    @Operation(summary = "Update PaymentStatus (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public PaymentStatusDTO update(@PathVariable Long id, @Valid @RequestBody PaymentStatusDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, PaymentStatus.class)), PaymentStatusDTO.class);
    }

    @Operation(summary = "Delete PaymentStatus")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
