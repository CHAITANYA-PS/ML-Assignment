package com.example.DSphere.finance.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.DSphere.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Request and response body for Invoice. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class InvoiceDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long invoiceId;

    @NotBlank(groups=OnCreate.class, message="Invoice number is required")
    @Size(max=100, message="Invoice number must be at most 100 characters")
    private String invoiceNumber;

    @NotNull(groups=OnCreate.class, message="Order id is required")
    private Long orderId;

    @NotNull(groups=OnCreate.class, message="Invoice status id is required")
    private Long invoiceStatusId;

    @NotNull(groups=OnCreate.class, message="Invoice date is required")
    private LocalDate invoiceDate;

    @NotNull(groups=OnCreate.class, message="Due date is required")
    private LocalDate dueDate;

    @NotNull(groups=OnCreate.class, message="Invoice amount is required")
    @PositiveOrZero(message="Invoice amount must be 0 or greater")
    private BigDecimal invoiceAmount;
}
