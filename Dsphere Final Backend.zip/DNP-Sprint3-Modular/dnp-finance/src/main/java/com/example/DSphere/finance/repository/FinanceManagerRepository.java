package com.example.DSphere.finance.repository;

import com.example.DSphere.finance.entity.FinanceManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FinanceManagerRepository extends JpaRepository<FinanceManager, Long> {
}
