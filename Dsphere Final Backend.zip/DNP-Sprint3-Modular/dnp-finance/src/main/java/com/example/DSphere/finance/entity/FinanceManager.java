package com.example.DSphere.finance.entity;
import com.example.DSphere.systemadmin.entity.locking.VersionedEntity;
import com.example.DSphere.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="finance_manager",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class FinanceManager implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @NotNull(groups=OnCreate.class, message="User id is required (send the id of an existing user)")
 @Column(name="user_id")
 private Long userId;
 @NotNull(groups=OnCreate.class, message="Department id is required")
 @Column(name="department_id")
 private Long departmentId;
}