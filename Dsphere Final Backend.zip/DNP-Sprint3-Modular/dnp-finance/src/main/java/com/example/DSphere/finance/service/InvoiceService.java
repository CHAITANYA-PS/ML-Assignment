package com.example.DSphere.finance.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.finance.entity.Invoice;
import com.example.DSphere.finance.repository.InvoiceRepository;
import org.springframework.stereotype.Service;

@Service
public class InvoiceService extends AbstractCrudService<Invoice, Long> {
    public InvoiceService(InvoiceRepository repository) {
        super(repository, Invoice.class);
    }
}
