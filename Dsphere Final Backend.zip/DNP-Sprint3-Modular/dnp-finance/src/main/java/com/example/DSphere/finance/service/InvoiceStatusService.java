package com.example.DSphere.finance.service;

import com.example.DSphere.systemadmin.service.AbstractCrudService;

import com.example.DSphere.finance.entity.InvoiceStatus;
import com.example.DSphere.finance.repository.InvoiceStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class InvoiceStatusService extends AbstractCrudService<InvoiceStatus, Long> {
    public InvoiceStatusService(InvoiceStatusRepository repository) {
        super(repository, InvoiceStatus.class);
    }
}
