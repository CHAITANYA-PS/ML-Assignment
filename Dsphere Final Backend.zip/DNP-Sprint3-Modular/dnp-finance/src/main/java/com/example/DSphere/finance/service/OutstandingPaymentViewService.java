package com.example.DSphere.finance.service;

import com.example.DSphere.systemadmin.service.ReadOnlyViewService;

import com.example.DSphere.finance.entity.OutstandingPaymentView;
import com.example.DSphere.finance.repository.OutstandingPaymentViewRepository;
import org.springframework.stereotype.Service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

@Service
public class OutstandingPaymentViewService extends ReadOnlyViewService<OutstandingPaymentView, Long> {
    private final OutstandingPaymentViewRepository repository;

    public OutstandingPaymentViewService(OutstandingPaymentViewRepository repository) {
        super("OutstandingPaymentView");
        this.repository = repository;
    }

    @Override
    protected List<OutstandingPaymentView> findAllRows() {
        return repository.findAll();
    }

    @Override
    protected Optional<OutstandingPaymentView> findRow(Long id) {
        return repository.findById(id);
    }

    @Override
    protected Page<OutstandingPaymentView> findPageRows(Pageable pageable) {
        return repository.findAll(pageable);
    }

    @Override
    protected String idProperty() {
        return "paymentId";
    }
}
