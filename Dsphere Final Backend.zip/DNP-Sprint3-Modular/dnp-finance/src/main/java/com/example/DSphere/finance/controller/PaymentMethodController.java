package com.example.DSphere.finance.controller;

import com.example.DSphere.finance.dto.PaymentMethodDTO;
import com.example.DSphere.finance.entity.PaymentMethod;
import com.example.DSphere.finance.service.PaymentMethodService;
import com.example.DSphere.systemadmin.dto.DtoMapper;
import com.example.DSphere.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/payment-methods")
public class PaymentMethodController {
    private final PaymentMethodService service;

    public PaymentMethodController(PaymentMethodService service) {
        this.service = service;
    }

    @Operation(summary = "Create PaymentMethod")
    @PostMapping
    public ResponseEntity<PaymentMethodDTO> create(@Validated(OnCreate.class) @RequestBody PaymentMethodDTO body) {
        PaymentMethod saved = service.create(DtoMapper.toEntity(body, PaymentMethod.class));
        return ResponseEntity.created(URI.create("/api/v1/payment-methods/" + saved.getPaymentMethodId())).body(DtoMapper.toDto(saved, PaymentMethodDTO.class));
    }

    @Operation(summary = "Get one PaymentMethod by id")
    @GetMapping("/{id}")
    public PaymentMethodDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), PaymentMethodDTO.class);
    }

    @Operation(summary = "List / search PaymentMethod", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<PaymentMethodDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), PaymentMethodDTO.class));
        }
        Page<PaymentMethod> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), PaymentMethodDTO.class));
    }

    @Operation(summary = "Update PaymentMethod (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public PaymentMethodDTO update(@PathVariable Long id, @Valid @RequestBody PaymentMethodDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, PaymentMethod.class)), PaymentMethodDTO.class);
    }

    @Operation(summary = "Delete PaymentMethod")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
