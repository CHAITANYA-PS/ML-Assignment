package com.example.DSphere.finance.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.DSphere.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Request and response body for Payment. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class PaymentDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long paymentId;

    @NotNull(groups=OnCreate.class, message="Invoice id is required")
    private Long invoiceId;

    @NotNull(groups=OnCreate.class, message="Payment method id is required")
    private Long paymentMethodId;

    @NotNull(groups=OnCreate.class, message="Payment status id is required")
    private Long paymentStatusId;

    @NotBlank(groups=OnCreate.class, message="Transaction reference is required")
    @Size(max=150, message="Transaction reference must be at most 150 characters")
    private String transactionReference;

    private LocalDate paymentDate;

    @NotNull(groups=OnCreate.class, message="Amount is required")
    @DecimalMin(value="0.01", message="Amount must be at least 0.01")
    private BigDecimal amount;
}
