package com.example.DSphere.finance.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.DSphere.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;

/**
 * Response body for the read-only view OutstandingPaymentView (no create / update).
 */
@Getter
@Setter
@NoArgsConstructor
public class OutstandingPaymentViewDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long paymentId;

    private Long customerId;

    private String customerName;

    private BigDecimal outstandingAmount;

    private String paymentStatus;

    private String dueDate;
}
