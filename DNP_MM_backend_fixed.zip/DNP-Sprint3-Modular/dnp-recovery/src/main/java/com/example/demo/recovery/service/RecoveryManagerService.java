package com.example.demo.recovery.service;

import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.service.StakeholderRoleService;
import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.RecoveryManager;
import com.example.demo.recovery.repository.RecoveryManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryManagerService extends AbstractCrudService<RecoveryManager, Long> {
    private final StakeholderRoleService stakeholders;

    public RecoveryManagerService(RecoveryManagerRepository repository, StakeholderRoleService stakeholders) {
        super(repository, RecoveryManager.class);
        this.stakeholders = stakeholders;
    }

    /** A RecoveryManager row gives the user the RECOVERY_MANAGER role (one user = one stakeholder). */
    @Override
    protected void afterCreate(RecoveryManager saved) {
        stakeholders.assign(saved.getUserId(), Roles.RECOVERY_MANAGER);
    }

    @Override
    protected void beforeDelete(RecoveryManager existing) {
        stakeholders.unassign(existing.getUserId(), Roles.RECOVERY_MANAGER);
    }

    /** The id is the user_id of an existing user (one-to-one sub-type of app_user), so the client supplies it. */
    @Override
    protected boolean idAssignedByClient() {
        return true;
    }
}
