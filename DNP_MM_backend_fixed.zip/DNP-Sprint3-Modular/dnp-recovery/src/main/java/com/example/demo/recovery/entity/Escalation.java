package com.example.demo.recovery.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="escalation",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Escalation implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="escalation_id")
 private Long escalationId;
 @Column(name="ticket_id")
 private Long ticketId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "ticket_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private Ticket ticket;
 @Column(name="escalated_to")
 private Long escalatedTo;
 @Column(name="escalation_level")
 private Integer escalationLevel;
 @Column(name="reason")
 private String reason;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}