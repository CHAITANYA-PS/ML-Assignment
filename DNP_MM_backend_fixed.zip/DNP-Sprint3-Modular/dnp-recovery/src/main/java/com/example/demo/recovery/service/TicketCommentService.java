package com.example.demo.recovery.service;

import org.springframework.transaction.annotation.Transactional;
import com.example.demo.recovery.entity.Ticket;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import java.util.LinkedHashMap;
import java.util.Map;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.TicketComment;
import com.example.demo.recovery.repository.TicketCommentRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketCommentService extends AbstractCrudService<TicketComment, Long> {
    public TicketCommentService(TicketCommentRepository repository) {
        super(repository, TicketComment.class);
    }

    /** Relationship demo (@ManyToOne): the ticket a comment belongs to, read through comment.getTicket(). */
    @Transactional(readOnly = true)
    public Map<String, Object> ticketOf(Long commentId) {
        TicketComment c = get(commentId);
        Ticket t = c.getTicket();
        if (t == null) {
            throw new ResourceNotFoundException("Ticket not found for comment " + commentId);
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("commentId", c.getCommentId());
        out.put("ticketId", t.getTicketId());
        out.put("referenceNumber", t.getReferenceNumber());
        out.put("subject", t.getSubject());
        return out;
    }
}
