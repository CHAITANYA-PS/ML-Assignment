package com.example.demo.recovery.service;

import com.example.demo.recovery.entity.Ticket;
import com.example.demo.recovery.entity.TicketComment;
import com.example.demo.recovery.repository.TicketCommentRepository;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/** @ManyToOne TicketComment.ticket and @OneToMany Ticket.ticketComments (no database). */
@ExtendWith(MockitoExtension.class)
class TicketCommentRelationshipTest {
    @Mock TicketCommentRepository repository;
    @InjectMocks TicketCommentService service;

    @Test
    void mappings_areDeclared() throws Exception {
        JoinColumn jc = TicketComment.class.getDeclaredField("ticket").getAnnotation(JoinColumn.class);
        assertNotNull(TicketComment.class.getDeclaredField("ticket").getAnnotation(ManyToOne.class));
        assertEquals("ticket_id", jc.name());
        assertFalse(jc.insertable());
        assertFalse(jc.updatable());
        assertEquals("ticket", Ticket.class.getDeclaredField("ticketComments").getAnnotation(OneToMany.class).mappedBy());
    }

    @Test
    void ticketOf_readsThroughManyToOne() {
        Ticket t = new Ticket();
        t.setTicketId(7L);
        t.setReferenceNumber("TKT-7");
        t.setSubject("Short delivery");
        TicketComment c = new TicketComment();
        c.setCommentId(3L);
        c.setTicketId(7L);
        c.setTicket(t);
        when(repository.findById(3L)).thenReturn(Optional.of(c));
        Map<String, Object> out = service.ticketOf(3L);
        assertEquals(7L, out.get("ticketId"));
        assertEquals("TKT-7", out.get("referenceNumber"));
    }

    @Test
    void ticketOf_missingTicket_isNotFound() {
        TicketComment c = new TicketComment();
        c.setCommentId(3L);
        when(repository.findById(3L)).thenReturn(Optional.of(c));
        assertThrows(ResourceNotFoundException.class, () -> service.ticketOf(3L));
    }
}
