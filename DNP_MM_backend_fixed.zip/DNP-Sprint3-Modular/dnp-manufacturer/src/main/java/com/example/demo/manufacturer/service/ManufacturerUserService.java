package com.example.demo.manufacturer.service;

import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.service.StakeholderRoleService;
import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.manufacturer.entity.ManufacturerUser;
import com.example.demo.manufacturer.repository.ManufacturerUserRepository;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerUserService extends AbstractCrudService<ManufacturerUser, Long> {
    private final StakeholderRoleService stakeholders;

    public ManufacturerUserService(ManufacturerUserRepository repository, StakeholderRoleService stakeholders) {
        super(repository, ManufacturerUser.class);
        this.stakeholders = stakeholders;
    }

    /** A ManufacturerUser row gives the user the MANUFACTURER role (one user = one stakeholder). */
    @Override
    protected void afterCreate(ManufacturerUser saved) {
        stakeholders.assign(saved.getUserId(), Roles.MANUFACTURER);
    }

    @Override
    protected void beforeDelete(ManufacturerUser existing) {
        stakeholders.unassign(existing.getUserId(), Roles.MANUFACTURER);
    }

    /** The id is the user_id of an existing user (one-to-one sub-type of app_user), so the client supplies it. */
    @Override
    protected boolean idAssignedByClient() {
        return true;
    }
}
