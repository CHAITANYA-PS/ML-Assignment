package com.example.demo.manufacturer.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="emission_factor",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class EmissionFactor implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="emission_factor_id")
 private Long emissionFactorId;
 @Column(name="vehicle_type_id")
 private Long vehicleTypeId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "vehicle_type_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private VehicleType vehicleType;
 @Column(name="factor_value")
 private BigDecimal factorValue;
 @Column(name="unit")
 private String unit;
 @Column(name="valid_from")
 private LocalDate validFrom;
 @Column(name="valid_to")
 private LocalDate validTo;
}