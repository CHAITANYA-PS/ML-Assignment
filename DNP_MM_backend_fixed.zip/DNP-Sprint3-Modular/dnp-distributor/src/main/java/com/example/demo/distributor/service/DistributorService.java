package com.example.demo.distributor.service;

import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Map;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.DuplicateResourceException;
import com.example.demo.distributor.entity.Distributor;
import com.example.demo.distributor.repository.DistributorRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.OffsetDateTime;

@Service
public class DistributorService extends AbstractCrudService<Distributor, Long> {
    static final String DEFAULT_STATUS = "Active";
    private final DistributorRepository distributors;

    public DistributorService(DistributorRepository repository) {
        super(repository, Distributor.class);
        this.distributors = repository;
    }

    @Override
    protected void beforeCreate(Distributor d) {
        if (distributors.existsByDistributorCode(d.getDistributorCode())) {
            throw new DuplicateResourceException("Distributor code already exists: " + d.getDistributorCode());
        }
        if (d.getStatus() == null || d.getStatus().isBlank()) {
            d.setStatus(DEFAULT_STATUS);
        }
        if (d.getOnboardingDate() == null) {
            d.setOnboardingDate(LocalDate.now());
        }
        OffsetDateTime now = OffsetDateTime.now();
        d.setCreatedAt(now);
        d.setUpdatedAt(now);
    }

    @Override
    protected void beforeUpdate(Long id, Distributor d, Distributor existing) {
        distributors.findByDistributorCode(d.getDistributorCode())
                .filter(other -> !other.getDistributorId().equals(id))
                .ifPresent(other -> {
                    throw new DuplicateResourceException("Distributor code already exists: " + d.getDistributorCode());
                });
        if (d.getStatus() == null || d.getStatus().isBlank()) {
            throw new BusinessRuleException("Distributor status must not be blank");
        }
        d.setCreatedAt(existing.getCreatedAt());
        d.setUpdatedAt(OffsetDateTime.now());
    }

    /**
     * The @ManyToMany side owns the distributor_category link table, so Hibernate would delete the links on its
     * own when a distributor is deleted. Refuse instead, as the foreign key did before.
     */
    @Override
    protected void beforeDelete(Distributor existing) {
        if (existing.getCategories() != null && !existing.getCategories().isEmpty()) {
            throw new BusinessRuleException("Distributor " + existing.getDistributorId() + " is still assigned to "
                    + existing.getCategories().size() + " categories. Remove the distributor categories first");
        }
    }

    /** Relationship demo (@ManyToMany): the categories of a distributor, read through distributor.getCategories(). */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> categories(Long id) {
        Distributor d = get(id);
        if (d.getCategories() == null) {
            return List.of();
        }
        return d.getCategories().stream()
                .map(c -> Map.<String, Object>of("categoryId", c.getCategoryId(), "categoryName", String.valueOf(c.getCategoryName())))
                .toList();
    }
}
