package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.DuplicateResourceException;
import com.example.demo.distributor.entity.Distributor;
import com.example.demo.distributor.repository.DistributorRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import com.example.demo.systemadmin.service.ResourceNotFoundException;

import java.time.OffsetDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DistributorServiceTest {
    @Mock DistributorRepository repository;
    @InjectMocks DistributorService service;

    private Distributor d(Long id, String code, Long version) {
        Distributor x = new Distributor();
        x.setDistributorId(id);
        x.setDistributorCode(code);
        x.setDistributorName("Name");
        x.setVersion(version);
        return x;
    }

    @Test
    void create_setsDefaults() {
        when(repository.existsByDistributorCode("D1")).thenReturn(false);
        when(repository.save(any(Distributor.class))).thenAnswer(a -> a.getArgument(0));
        Distributor r = service.create(d(null, "D1", null));
        assertEquals("Active", r.getStatus());
        assertNotNull(r.getOnboardingDate());
        assertNotNull(r.getCreatedAt());
    }

    @Test
    void create_duplicateCode_rejected() {
        when(repository.existsByDistributorCode("D1")).thenReturn(true);
        assertThrows(DuplicateResourceException.class, () -> service.create(d(null, "D1", null)));
        verify(repository, never()).save(any());
    }

    @Test
    void update_codeUsedByAnotherDistributor_rejected() {
        Distributor existing = d(1L, "D1", 0L);
        existing.setStatus("Active");
        when(repository.findById(1L)).thenReturn(Optional.of(existing));
        when(repository.findByDistributorCode("D2")).thenReturn(Optional.of(d(2L, "D2", 0L)));
        Distributor body = d(null, "D2", null);
        body.setStatus("Active");
        assertThrows(DuplicateResourceException.class, () -> service.update(1L, body));
    }

    @Test
    void update_sameCode_keepsCreatedAtAndBumpsUpdatedAt() {
        Distributor existing = d(1L, "D1", 0L);
        OffsetDateTime created = OffsetDateTime.now().minusDays(3);
        existing.setCreatedAt(created);
        when(repository.findById(1L)).thenReturn(Optional.of(existing));
        when(repository.findByDistributorCode("D1")).thenReturn(Optional.of(existing));
        when(repository.save(any(Distributor.class))).thenAnswer(a -> a.getArgument(0));
        Distributor body = d(null, "D1", 0L);
        body.setStatus("INACTIVE");
        Distributor r = service.update(1L, body);
        assertEquals(created, r.getCreatedAt());
        assertTrue(r.getUpdatedAt().isAfter(created));
    }

    @Test
    void update_staleVersion_rejected() {
        when(repository.findById(1L)).thenReturn(Optional.of(d(1L, "D1", 4L)));
        assertThrows(ObjectOptimisticLockingFailureException.class, () -> service.update(1L, d(null, "D1", 3L)));
    }

    @Test
    void update_missing_notFound() {
        when(repository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.update(1L, d(null, "D1", null)));
    }
}
