package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.Category;
import com.example.demo.distributor.entity.Distributor;
import com.example.demo.distributor.entity.DistributorCategory;
import com.example.demo.distributor.repository.DistributorRepository;
import com.example.demo.systemadmin.service.BusinessRuleException;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** The JPA relationships of the distributor module: @ManyToOne, @OneToMany and @ManyToMany (no database). */
@ExtendWith(MockitoExtension.class)
class DistributorRelationshipTest {
    @Mock DistributorRepository repository;
    @InjectMocks DistributorService service;

    private static Category category(long id, String name) {
        Category c = new Category();
        c.setCategoryId(id);
        c.setCategoryName(name);
        return c;
    }

    private static Distributor distributor(List<Category> categories) {
        Distributor d = new Distributor();
        d.setDistributorId(1L);
        d.setVersion(0L);
        d.setCategories(categories);
        return d;
    }

    @Test
    void mappings_areDeclared() throws Exception {
        assertNotNull(DistributorCategory.class.getDeclaredField("distributor").getAnnotation(ManyToOne.class));
        assertEquals("distributor", Distributor.class.getDeclaredField("distributorCategories").getAnnotation(OneToMany.class).mappedBy());
        assertNotNull(Distributor.class.getDeclaredField("categories").getAnnotation(ManyToMany.class));
        assertEquals("distributor_category", Distributor.class.getDeclaredField("categories").getAnnotation(JoinTable.class).name());
        assertEquals("categories", Category.class.getDeclaredField("distributors").getAnnotation(ManyToMany.class).mappedBy());
    }

    @Test
    void categories_readThroughManyToMany() {
        when(repository.findById(1L)).thenReturn(Optional.of(distributor(List.of(category(3, "Dairy"), category(4, "Snacks")))));
        List<Map<String, Object>> out = service.categories(1L);
        assertEquals(2, out.size());
        assertEquals("Dairy", out.get(0).get("categoryName"));
    }

    @Test
    void categories_noneLinked_isEmpty() {
        when(repository.findById(1L)).thenReturn(Optional.of(distributor(null)));
        assertTrue(service.categories(1L).isEmpty());
    }

    @Test
    void delete_withCategories_isRefused() {
        when(repository.findById(1L)).thenReturn(Optional.of(distributor(List.of(category(3, "Dairy")))));
        assertThrows(BusinessRuleException.class, () -> service.delete(1L));
        verify(repository, never()).deleteById(any());
    }

    @Test
    void delete_withoutCategories_isAllowed() {
        when(repository.findById(1L)).thenReturn(Optional.of(distributor(null)));
        service.delete(1L);
        verify(repository).deleteById(1L);
    }
}
