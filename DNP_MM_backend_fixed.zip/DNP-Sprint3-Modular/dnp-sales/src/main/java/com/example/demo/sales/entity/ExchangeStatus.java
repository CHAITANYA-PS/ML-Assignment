package com.example.demo.sales.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="exchange_status",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ExchangeStatus implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="exchange_status_id")
 private Long exchangeStatusId;
 @Column(name="status_name")
 private String statusName;
 @Column(name="sequence_number")
 private Integer sequenceNumber;
 @Column(name="is_terminal")
 private Boolean isTerminal;

 @JsonIgnore
 @OneToMany(mappedBy = "exchangeStatus", fetch = FetchType.LAZY)
 private List<ExchangeHistory> exchangeHistories;

 @JsonIgnore
 @OneToMany(mappedBy = "exchangeStatus", fetch = FetchType.LAZY)
 private List<ExchangeRequest> exchangeRequests;

}