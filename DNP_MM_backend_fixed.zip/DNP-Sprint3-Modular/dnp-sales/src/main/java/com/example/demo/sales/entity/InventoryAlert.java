package com.example.demo.sales.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="inventory_alert",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class InventoryAlert implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="alert_id")
 private Long alertId;
 @Column(name="warehouse_stock_id")
 private Long warehouseStockId;
 @JsonIgnore
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "warehouse_stock_id", insertable = false, updatable = false, foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
 private WarehouseStock warehouseStock;
 @Column(name="alert_type")
 private String alertType;
 @Column(name="message")
 private String message;
 @Column(name="status")
 private String status;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}