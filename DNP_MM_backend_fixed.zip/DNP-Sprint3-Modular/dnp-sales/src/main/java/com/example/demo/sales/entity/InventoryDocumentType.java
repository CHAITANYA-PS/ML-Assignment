package com.example.demo.sales.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="inventory_document_type",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class InventoryDocumentType implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="inventory_document_type_id")
 private Long inventoryDocumentTypeId;
 @Column(name="document_type_name")
 private String documentTypeName;

 @JsonIgnore
 @OneToMany(mappedBy = "inventoryDocumentType", fetch = FetchType.LAZY)
 private List<InventoryDocument> inventoryDocuments;

}