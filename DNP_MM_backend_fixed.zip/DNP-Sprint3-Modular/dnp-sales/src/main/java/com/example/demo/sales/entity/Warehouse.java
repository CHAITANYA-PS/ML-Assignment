package com.example.demo.sales.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal;
@Entity @Table(name="warehouse",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Warehouse implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="warehouse_id")
 private Long warehouseId;
 @Column(name="warehouse_code")
 private String warehouseCode;
 @Column(name="warehouse_name")
 private String warehouseName;
 @Column(name="region_id")
 private Long regionId;
 @Column(name="location")
 private String location;
 @Column(name="capacity")
 private BigDecimal capacity;
 @Column(name="status")
 private String status;

 @JsonIgnore
 @OneToMany(mappedBy = "warehouse", fetch = FetchType.LAZY)
 private List<Shipment> shipments;

 @JsonIgnore
 @OneToMany(mappedBy = "warehouse", fetch = FetchType.LAZY)
 private List<WarehouseStock> warehouseStocks;

}